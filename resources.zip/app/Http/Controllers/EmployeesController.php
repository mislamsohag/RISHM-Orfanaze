<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Exception;
use Illuminate\Http\Request;

class EmployeesController extends Controller
{
    function Employee()
    {
        $employee = [
            [
                'id' => 1,
                'image' => 'url1',
                'name' => 'Mohammad Asheque Ameen Majumder',
                'designation' => 'Advisor',
                'phone' => '0171----------'
            ],
            [
                'id' => 2,
                'image' => 'url2',
                'name' => 'Md. Moniruzzaman',
                'designation' => 'Muhtameem/Principal',
                'phone' => '01------------'
            ],
            [
                'id' => 3,
                'image' => 'url3',
                'name' => 'Md. Masud Alam',
                'designation' => 'Assistant Teacher (English)',
                'phone' => '01----------'
            ],
            [
                'id' => 4,
                'image' => 'url3',
                'name' => 'Md. Mazharul Islam Sohag',
                'designation' => 'Engineer',
                'phone' => '01812060163'
            ],
        ];
        return view("pages.employees", ['employees' => $employee]);
    }

    public function EmployeeCreate(Request $request)
    {
        $request->validate([
            'title' => 'required|string',
            'name' => 'required|string',
            'email' => 'required|string',
            'n_id' => 'required|string',
            'mobile' => 'required|string',
            'gender' => 'required|string',
            'address' => 'required|string'
        ]);

        try {
            return Employee::create([
                'title' => $request->input('title'),
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'n_id' => $request->input('n_id'),
                'mobile' => $request->input('mobile'),
                'gender' => $request->input('gender'),
                'address' => $request->input('address')
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => 'faild',
                'message' => 'Something went wrong!'
            ], 401);
        }
    }

    public function EmployeeUpdate(Request $request)
    {
        $request->validate([
            'title' => 'required|string',            
            'email' => 'required|string',            
            'mobile' => 'required|string',            
            'address' => 'required|string'
        ]);

        $id=$request->input('id');
        try {
            return Employee::where('id', $id)->update([
                'title' => $request->input('title'),
                'email' => $request->input('email'),
                'mobile' => $request->input('mobile'),
                'address' => $request->input('address')
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => 'faild',
                'message' => 'Something went wrong!'
            ], 401);
        }
    }

    function EmployeeDelete(Request $request){
        $id=$request->id;

        return Employee::where('id', $id)->delete();
    }
}
