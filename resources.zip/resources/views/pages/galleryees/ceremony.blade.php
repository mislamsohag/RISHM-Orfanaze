@extends('Layouts.app')

@section('content')

@include('Components.galleryees.ceremony')

@endsection