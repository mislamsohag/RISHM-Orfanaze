<section class="links box-shadow">
    <h1 class="section-heading text-highlight heading-bg"><span class="line">Download</span></h1>
    <div class="section-content">
        <p>
            <a href="{{url('#')}}"><i class="fa fa-download"></i>Admission Form</a>
        </p>
        <p>
            <a href="{{url('#')}}"><i class="fa fa-download"></i>Academic Prospectus</a>
        </p>
        <p>
            <a href="{{url('#')}}"><i class="fa fa-download"></i>Admission Result</a>
        </p>
        <p>
            <a href="{{url('tcForm.pdf')}}"><i class="fa fa-download"></i>TC Form</a>
        </p>
    </div>

</section>