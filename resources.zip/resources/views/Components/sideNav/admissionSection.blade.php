
<section class="widget has-divider">
    <h3 class="title">Admission on Online</h3>
    <a class="btn btn-theme" href="{{url('admission/onlineAdmission')}}"><i class="fa fa-arrow-circle-right"></i>Apply Now</a>
</section>