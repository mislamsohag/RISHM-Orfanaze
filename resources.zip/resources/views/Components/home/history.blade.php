<section class="history">
    <h1 class="section-heading text-highlight"><span class="line">RAZAPUR SIDDIQIA ISLAMIA HAFIZIA MADRASAH</span></h1>
    <figure class="thumb col-md-6 col-sm-6 col-xs-6">
        <img src="{{asset('images/history/madrasahBoban.jpg')}}" class="img-responsive img-resize" alt="Image">
    </figure>
    <div class="section-content">
        <p class="description"><big>T</big>he renowned madrasah of Chandpur district is Rajapur Siddiqia Hafizia Nurani Madrasah and Atimkhana
             was founded in 2007. It is one of the famous educational institute for Hefz in Chandpur district. Modern education system, strict rules and regulation, low costing, and full free cost of Atim Students highly educated and trained teachers supervised the madrasah. The madrasah is situated in Rajapur, Khilpara, Hajigonj, Chandpur with own land and it&rsquo;s natural beauty is suitable for students. In present
            time there are Hefz and Nurani Division in this institute. In the examination the madrasah has good reputation, and Last 10 years and it's increasing day by day InshaAllah.
        </p>
    </div>
</section>