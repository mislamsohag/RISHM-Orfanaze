
<section class="widget has-divider">
    <h3 class="title">Teram Result</h3>
    <a class="btn btn-theme" href="{{url('termResult')}}"><i class="fa fa-arrow-circle-right"></i>Search</a>
</section>