<div class="col-md-12 noPrintShow">
	<div class="page-wrapper">
		<header class="page-heading clearfix">
			<h1 class="heading-title pull-left">Result</h1>
			<div class="breadcrumbs pull-right">
				<ul class="breadcrumbs-list">
					<li class="breadcrumbs-label">You are here:</li>
					<li><a href="<?php echo e(url('home')); ?>">Home</a><i class="fa fa-angle-right"></i></li>
					<li class="current">Leadership Team</li>
				</ul>
			</div><!--//breadcrumbs-->
		</header>
	</div>
</div>

<div class="col-md-9">
	<div style="background: #FFF;" class="table-responsive">
		<table class="table table-bordered">
			<thead style="background: #002E5B;">
				<tr>
					<th style=" color: #FFF;">#</th>
					<th style=" color: #FFF;">Class</th>
					<th style=" color: #FFF;" width="350">Title</th>
					<th style=" color: #FFF;">Published Date</th>
					<th style=" color: #FFF;">Download</th>
				</tr>
			</thead>
			
			<tbody>
				<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($result['id']); ?></td>
					<td><?php echo e($result['class']); ?></td>
					<td><a href='javascript:;'><?php echo e($result['resultTitle']); ?></a> <span class="label label-success"></span>
					</td>
					<td><i class="fa fa-calendar"></i> <?php echo e($result['date']); ?></td>

					<td>
						<a href="<?php echo e(asset('../results/3183608Jan2023.pdf')); ?>" target="_blank"
							class="btn btn-success btn-sm"><i class='fa fa-download'>
								&nbsp;<?php echo e($result['download']); ?></i></a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table><!--//table-->
	</div><!--//table-responsive-->
	<tr>
		<td colspan="6">

		</td>
	</tr>
</div><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/results/pdfResult.blade.php ENDPATH**/ ?>