<section class="links box-shadow">
    <h1 class="section-heading text-highlight heading-bg"><span class="line">Visitor</span></h1>
    <div class="section-content" align="center">
        <object allowscriptaccess="always" type="application/x-shockwave-flash"
            data="plagin Control Link" width="230" height="180"
            wmode="transparent">
            <param name="allowscriptaccess" value="always" />
            <param name="movie" value="plagin Control Link" />
            <param name="wmode" value="transparent" /><embed
                src="plagin Control Link"
                type="application/x-shockwave-flash" allowscriptaccess="always" wmode="transparent" width="200"
                height="250" /><video width="200" height="250"><a href="Link" title="roulett"
                    style="font-weight:normal;;text-decoration:none">roulett</a></video>
        </object>
    </div>
</section><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/pages/home/visitorsCount.blade.php ENDPATH**/ ?>