
<section class="widget has-divider">
    <h3 class="title">Tutorial Result</h3>
    <a class="btn btn-theme" href="<?php echo e(url('tutorialResult')); ?>"><i class="fa fa-arrow-circle-right"></i>Search</a>
</section><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/results/tutorial.blade.php ENDPATH**/ ?>