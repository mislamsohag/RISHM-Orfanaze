<?php $__env->startSection('content'); ?>
<div class="content container">
	<div class="row cols-wrapper">
		<div class="col-md-12 noPrintShow">
			<div class="page-wrapper">
				<header class="page-heading clearfix">
					<h1 class="heading-title pull-left">Employees</h1>
					<div class="breadcrumbs pull-right">
						<ul class="breadcrumbs-list">
							<li class="breadcrumbs-label">You are here:</li>
							<li><a href="index.html">Home</a><i class="fa fa-angle-right"></i></li>
							<li class="current">Leadership Team</li>
						</ul>
					</div><!--//breadcrumbs-->
				</header>
			</div>
		</div>
		<div class="col-md-9">
			<div style="background: #FFF;" class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>#</th>
							<th>Picture</th>
							<th>Name</th>
							<th>Designation</th>
							<!--<th>E-mail</th>-->
							<th>Phone</th>
						</tr>
					</thead>
					<tbody>

						<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($employee['id']); ?></td>
							<td>
								<img src="<?php echo e($employee['image']); ?>" class="img-responsive img-circle profile-img"
									alt="">
							</td>

							<td><a href="javascript:"><b><?php echo e($employee['name']); ?></b></a></td>
							<td><?php echo e($employee['designation']); ?></td>
							<!--<td></td>-->
							<td><?php echo e($employee['phone']); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>
				</table><!--//table-->
			</div><!--//table-responsive-->
		</div>


		<div class="col-md-3 noPrintShow">
			<?php echo $__env->make('Components.pages.home.admissionSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('Components.pages.home.downloadLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('Components.pages.home.visitorsCount', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div><!--//cols-wrapper-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/pages/employees/employees.blade.php ENDPATH**/ ?>