
<footer class="container">
    <div class="bottom-footer_lastSection__1ftfg ">
        <div><img src="#"
                class="bottom-footer_dkLogo__1q7Vu gm-observing gm-observing-cb lazyloaded" alt="Help for Orphans and Helpless Logo"
                loading="lazy">
            <p class="bottom-footer_aboutDkText__TARHw">We are Bangladeshi most trusted and transparent crowdfunding
                platform, with a vision to create a social impact. Our unique model allows people from across the globe
                to donate towards raising funds for products required by NGOs and charities in India, which are then
                delivered to them by us.</p>
            <div class="bottom-footer_dkConnectingPoint__3hVdB">
                <div class="footer-social-icons_socialLinkContainer__3BpgX"><a id="facebook"
                        class="footer-social-icons_socialIcon__2KP2K footer-social-icons_iconFacebook__wnn8j"
                        href="<?php echo e(url('https://www.facebook.com')); ?>" rel="noreferrer" target="_blank"><i><svg
                                aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-f"
                                class="svg-inline--fa fa-facebook-f fa-w-10 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                <path fill="currentColor"
                                    d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
                                </path>
                            </svg></i></a><a id="twitter"
                        class="footer-social-icons_socialIcon__2KP2K footer-social-icons_iconTwitter__17rzi"
                        href="<?php echo e(url('https://twitter.com')); ?>" rel="noreferrer" target="_blank"><i><svg
                                aria-hidden="true" focusable="false" data-prefix="fab" data-icon="twitter"
                                class="svg-inline--fa fa-twitter fa-w-16 " role="img" xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 512 512">
                                <path fill="currentColor"
                                    d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z">
                                </path>
                            </svg></i></a><a id="instagram"
                        class="footer-social-icons_socialIcon__2KP2K footer-social-icons_iconInstagram__2_qJf"
                        href="<?php echo e(url('https://www.instagram.com')); ?>" rel="noreferrer" target="_blank"><i><svg
                                aria-hidden="true" focusable="false" data-prefix="fab" data-icon="instagram"
                                class="svg-inline--fa fa-instagram fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
                                </path>
                            </svg></i></a><a id="linkedIn"
                        class="footer-social-icons_socialIcon__2KP2K footer-social-icons_iconLinkedin__3qIQJ"
                        href="<?php echo e(url('https://www.linkedin.com')); ?>" rel="noreferrer" target="_blank"><i><svg
                                aria-hidden="true" focusable="false" data-prefix="fab" data-icon="linkedin-in"
                                class="svg-inline--fa fa-linkedin-in fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
                                </path>
                            </svg></i></a><a id="youtube"
                        class="footer-social-icons_socialIcon__2KP2K footer-social-icons_iconYoutube__2aYSV"
                        href="<?php echo e(url('https://www.youtube.com')); ?>" rel="noreferrer"
                        target="_blank"><i><svg aria-hidden="true" focusable="false" data-prefix="fab"
                                data-icon="youtube" class="svg-inline--fa fa-youtube fa-w-18 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                                <path fill="currentColor"
                                    d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z">
                                </path>
                            </svg></i></a></div>
            </div>
        </div>
        <div class="footer-dk-links_linksContainer__28S7c">
            <div class="footer-dk-links_linksWrapper__23SHK">
                <div class="footer-dk-links_sectionTitle__1jIak">Discover</div><a id="aboutUs" to="<?php echo e(url('/about-us')); ?>"
                    title="Donate Cart Is An Online Crowdfunding Platform That Helps People To Donate For Social Causes"
                    href="<?php echo e(url('#')); ?>">About Us</a><a id="requestCampaign" to="<?php echo e(url('#')); ?>"
                    title="Start a campaign with Help for Orphans and Helpless" href="<?php echo e(url('/start-campaign')); ?>">Start A Campaign</a><a
                    id="monthlyGiving" to="<?php echo e(url('/monthlygiving')); ?>"
                    title="Make Online Donations To Charity On Monthly Basis &amp; Avail Tax Benefits With Help for Orphans and Helpless"
                    href="<?php echo e(url('/monthlygiving')); ?>">Donate Monthly</a><a id="exploreCampaigns" to="<?php echo e(url('/explore-campaigns')); ?>"
                    title="Explore Various Campaigns Under Specific Categories" href="<?php echo e(url('/explore-campaigns')); ?>">Explore
                    Campaigns</a><a id="lifeCampaigns"
                    to="<?php echo e(url('#')); ?>"
                    title="Support People To Raise Funds For Their Medical Emergencies With Help for Orphans and Helpless"
                    href="<?php echo e(url('#')); ?>">Life</a>
            </div>
            <div class="footer-dk-links_linksWrapper__23SHK">
                <div class="footer-dk-links_sectionTitle__1jIak">Learn</div><a id="howItWorks" to="<?php echo e(url('#')); ?>"
                    title="Explore The Operations Of Help for Orphans and Helpless- An Online Donation Platform" href="<?php echo e(url('#')); ?>">How
                    It Works</a><a id="faqs" to="<?php echo e(url('#')); ?>"
                    title="Explore Most Commonly Asked Questions &amp; Their Answers About Online Fundraising &amp; Donations"
                    href="<?php echo e(url('#')); ?>">FAQs</a><a id="giftCard" to="<?php echo e(url('#')); ?>"
                    title="Now Double Your Happiness With Help for Orphans and Helpless's Gift Cards On Your Special Occasions"
                    href="<?php echo e(url('#')); ?>">Gift Cards</a><a id="partnerShips" to="<?php echo e(url('#')); ?>"
                    title="Partner With Help for Orphans and Helpless - India's Most Trusted Online Crowdfunding/Donation Platform"
                    href="<?php echo e(url('#')); ?>">Partnerships</a><a id="blogs" href="<?php echo e(url('#')); ?>"
                    title="Get Updates On Current Social Affairs &amp; Challenges With Help for Orphans and Helpless's Blog">Blogs</a>
            </div>
        </div>
        <div class="bottom-footer_addressContainer__1Xu3v ">
            <p class="bottom-footer_sectionTitle__1QLFE">Contact Us</p>
            <div class="bottom-footer_addressWrapper__2uxg4">
                <div class="bottom-footer_contactIcon__Im-1Q"><svg aria-hidden="true" focusable="false"
                        data-prefix="fas" data-icon="map-marker-alt" class="svg-inline--fa fa-map-marker-alt fa-w-12 "
                        role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                        <path fill="currentColor"
                            d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z">
                        </path>
                    </svg></div>
                <p class="bottom-footer_address__2X3Qb"><span class="bottom-footer_addressHeading__2mkjA"> Madrasah
                        Address, Bangladesh</span><br>Village: Razapur,<br>Posrt Office: Khilpara,<br>Police Station: Hajigonj,<br>District: Chandpur</p>
            </div>
            <div class="bottom-footer_phoneEmail__-tODL">
                <div class="bottom-footer_contactUsDiv__2e8Iv">
                    <div class="bottom-footer_contactIcon__Im-1Q"><svg aria-hidden="true" focusable="false"
                            data-prefix="fas" data-icon="phone-alt" class="svg-inline--fa fa-phone-alt fa-w-16 "
                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path fill="currentColor"
                                d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z">
                            </path>
                        </svg></div><a id="Help for Orphans and HelplessPhoneNumber" href="<?php echo e(url('tel:+8801891533721')); ?>"
                        class="bottom-footer_contactLink__176D_">+880 1891533721</a>
                </div>
                <div class="bottom-footer_contactUsDiv__2e8Iv">
                    <div class="bottom-footer_contactIcon__Im-1Q"><svg aria-hidden="true" focusable="false"
                            data-prefix="fas" data-icon="envelope" class="svg-inline--fa fa-envelope fa-w-16 "
                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path fill="currentColor"
                                d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z">
                            </path>
                        </svg></div><a id="Help for Orphans and HelplessEmailId" href="mailto:info@Help for Orphans and Helpless.com"
                        class="bottom-footer_contactLink__176D_">info@rshnm.org</a>
                </div>
            </div>
            <div class="bottom-footer_contactUsDiv__2e8Iv">
                <div class="bottom-footer_contactIcon__Im-1Q"><svg aria-hidden="true" focusable="false"
                        data-prefix="fas" data-icon="file-alt" class="svg-inline--fa fa-file-alt fa-w-12 " role="img"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                        <path fill="currentColor"
                            d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z">
                        </path>
                    </svg></div><a id="enquire" to="<?php echo e(url('#')); ?>" class="bottom-footer_contactLink__176D_"
                    href="<?php echo e(url('#')); ?>">Send Us An Inquiry</a>
            </div>
            
            <div class="bottom-footer_paymentCards__3-Nha">
                <img class="gm-observing gm-observing-cb lazyloaded" alt="Help for Orphans and Helpless - Secure Payment Methods"
                    loading="lazy" src="<?php echo e(asset('_next/images/VisaCard.jpg')); ?>">
                    
                    
                    <img class="gm-observing gm-observing-cb lazyloaded" alt="Help for Orphans and Helpless - Payment Methods - Master Card"
                    loading="lazy" src="<?php echo e(asset('_next/images/masterCard.jpg')); ?>">                  
                    
                    
                    <img class="gm-observing gm-observing-cb lazyloaded"
                    alt="Help for Orphans and Helpless - Payment Methods - American Express" loading="lazy"
                    src="<?php echo e(asset('_next/images/AmeriacanEx.jpg')); ?>">
            </div>
        </div>
    </div>

</footer><a id="whatsappChatIcon"
    href="<?php echo e(url('#')); ?>"
    class="chat-on-whatsapp_whatsappChat__3i3wa"><img
        data-src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMEAAAA8CAYAAADfTt5bAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAD0VJREFUeNrsXQlYFdUe/4Moi4oIIiouqCAuWbhkWCaY+lnac3uVWq/EFtfyYbZqz8dXabZYZL1XuSTabplLfaalCak9Ec3dXFFwRRABBWR/53eYGWbuOvdyR4HOj2++e5l758ycc/6//3b+M9etoqKCXIlu69wi2Es020LYFkECAq5DDtv2SlvioeEVOa5o1M0VJGCCD4GPkbZ2Yq4EbhDWsi2BkWHNTSMBE34/9hLPtvFiPgRuItLYFussGZwmASNALHuJY1sTMQcCNQRJ8EYYGU4bSgJJ+4NxUWLMBWogciWrkKD3AHcngt69ggACNRjwTJYxWY13uSWQCJAo3B+BWoTlzCLEuMQSCAII1FKMZ7KbUG0SqGIAQQCB2kqE2OpaAhBA5P4FajPeY0SIdooE7MA4EQQL1BGskbwa/SSQVoH/LcZOoI4A7ny8o5YgQYybQB2MD8zcIg8rViD6ZrlBQ4PHUg//ftTCuzU1ru9HxWXXKbPoIv2RvY1+Pv8dXS3JEVMpUB3AxdcQweI6ASMBFsRuu1FXNaPrfLonaDgFMcFv6NHY6veKy4voctElTojX9k8VhBBwFgMODa9ItEoCyQpsuVHCP7JNDDXzDHL42PzSq5Sc9SvN2hMjyCDgKJIYCaJtkQAp0RFGXkErn3b0ad9fqU3DDhaF+9L181ywi8qvk6e7F3nW86LmXsHUtEEzs+/nFGfRy3vG028Z68XUCjiCHowIe81IIGWEThl55l4Bd9PHkevJp14jjZtzJj+VvktfTCtOvmf12P5BQ2lKpzkU6ttNc3xJeTF9cnwufXT0VTG1AnqhlFSYBsYjjSbA+7d/rxHgLBb0vnlwBq0/97Xd46HtsXXyvZXm91hB4U0qw5b67g1oYtgs/l4QQUAnRlp0h4wMiJHp2TT4NDXyqKq++CN7Oz26rZ/TbU4Jn0OTwmZzEsgWYXrKKOEa2cHtzSrd4SO5e//q8RQPkBUSSKtpV4w627oBh6lj4y7K/6vSltKcfU9Wu937gsfQG8wqyES4VppLg34JqfbkyoKCdiAs1j4/X3CazrGtNmH7vVnk1yCApiUPp8SMH3SNQ23spw68z0gQq14sizbqTI91nKEhwMGcFA0B4N7M7ZFAD7ab6HDbP537hscDMmBpPuyz1ulrfbvXl8xipVHCnVv4tipqD60ZcIAGttB6ivMilvHPnwp7uU6ryjrez2jTmMCwJ0NMZcGsOpsz5rc+GpcG/nwDd0+6r9UYyi/N0xUfqIE4YHCL0UqMcFvTSE6sY3n7HWpnVdRe6tzE3BsMa3wLvRqxhLwPNqIfz37O9xWWFRgyVt/230UV7G/OvqcsWiBXIHbXA4o7JOM/d/xATeo3pV8vrqVPT7yt7DeqnzUEfLINtwTQ7ogHZMw98IwmTpjQ8TlOAACp0CdCX3TqPON/j+bpVTlQfqazYwHy46HPU1spZZtTfJnWnllOs/dMoP9lbqLM6xe4+zCz65uavhiBjr7dqJtfb2rh1cawc6RkJfJN7TK28elAPfzvolv8bv9LBQVYF1NbghAjTjI2ZIry/mLhGY2WfzLsJbMV4g7MbYKgOerT4/v7ruygOwMHV3aOCZIjGBcylXzYtZy+dowm7hii+L9rziTwBb3pXV6jIK/W3FqtTPvE7PhgnxBqxTZbwSb61blJhEUfG/vVBAvz7U75ZVcttqduB8Jsut80jpHblverA2Nfth/X7eFen+/z92zOP7cWA+jpp+l3LcVVtoLzGxyHhKhJYMg9AyiFkLH5gvaJGF18zT0wWIXpnV9nFuNph8/18bHXFBIEeQXzlOzuy1t1HduofmXWav25r8wGfvPFNYpPHBk4UEMCuEq/DDrFJxtAWUdy1mZ6fvfDmjaW3rmJfbc7BTAhk63N5aIMemTbXVwIXr1tsYa4sV3m0nXmikxOHqYRdDmGWhS5gYrLr9PoxAjlet/q+QVfS4HwDN7UXvn+gl7fUEijTrSDXdcTvw+i+N7fKYHx8DaP0pBWD1YJYEAUjwG+TVtEcfsmOdxPNWZ2fYu3jRhQ7QIDiyM3coutDs5hjaGM5HMAJ68ephf+eMQw1xAkcJdMgiFWAJpAvcq7PPVdzecojLOEMwUnnTofBD7j+jnl//5Bw3RngqAJC5g7tfNyokUrM3P3GIr5fQAtOPyC1pwywVVPGoT8nhYj6P7W/1D2Len7C0U2G6gQAIAQdmzclT7tu8mJfv7GCYQkwCPtq9zLtg1D+SssWrB0TbAA/p6BVFB2jb5M/ZDvQyrZYbdBRz+tobAs32xfOftTA21P6jRbcw7uHrIxmt/zM0MtgbuRrlBk4CDlPYTTVMNuPL/S7JhdbIJtrRrbQ0bhWZuWxirsPHAAmgga2bQPEEZYD8QPq9MT+P9e9XxoVNsY5TuhjbvRnuztlHI5iabvHMW/Cw0HtJbiEATCIBlKRYD4P2dzK2BNA6blH+ev3ZveoSgcEKusopS/PhFaSVa4b74s4M0tzuYWzRQgNc4rt4drxP+Lj7/hcD+rA1hCkPpsQSpfPMU44VqQKIEVCvc1rJ4zxMNIismaCcDkmAKLWsgW+amsxbqz1WO9LESyFjQaqGiVXQLED5/128a0ZBCveVIyDj+30vjIeaU53AWAlpPXN0yF/XjeATM3SI3tlzZy69LSuzKAhtBD+PNKrnCh78lcQWBIcKWrc4HFY5ZwTvK7S8tL+P/ZzM2xdF49/awOPOt5K9koXA8Ii21aeJzhc+huZOPNPFtoXApLUGeLgGe7vOEy4VUTwi7c3Gx+jOASblOwibmWM1L2jl0/8BitG3BIWX+Qs2AVFeXOpVLTFvOFQQg+2peFHhr8QmE6BXq25NcaIFXobrm4tlpjqaef1UH8n7P4fEHrL+yzmq/VrOyfQu5u9WhFajwdzdtXO0mQpfL5rQk2skVHc/epfOVmXEhcol10ailoPmhC+NJ9AqItZnUQXOK6nraTei0qKzTbt5T5/e0ahnH3wVWAUkm/doK86zXkRYUQegg/yAGtD3IgmEeCAEH4xvPfunRuLfXTGhp72FdqiHO+PvVf3gegpXdbHodM7vQKszpbDSWgoSRIzz+hvK/nZt3zQo4fWk2tOb+6e4cZcd7p9TUtvyvJTBur4asacEfSrNlFmfx1aPA4s/axWuzt4cODy+2XfnZoDKaG/5sLJHzopIwfuU8Nnxs+f3VxIGcnf+0d0J+fA8KPPsta/77gsdw1AgluRsmDbIk9mMunHlPMr6kFRPLgVhbfoCweY4S6skM5u5SYIKbjzNpJgh2ZVZkPaCRrwouJm5r8N15SLQMD8uM9R/jtlgB8UNQJYcJXR++nD/qssWhd/Dyr4os/8/Sn1ValL+HZIaQSV/bfRfN6VK4PYHJiu8zjawSXCs8rK8Z64S9lhMrZpO/I3Mz7enfze+mhdk/ZPO6hkIn8/LawMm0Rz7z4eDTSuDywBkhhypbwxNVDuq8XQTxIb0vR6MXWjJ+kNrvyshi0Cx//3d4rzawizovFurhbP+FrFwuPvEIHGQkKSvMl1zrIcBIYUkoI7ZNbkq38P7nTv2ymN18/8LSGCOj4272+oqQhF6knGyAZWGBDeg55azWwLgCyKUJy+mPd14pSgfT8VCV9OaLNeDZxy6hv4CAK9GrJtWnc/kkOjwHaRZ/Qxou3vMf9XcQDTT0DNSlaGXnFlTWMUUH30+zuC20KI4LpswWn+NoKLCmEX1YqyPYg6AZJPjpmf/U8t+SKkpLENarXDpwFskm4QYr3MSCKtwvLCNfQNF5LOLmgMlXDlBDGCa7nmJDJyti/Y5KadiFyOAnkO2yMwPG8g1WTHWD73v1VaUtoFjOHatfIlhYoMMk/v9BtgfL+TEGqwy7A35Mi+MShTEIGFqyw0o16G3XWxNuOfy+XgmDhCiUY0Mwy0D6qaNFPxCHtG4ZrhEE+f3F5sd0kAdws7nqy+EDt/h24ksxfr5XkmWWe5IyUGq/vn6b44+hzQw9fh/ppDVOSh/FVeBnoMxbtCkvzzUhgOvYAjoV7ZCD2qkupMYIuf9Qi3BlocxnP7x5nt0DO1u2XaiCgHp0UoaQf4SbJZRgoBHtmp/P3CNlburf2ubVSAUslDbbOYat0QQ35fKbftVZCoT6vpZIFuRzD3jXaKomwNZ6yItFTNqG37WpihpoEuDpDHrMCd0bW5lgXuHdzmK6gFQR6tEMsnxi1xkG6DvlsaGd5kL6P2qtUkSKAHbmle12sfxdwPQaoA2PDKLf0xJuaFKjeoAsWY9zWSOq/sQV9kfoB1/xYJHr38EuMSKEKAVCOHa4qgUYAKgggoNcd8rgRJFCX5yKN56iJg9WYd3C6ZZ9TusVSiXKYpcFjWAQEdCANv4CpJkGiUWfq6V91H/Gpa0dc1u7s7h/SA+2eVAI9ZGGmp4wWzyES0Asu84o7JP3YmcvXplH2K9e3ACh3BnCzDRa+Ngw6qawFONLmhoEn6eH205RYAZWRi47P0106LSBAlT87YPa0CTy195+uPMtbvb6kYcHj+HsstR/ISeG5aNMHaZ3JP0lrz66gz1MXWtXkIM7oto+bBcqwACCAeNyKgINoCnfI8IdvbRqcrrEE9gCBvsL8enXJBQrxmnu1svic0qyiDHp214PCAgg4CssP34JLxIgAl8glxdumrpCpsJ/NTyXfBv6axTBoeKz6qld+LQFpUpRiP7d7rJhOAaddITMSSIBLtMwVZ8E9xKaCC7dnW+ZGWnJ8vuL24JEsI1o/Rm0bhWqeTmeJOLhpBsL/wdE5IgAWcBbICikksPZodgTJ1b7nOHloDrmx2BuCv+niapv+vgzUzPQM6Ke5F6Gg9Brtyd5GWy9tEIIv4ApMUP/YtzUSxLjCGiCQxQ3bAgI1zAqEqHdY/TFvV1kDAYGabAUAW/cTxIjxEqhjSDIlgE0SSD9n874YN4E6glxrit3enWVxZMAqsoDATUCsVBXhGAmwmiaxJ1eMoUAtxnJLbpDdwNgkSI6mG/RjfgICBsQB0ba+oOtGeyk+mCDGU6CWAa683dsLdT9tQjIno4RrJFBLgEdvREsuvU3ocodMXCPchIolZ7GGIFBTwX+GSe+XHX7ukPRkChBBpE8FahrSqPLH+GIdOchhS2AhYI4jg27QFxDQCbjoKPyM1+P+uJQEJmQA+0aI+RC4wZo/wVnhdykJVGTwk6JxkCJEWAgBA4T+NFXeG7zGVQ+N+78AAwBpLz7A1qV6zgAAAABJRU5ErkJggsQwS+kBvM3RBobUITUY3oC5uzKGILlWgVcThrBRfBYCgKELH6SONX3YtUTiD4gGw5EjJssYpURCIIDBDGGwaoK+RGIEqOhYkKG/8jGi/rjilxAIIAxYNNXq/4QvkahBy98rZkCJK7/AFCEQQE3Cktr4r4BYp0b2EBIzQaVHwAvqDoZCm7NCCtEf9WyK/YTKziAAAAAASUVORK5CYII="
        class="lazyloaded gm-observing gm-observing-cb" height="35" alt="Chat With Help for Orphans and Helpless Support"
        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMEAAAA8CAYAAADfTt5bAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAD0VJREFUeNrsXQlYFdUe/4Moi4oIIiouqCAuWbhkWCaY+lnac3uVWq/EFtfyYbZqz8dXabZYZL1XuSTabplLfaalCak9Ec3dXFFwRRABBWR/53eYGWbuOvdyR4HOj2++e5l758ycc/6//3b+M9etoqKCXIlu69wi2Es020LYFkECAq5DDtv2SlvioeEVOa5o1M0VJGCCD4GPkbZ2Yq4EbhDWsi2BkWHNTSMBE34/9hLPtvFiPgRuItLYFussGZwmASNALHuJY1sTMQcCNQRJ8EYYGU4bSgJJ+4NxUWLMBWogciWrkKD3AHcngt69ggACNRjwTJYxWY13uSWQCJAo3B+BWoTlzCLEuMQSCAII1FKMZ7KbUG0SqGIAQQCB2kqE2OpaAhBA5P4FajPeY0SIdooE7MA4EQQL1BGskbwa/SSQVoH/LcZOoI4A7ny8o5YgQYybQB2MD8zcIg8rViD6ZrlBQ4PHUg//ftTCuzU1ru9HxWXXKbPoIv2RvY1+Pv8dXS3JEVMpUB3AxdcQweI6ASMBFsRuu1FXNaPrfLonaDgFMcFv6NHY6veKy4voctElTojX9k8VhBBwFgMODa9ItEoCyQpsuVHCP7JNDDXzDHL42PzSq5Sc9SvN2hMjyCDgKJIYCaJtkQAp0RFGXkErn3b0ad9fqU3DDhaF+9L181ywi8qvk6e7F3nW86LmXsHUtEEzs+/nFGfRy3vG028Z68XUCjiCHowIe81IIGWEThl55l4Bd9PHkevJp14jjZtzJj+VvktfTCtOvmf12P5BQ2lKpzkU6ttNc3xJeTF9cnwufXT0VTG1AnqhlFSYBsYjjSbA+7d/rxHgLBb0vnlwBq0/97Xd46HtsXXyvZXm91hB4U0qw5b67g1oYtgs/l4QQUAnRlp0h4wMiJHp2TT4NDXyqKq++CN7Oz26rZ/TbU4Jn0OTwmZzEsgWYXrKKOEa2cHtzSrd4SO5e//q8RQPkBUSSKtpV4w627oBh6lj4y7K/6vSltKcfU9Wu937gsfQG8wqyES4VppLg34JqfbkyoKCdiAs1j4/X3CazrGtNmH7vVnk1yCApiUPp8SMH3SNQ23spw68z0gQq14sizbqTI91nKEhwMGcFA0B4N7M7ZFAD7ab6HDbP537hscDMmBpPuyz1ulrfbvXl8xipVHCnVv4tipqD60ZcIAGttB6ivMilvHPnwp7uU6ryjrez2jTmMCwJ0NMZcGsOpsz5rc+GpcG/nwDd0+6r9UYyi/N0xUfqIE4YHCL0UqMcFvTSE6sY3n7HWpnVdRe6tzE3BsMa3wLvRqxhLwPNqIfz37O9xWWFRgyVt/230UV7G/OvqcsWiBXIHbXA4o7JOM/d/xATeo3pV8vrqVPT7yt7DeqnzUEfLINtwTQ7ogHZMw98IwmTpjQ8TlOAACp0CdCX3TqPON/j+bpVTlQfqazYwHy46HPU1spZZtTfJnWnllOs/dMoP9lbqLM6xe4+zCz65uavhiBjr7dqJtfb2rh1cawc6RkJfJN7TK28elAPfzvolv8bv9LBQVYF1NbghAjTjI2ZIry/mLhGY2WfzLsJbMV4g7MbYKgOerT4/v7ruygOwMHV3aOCZIjGBcylXzYtZy+dowm7hii+L9rziTwBb3pXV6jIK/W3FqtTPvE7PhgnxBqxTZbwSb61blJhEUfG/vVBAvz7U75ZVcttqduB8Jsut80jpHblverA2Nfth/X7eFen+/z92zOP7cWA+jpp+l3LcVVtoLzGxyHhKhJYMg9AyiFkLH5gvaJGF18zT0wWIXpnV9nFuNph8/18bHXFBIEeQXzlOzuy1t1HduofmXWav25r8wGfvPFNYpPHBk4UEMCuEq/DDrFJxtAWUdy1mZ6fvfDmjaW3rmJfbc7BTAhk63N5aIMemTbXVwIXr1tsYa4sV3m0nXmikxOHqYRdDmGWhS5gYrLr9PoxAjlet/q+QVfS4HwDN7UXvn+gl7fUEijTrSDXdcTvw+i+N7fKYHx8DaP0pBWD1YJYEAUjwG+TVtEcfsmOdxPNWZ2fYu3jRhQ7QIDiyM3coutDs5hjaGM5HMAJ68ephf+eMQw1xAkcJdMgiFWAJpAvcq7PPVdzecojLOEMwUnnTofBD7j+jnl//5Bw3RngqAJC5g7tfNyokUrM3P3GIr5fQAtOPyC1pwywVVPGoT8nhYj6P7W/1D2Len7C0U2G6gQAIAQdmzclT7tu8mJfv7GCYQkwCPtq9zLtg1D+SssWrB0TbAA/p6BVFB2jb5M/ZDvQyrZYbdBRz+tobAs32xfOftTA21P6jRbcw7uHrIxmt/zM0MtgbuRrlBk4CDlPYTTVMNuPL/S7JhdbIJtrRrbQ0bhWZuWxirsPHAAmgga2bQPEEZYD8QPq9MT+P9e9XxoVNsY5TuhjbvRnuztlHI5iabvHMW/Cw0HtJbiEATCIBlKRYD4P2dzK2BNA6blH+ev3ZveoSgcEKusopS/PhFaSVa4b74s4M0tzuYWzRQgNc4rt4drxP+Lj7/hcD+rA1hCkPpsQSpfPMU44VqQKIEVCvc1rJ4zxMNIismaCcDkmAKLWsgW+amsxbqz1WO9LESyFjQaqGiVXQLED5/128a0ZBCveVIyDj+30vjIeaU53AWAlpPXN0yF/XjeATM3SI3tlzZy69LSuzKAhtBD+PNKrnCh78lcQWBIcKWrc4HFY5ZwTvK7S8tL+P/ZzM2xdF49/awOPOt5K9koXA8Ii21aeJzhc+huZOPNPFtoXApLUGeLgGe7vOEy4VUTwi7c3Gx+jOASblOwibmWM1L2jl0/8BitG3BIWX+Qs2AVFeXOpVLTFvOFQQg+2peFHhr8QmE6BXq25NcaIFXobrm4tlpjqaef1UH8n7P4fEHrL+yzmq/VrOyfQu5u9WhFajwdzdtXO0mQpfL5rQk2skVHc/epfOVmXEhcol10ailoPmhC+NJ9AqItZnUQXOK6nraTei0qKzTbt5T5/e0ahnH3wVWAUkm/doK86zXkRYUQegg/yAGtD3IgmEeCAEH4xvPfunRuLfXTGhp72FdqiHO+PvVf3gegpXdbHodM7vQKszpbDSWgoSRIzz+hvK/nZt3zQo4fWk2tOb+6e4cZcd7p9TUtvyvJTBur4asacEfSrNlFmfx1aPA4s/axWuzt4cODy+2XfnZoDKaG/5sLJHzopIwfuU8Nnxs+f3VxIGcnf+0d0J+fA8KPPsta/77gsdw1AgluRsmDbIk9mMunHlPMr6kFRPLgVhbfoCweY4S6skM5u5SYIKbjzNpJgh2ZVZkPaCRrwouJm5r8N15SLQMD8uM9R/jtlgB8UNQJYcJXR++nD/qssWhd/Dyr4os/8/Sn1ValL+HZIaQSV/bfRfN6VK4PYHJiu8zjawSXCs8rK8Z64S9lhMrZpO/I3Mz7enfze+mhdk/ZPO6hkIn8/LawMm0Rz7z4eDTSuDywBkhhypbwxNVDuq8XQTxIb0vR6MXWjJ+kNrvyshi0Cx//3d4rzawizovFurhbP+FrFwuPvEIHGQkKSvMl1zrIcBIYUkoI7ZNbkq38P7nTv2ymN18/8LSGCOj4272+oqQhF6knGyAZWGBDeg55azWwLgCyKUJy+mPd14pSgfT8VCV9OaLNeDZxy6hv4CAK9GrJtWnc/kkOjwHaRZ/Qxou3vMf9XcQDTT0DNSlaGXnFlTWMUUH30+zuC20KI4LpswWn+NoKLCmEX1YqyPYg6AZJPjpmf/U8t+SKkpLENarXDpwFskm4QYr3MSCKtwvLCNfQNF5LOLmgMlXDlBDGCa7nmJDJyti/Y5KadiFyOAnkO2yMwPG8g1WTHWD73v1VaUtoFjOHatfIlhYoMMk/v9BtgfL+TEGqwy7A35Mi+MShTEIGFqyw0o16G3XWxNuOfy+XgmDhCiUY0Mwy0D6qaNFPxCHtG4ZrhEE+f3F5sd0kAdws7nqy+EDt/h24ksxfr5XkmWWe5IyUGq/vn6b44+hzQw9fh/ppDVOSh/FVeBnoMxbtCkvzzUhgOvYAjoV7ZCD2qkupMYIuf9Qi3BlocxnP7x5nt0DO1u2XaiCgHp0UoaQf4SbJZRgoBHtmp/P3CNlburf2ubVSAUslDbbOYat0QQ35fKbftVZCoT6vpZIFuRzD3jXaKomwNZ6yItFTNqG37WpihpoEuDpDHrMCd0bW5lgXuHdzmK6gFQR6tEMsnxi1xkG6DvlsaGd5kL6P2qtUkSKAHbmle12sfxdwPQaoA2PDKLf0xJuaFKjeoAsWY9zWSOq/sQV9kfoB1/xYJHr38EuMSKEKAVCOHa4qgUYAKgggoNcd8rgRJFCX5yKN56iJg9WYd3C6ZZ9TusVSiXKYpcFjWAQEdCANv4CpJkGiUWfq6V91H/Gpa0dc1u7s7h/SA+2eVAI9ZGGmp4wWzyES0Asu84o7JP3YmcvXplH2K9e3ACh3BnCzDRa+Ngw6qawFONLmhoEn6eH205RYAZWRi47P0106LSBAlT87YPa0CTy195+uPMtbvb6kYcHj+HsstR/ISeG5aNMHaZ3JP0lrz66gz1MXWtXkIM7oto+bBcqwACCAeNyKgINoCnfI8IdvbRqcrrEE9gCBvsL8enXJBQrxmnu1svic0qyiDHp214PCAgg4CssP34JLxIgAl8glxdumrpCpsJ/NTyXfBv6axTBoeKz6qld+LQFpUpRiP7d7rJhOAaddITMSSIBLtMwVZ8E9xKaCC7dnW+ZGWnJ8vuL24JEsI1o/Rm0bhWqeTmeJOLhpBsL/wdE5IgAWcBbICikksPZodgTJ1b7nOHloDrmx2BuCv+niapv+vgzUzPQM6Ke5F6Gg9Brtyd5GWy9tEIIv4ApMUP/YtzUSxLjCGiCQxQ3bAgI1zAqEqHdY/TFvV1kDAYGabAUAW/cTxIjxEqhjSDIlgE0SSD9n874YN4E6glxrit3enWVxZMAqsoDATUCsVBXhGAmwmiaxJ1eMoUAtxnJLbpDdwNgkSI6mG/RjfgICBsQB0ba+oOtGeyk+mCDGU6CWAa683dsLdT9tQjIno4RrJFBLgEdvREsuvU3ocodMXCPchIolZ7GGIFBTwX+GSe+XHX7ukPRkChBBpE8FahrSqPLH+GIdOchhS2AhYI4jg27QFxDQCbjoKPyM1+P+uJQEJmQA+0aI+RC4wZo/wVnhdykJVGTwk6JxkCJEWAgBA4T+NFXeG7zGVQ+N+78AAwBpLz7A1qV6zgAAAABJRU5ErkJggsQwS+kBvM3RBobUITUY3oC5uzKGILlWgVcThrBRfBYCgKELH6SONX3YtUTiD4gGw5EjJssYpURCIIDBDGGwaoK+RGIEqOhYkKG/8jGi/rjilxAIIAxYNNXq/4QvkahBy98rZkCJK7/AFCEQQE3Cktr4r4BYp0b2EBIzQaVHwAvqDoZCm7NCCtEf9WyK/YTKziAAAAAASUVORK5CYII="
        loading="lazy"></a>

<section id="copyrights" class="copy-rights_copyrights__EWZfA">
    <div class="copy-rights_copyRightText__1OL99">&copy; 2023 RSHNM | All rights reserved.</div>
    <div class="copy-rights_termsAndPolicy__2EELw"><a to="<?php echo e(url('#')); ?>"
        title="Explore Help for Orphans and Helpless's Terms Of Using Crowdfunding Platform For Online Donations"
        href="<?php echo e(url('#')); ?>">Terms of Use</a> | <a to="<?php echo e(url('#')); ?>"
        title="Read Help for Orphans and Helpless'S Privacy Policies About Online Donations, Data Safety &amp; Security"
        href="<?php echo e(url('#')); ?>">Privacy Policy</a></div>
</section> <?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/donate_footer.blade.php ENDPATH**/ ?>