<!--  -->
<footer>
    <div class="bottom-bar">
        <div class="container">
            <div class="row">
                <small class="copyright col-md-6 col-sm-12 col-xs-12">
                    Copyright &copy; রাজাপুর ছিদ্দিকিয়া হাফিজিয়া নূরানী মাদ্রাসা-2023; Developed by
                    <a href="<?php echo e(url('#')); ?>">SohagTech</a>
                </small>

                <ul class="social pull-right col-md-4 col-sm-12 col-xs-12">
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-youtube"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-pinterest"></i></a></li>
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-skype"></i></a></li>
                    <li class="row-end"><a href="#"><i class="fa fa-rss"></i></a></li>
                </ul><!--//social-->
            </div><!--//row-->
        </div><!--//container-->
    </div><!--//bottom-bar-->
</footer><!--//footer--><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/footer.blade.php ENDPATH**/ ?>