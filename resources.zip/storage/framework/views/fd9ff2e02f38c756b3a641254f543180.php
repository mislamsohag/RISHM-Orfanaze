<section class="notice-box">
    <div class="col-md-3">
        <h1 class="section-heading text-highlight heading-bg"><span class="line">Official
                Notice</span></h1>
        <div class="section-content">
            <p>
                <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Form</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Academic Prospectus</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Result</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Tc Form</a>
            </p>
        </div>
    </div>
    <div class="col-md-3">
        <h1 class="section-heading text-highlight heading-bg"><span class="line">Research</span>
        </h1>
        <div class="section-content">
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Form</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Academic Prospectus</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Result</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Tc Form</a>
            </p>
        </div>
    </div>
    <div class="col-md-3">
        <h1 class="section-heading text-highlight heading-bg"><span class="line">Notice </span></h1>
        <div class="section-content">
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Form</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Academic Prospectus</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Result</a>
            </p>
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Tc Form</a>
            </p>
        </div>
    </div>
    <div class="col-md-3">
        <h1 class="section-heading text-highlight heading-bg"><span class="line">News &amp;
                Events</span></h1>
        <div class="section-content">
            <p>
            <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Form</a>
            </p>
            <p>
                <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Academic Prospectus</a>
            </p>
            <p>
                <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Admission Result</a>
            </p>
            <p>
                <a href="<?php echo e(url('#')); ?>"><i class="fa fa-angle-double-right"></i> Tc Form</a>
            </p>
        </div>
    </div>
</section><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Components/notice.blade.php ENDPATH**/ ?>