
<div class="col-md-12 noPrintShow">
	<div class="page-wrapper">
		<header class="page-heading clearfix">
			<h1 class="heading-title pull-left">Employees</h1>
			<div class="breadcrumbs pull-right">
				<ul class="breadcrumbs-list">
					<li class="breadcrumbs-label">You are here:</li>
					<li><a href="index.html">Home</a><i class="fa fa-angle-right"></i></li>
					<li class="current">Leadership Team</li>
				</ul>
			</div><!--//breadcrumbs-->
		</header>
	</div>
</div>
<div class="col-md-9">
	<div style="background: #FFF;" class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>#</th>
					<th>Picture</th>
					<th>Name</th>
					<th>Designation</th>
					<!--<th>E-mail</th>-->
					<th>Phone</th>
				</tr>
			</thead>
			<tbody>

				<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($employee['id']); ?></td>
					<td>
						<img src="<?php echo e($employee['image']); ?>" class="img-responsive img-circle profile-img"
							alt="">
					</td>

					<td><a href="javascript:"><b><?php echo e($employee['name']); ?></b></a></td>
					<td><?php echo e($employee['designation']); ?></td>
					<!--<td></td>-->
					<td><?php echo e($employee['phone']); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tbody>
		</table><!--//table-->
	</div><!--//table-responsive-->
</div>


<?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/employee.blade.php ENDPATH**/ ?>