

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Components.pages.admission.onlineAdmission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/admission.blade.php ENDPATH**/ ?>