<?php $__env->startSection('content'); ?>
<div class="content container">
	<div class="row cols-wrapper">
		<div class="col-md-12 noPrintShow">
			<div class="page-wrapper">
				<header class="page-heading clearfix">
					<h1 class="heading-title pull-left">Syllabus</h1>
					<div class="breadcrumbs pull-right">
						<ul class="breadcrumbs-list">
							<li class="breadcrumbs-label">You are here:</li>
							<li><a href="index.html">Home</a><i class="fa fa-angle-right"></i></li>
							<li class="current">Leadership Team</li>
						</ul>
					</div><!--//breadcrumbs-->
				</header>
			</div>
		</div>

		<div class="col-md-9">
			<div style="background: #FFF;" class="table-responsive">
				<table class="table table-bordered">
					<thead style="background: #002E5B;">
						<tr>
							<th style=" color: #FFF;">#</th>
							<th style=" color: #FFF;">Class</th>
							<th style=" color: #FFF;" width="350">Title</th>
							<th style=" color: #FFF;">Published Date</th>
							<th style=" color: #FFF;">Download</th>
						</tr>
					</thead>
					<tbody>
					<tbody>
						<?php $__currentLoopData = $syllabuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syllabus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($syllabus['id']); ?></td>
							<td><?php echo e($syllabus['class']); ?></td>
							<td><a href='javascript:;'><?php echo e($syllabus['syllabusTitle']); ?></a> <span
									class="label label-success"></span></td>
							<td><i class="fa fa-calendar"></i> <?php echo e($syllabus['date']); ?></td>

							<td>
								<a href="<?php echo e(asset('../results/3183608Jan2023.pdf')); ?>" target="_blank"
									class="btn btn-success btn-sm"><i class='fa fa-download'> &nbsp;<?php echo e($syllabus['download']); ?></i></a>
							</td>
						</tr>						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table><!--//table-->
			</div><!--//table-responsive-->
			<tr>
				<td colspan="6">

				</td>
			</tr>
		</div>

		<div class="col-md-3 noPrintShow">
			<?php echo $__env->make('pages.home.admissionSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('pages.home.downloadLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('pages.home.visitorsCount', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div><!--//cols-wrapper-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/pages/Syllabus/syllabus.blade.php ENDPATH**/ ?>