

<header class="header noPrintShow">
    <div class="top-bar"></div>
    <div class="header-main container">
        <h1 class="logo col-md-6 col-sm-6">
            <a href="javascript:;"><img style="height: 80px; width: 80px;" src="<?php echo e(asset('images/institute/RSIHNM.png')); ?>" alt="Logo">
                <h3 style="line-height: 30px;">RAZAPUR SIDDIQIA ISLAMIA HAFIZIA MADRASAH</h3>
            </a>
        </h1>

        <div class="info col-md-6 col-sm-6">
            <ul class="menu-top navbar-right hidden-xs">
                <li class="nav-item btn btn-lg" style="background:#68B4F8"><a style="" href="#" target="_blank">Student
                        Portal</a>
                </li>
                <li class="nav-item btn btn-lg" style="margin-left:2px; background:#68B4F8;"><a href="#"
                        target="_blank">Mark
                        Entry</a></li>
            </ul>
            <br />
            <div class="panel-link pull-right">
            </div><br />

            <div class="contact-us pull-right">
                <p class="phone"><i class="fa fa-phone"></i> Call us today 01812060163</p>
                <p class="email"><i class="fa fa-envelope"></i><a href="#">
                        info@rsihm.edu.bd</a></p>
            </div>
        </div>
    </div>
</header><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Layout/header.blade.php ENDPATH**/ ?>