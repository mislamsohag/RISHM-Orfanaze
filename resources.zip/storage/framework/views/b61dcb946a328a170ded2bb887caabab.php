

<footer class="footer noPrintShow">
    <div class="bottom-bar">
        <div class="container">
            <div class="row">
                <small class="copyright col-md-6 col-sm-12 col-xs-12">Copyright @ 2023 Developed by <a
                        href="<?php echo e(url('#')); ?>">UNITECH IT</a></small>
                <ul class="social pull-right col-md-6 col-sm-12 col-xs-12">
                    <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-facebook"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Layout/footer.blade.php ENDPATH**/ ?>