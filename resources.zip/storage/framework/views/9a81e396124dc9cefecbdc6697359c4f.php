<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <title>RSIHM</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.html">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/nivoSlider/default.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/nivo-slider.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/prettyPhoto.css')); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(asset('css/flexslider.css')); ?>">


    <script src="<?php echo e(asset('js/jquery-1.11.2.min.js')); ?>"></script>

    <style>
        @media print {
            .noPrintShow {
                display: none !important;
                visibility: hidden;
            }

            .printShow {
                border: 2px solid #c2c2c2;
                padding-top: 10px;
                padding-right: 15px;
                width: 100% !important;
                margin-top: 140px
            }

            @page {
                size: landscape
            }

            .header,
            .hide {
                visibility: hidden
            }
        }
    </style>
</head>

<body class="home-page">
    <div class="wrapper">
        <header class="header noPrintShow">
            <div class="top-bar"></div>
            <div class="header-main container">
                <h1 class="logo col-md-6 col-sm-6">
                    <a href="javascript:;"><img src="public/images/institute/29535.gif" alt="Logo">
                        <h3 style="line-height: 30px;">RAZAPUR SIDDIQIA ISLAMIA HAFIZIA MADRASAH</h3>
                    </a>
                </h1>

                <div class="info col-md-6 col-sm-6">
                    <ul class="menu-top navbar-right hidden-xs">
                        <li class="nav-item btn btn-lg" style="background:#68B4F8"><a style=""
                                href="#" target="_blank">Student Portal</a>
                        </li>
                        <li class="nav-item btn btn-lg" style="margin-left:2px; background:#68B4F8;"><a
                                href="#" target="_blank">Mark
                                Entry</a></li>
                    </ul>
                    <br />
                    <div class="panel-link pull-right">
                    </div><br />

                    <div class="contact-us pull-right">
                        <p class="phone"><i class="fa fa-phone"></i> Call us today 01711142942</p>
                        <p class="email"><i class="fa fa-envelope"></i><a href="#">
                                info@falahiaChandpur.edu.bd</a></p>
                    </div>
                </div>
            </div>
        </header>
    </div>
</div>
<!-- Header -->






<!-- Footer -->
    <footer class="footer noPrintShow">
        <div class="bottom-bar">
            <div class="container">
                <div class="row">
                    <small class="copyright col-md-6 col-sm-12 col-xs-12">Copyright @ 2023 Developed by <a
                            href="<?php echo e(url('#')); ?>">UNITECH IT</a></small>
                    <ul class="social pull-right col-md-6 col-sm-12 col-xs-12">
                        <li><a href="<?php echo e(url('#')); ?>"><i class="fa fa-facebook"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/jquery-migrate-1.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-hover-dropdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/back-to-top.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.placeholder.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jflickrfeed/jflickrfeed.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.scrollbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nivo.slider.js')); ?>"></script>

</body>
<script>
    $(window).load(function () {
        $('#slider').nivoSlider();
    });

    $(function () {
        $(window).bind('scroll', function () {
            var navHeight = $(".header").height();
            ($(window).scrollTop() > navHeight) ? $('nav').addClass('goToTop') : $('nav').removeClass('goToTop');
        });
        //===============================		
        /*
         * Content Slider
        */
        $('#content-slider').scrollbox({
            direction: 'h',
            distance: 134
        });
        $('#slider-backward').click(function () {
            $('#content-slider').trigger('backward');
        });
        $('#slider-forward').click(function () {
            $('#content-slider').trigger('forward');
        });
        //===============================


        //========Active nav bar===========  
        var url = window.location;
        // Will only work if string in href matches with location
        $('ul.nav li a[href="' + url + '"]').parent().addClass('active');

        // Will also work for relative and absolute hrefs
        $('li.dropdown ul.dropdown-menu a').filter(function () {
            return this.href == url;
        }).parent().addClass('active').parent().parent().addClass('active');

    });
</script>

</html><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Layout.blade.php ENDPATH**/ ?>