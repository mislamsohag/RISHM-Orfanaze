
<section class="widget has-divider">
    <h3 class="title">Admission on Online</h3>
    <a class="btn btn-theme" href="<?php echo e(url('admission/onlineAdmission')); ?>"><i class="fa fa-arrow-circle-right"></i>Apply Now</a>
</section><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/pages/home/admissionSection.blade.php ENDPATH**/ ?>