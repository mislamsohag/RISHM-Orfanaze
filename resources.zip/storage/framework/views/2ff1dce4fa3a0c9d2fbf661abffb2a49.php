<section class="history">
    <h1 class="section-heading text-highlight"><span class="line">RAZAPUR SIDDIQIA ISLAMIA HAFIZIA MADRASAH</span></h1>
    <figure class="thumb col-md-6 col-sm-6 col-xs-6">
        <img src="<?php echo e(asset('images/history/44788.jpg')); ?>" class="img-responsive img-resize" alt="Image">
    </figure>
    <div class="section-content">
        <p class="description">
        <div><big>T</big>he renowned madrasah of Chandpur district is Razapur Siddiqia Islamia Hafizia Madrasah
             was founded in 1970. It is one of the famous educational institute in Chandpur
            district. Modern education system, strict rules and regulation, minimum costing, highly
            educated and trained teachers supervised the madrasah. The madrasah is situated in Chandpur
            Sadar with own land and it&rsquo;s natural beauty is suitable for students. In present
            time there are upto Kamil class in this institute. In the scholarship and Madrasah board
            examination the madrasah has good reputation, and Last 10 years in Bangladesh.</div>
        </p>
    </div><!--//section-content-->
</section><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Components/history.blade.php ENDPATH**/ ?>