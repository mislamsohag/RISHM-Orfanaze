<!DOCTYPE html>
<html>
	<head>
		<link media="all" type="text/css" rel="stylesheet" href="http://202.5.38.86/ems/public/css/bootstrap.min.css">
 
	<link media="all" type="text/css" rel="stylesheet" href="http://202.5.38.86/ems/public/css/ui-lightness/jquery-ui-1.10.0.custom.min.css">

	<script src="http://202.5.38.86/ems/public/js/libs/jquery-1.9.1.min.js"></script>

	<script src="http://202.5.38.86/ems/public/js/jquery.validate.min.js"></script>
 
	<script src="http://202.5.38.86/ems/public/js/jquery.customValidation.js"></script>
 
	<script src="http://202.5.38.86/ems/public/js/libs/jquery-ui-1.10.0.custom.min.js"></script>

		
	<style type="text/css">
		body{
			padding: 0px !important;
		}
		label{
			font-size: 12px;
			color: black;
			font-weight: bold;
			font-family: sans-serif;
		}
		.container{
			width: 1024px;
			box-shadow: 0px 20px 10px #888888;
		}
		.error{
			color: red;
		}
		#uploadPreview img{
		  height:130px;
		  width: 120px;
		}
	</style>
	</head>
<body>
	<div class="container">
		<div class="row" style="background-color:#337AB7; color:#eee">
			<div class="col-md-2">
				<h3 class="logo col-md-5 col-sm-5 lineHeight" >
				<a href="javascript:;" ><img src="http://falahiafeni.edu.bd/public/images/logo.gif" class="" alt="Logo" style="width:90px;height:90px"></a>
				</h3><!--//logo--> 
			</div>
			<div class="col-md-10">
				<h1 style="line-height: 30px;">AL JAMIATUL FALEHIA KAMIL MADRASAH</h1>
				<p>EIIN No: 106629 , Madrasah Code: 18039, District Code: 63, Center Code: 643</p>
				<p>Falahia Lane, Shanti Company Road, Feni-3900, Phone: 0331-74797, www.falahiafeni.edu.bd</p>

				<div class='pull-right'><a href='http://202.5.38.86/ems/editApplicantsView' class='btn btn-warning btn-sm'>Update Application</a></div>
				<br><br>
			</div>
		</div>
		<div style="padding:20px;padding-bottom:100px;" id="formDiv">
			<label><b>Type Your Applicant Number:</b> </label>
			<input type="number" name="tracking_no" id="tracking_no" style="border:2px solid gray;height:25px;width:200px;border-radius: 2px;" >
			<button id="btn_search">Search</button>
		</div>
		
		<div class="row" id="printContent"></div>

		<div class="row" style='height:50px;background-color:#337AB7'>
			<p style='text-align:center;'>
				Copyright &copy; 2015. Developed by : <a href='http://unitehcengr.com' target='_blank' style='color:#fff'>Unitech IT</a>
			</p>
		</div>
	</div>
	</body>
</html>

	<script type="text/javascript">
	$('#btn_search').click(function(e){
		e.preventDefault();
		$('#formDiv').hide();
		var trackingNo = $('#tracking_no').val();
		$('#printContent').
		load('editApplicantsDetails/'+trackingNo , function(data){
			var data = jQuery.parseJSON(data);
			if (data.error === true) {
				$('#printContent').empty();
				$('#formDiv').hide().slideDown();
				$('#printContent').append('<p style="color:red; font-weight:bolder;padding-left:200px">'+data.status+'</p>');
			}
		});
	});
	$(document).ready(function () {        
        $('.datepicker').datepicker();
    });
	</script>
<?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/Pages/Admission/updateApplicaton.blade.php ENDPATH**/ ?>