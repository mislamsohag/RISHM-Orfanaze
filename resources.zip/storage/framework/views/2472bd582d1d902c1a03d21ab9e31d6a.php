<section class="slide-box">
    <h1 class="section-heading text-highlight slider-content"><span class="line">Students Photo
            Gallery </span></h1>

    <div id="btn-dir" align="right">
        <span class="btn-left" id="slider-backward"><i class="fa fa-chevron-left"></i></span>
        <span class="btn-right" id="slider-forward"><i class="fa fa-chevron-right"></i></span>
    </div>
    <div id="content-slider" class="scroll-img">
        <ul>
        </ul>
    </div>
</section><?php /**PATH G:\Projects&Practices\PHPandLaravel\Module9\practiceProject\resources\views/Components/home/photoGallery.blade.php ENDPATH**/ ?>