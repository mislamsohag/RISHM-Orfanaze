<div class="content container">
	<div class="row cols-wrapper">
		<div class="col-md-12 noPrintShow">
			<div class="page-wrapper">
				<header class="page-heading clearfix">
					<h1 class="heading-title pull-left">Madrasah Visit</h1>
					<div class="breadcrumbs pull-right">
						<ul class="breadcrumbs-list">
							<li class="breadcrumbs-label">You are here:</li>
							<li><a href="<?php echo e(url('gallery')); ?>">Home</a><i class="fa fa-angle-right"></i></li>
							<li class="current">Leadership Team</li>
						</ul>
					</div><!--//breadcrumbs-->
				</header>
			</div>
		</div>

		<div style="background: #FFF; padding: 5px;">
			<div class="page-content">
				<div class="row page-row image-event">
					<a class="prettyphoto col-md-4 col-sm-4 col-xs-6" rel="prettyPhoto[gallery]"
						href="<?php echo e(url('../../../images')); ?>/event/event5163417Jan2023.jpg">
						<img src="<?php echo e(asset('../../../images')); ?>/event/event5163417Jan2023.jpg"
							class="img-responsive img-thumbnail" alt="">
						<strong class='title'>জনাব ফাহমিদা হক, অতিরিক্ত জেলা প্রশাসক (শিক্ষা ও আইসিটি), মহোদয় কে
							ফু...</strong>
					</a>

					<a class="prettyphoto col-md-4 col-sm-4 col-xs-6" rel="prettyPhoto[gallery]"
						href="<?php echo e(url('../../../images')); ?>/event/event5268017Jan2023.jpg">
						<img src="<?php echo e(asset('../../../images')); ?>/event/event5268017Jan2023.jpg"
							class="img-responsive img-thumbnail" alt="">
						<strong class='title'>জনাব ফাহমিদা হক, অতিরিক্ত জেলা প্রশাসক (শিক্ষা ও আইসিটি), মহোদয়ের
							মাদ্...</strong>
					</a>

					<a class="prettyphoto col-md-4 col-sm-4 col-xs-6" rel="prettyPhoto[gallery]"
						href="<?php echo e(url('../../../images')); ?>/event/event5313817Jan2023.jpg">
						<img src="<?php echo e(asset('../../../images')); ?>/event/event5313817Jan2023.jpg"
							class="img-responsive img-thumbnail" alt="">
						<strong class='title'>জনাব ফাহমিদা হক, অতিরিক্ত জেলা প্রশাসক (শিক্ষা ও আইসিটি), মহোদয়ের
							মাদ্...</strong>
					</a>

				</div><!--//page-row-->
				<div class="row page-row image-event">
					<a class="prettyphoto col-md-4 col-sm-4 col-xs-6" rel="prettyPhoto[gallery]"
						href="<?php echo e(url('../../../images')); ?>/event/event6341617Jan2023.jpg">
						<img src="<?php echo e(asset('../../../images')); ?>/event/event6341617Jan2023.jpg"
							class="img-responsive img-thumbnail" alt="">
						<strong class='title'>জনাব ফাহমিদা হক, অতিরিক্ত জেলা প্রশাসক (শিক্ষা ও আইসিটি), মহোদয়ের
							মাদ্...</strong>
					</a>
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div>
	</div><!--//cols-wrapper-->
</div><!--//content--><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/galleryees/visit.blade.php ENDPATH**/ ?>