<?php echo $__env->make('Components.donate_head_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Components.donate_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- All Components inject here -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- All Components inject here -->        
    <?php echo $__env->make('Components.donate_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php echo $__env->make('Components.donate_js_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Layout/donate.blade.php ENDPATH**/ ?>