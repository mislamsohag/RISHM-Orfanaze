  
<section class="navbar_navbarWrapper__1hBH3">
	<nav id="header" class="navbar_navbar__3Bct2 navbar_flexItemCenter__7pSUn navbar_fixedTop__1zfxM "><a id="navbarBrand"
		class="navbar_navbarBrand__1B8WF" to="/" href="<?php echo e(url('#')); ?>"></a>
	<div class="navbar_flexItemCenter__7pSUn navbar_linksWrapper__1WMCd">
		<ul class="navbar_navbarNav__2O6OL">
			<li id="life" role="presentation"><a class=" "
					to="#"
					href="<?php echo e(url('#')); ?>">Life</a></li>
			<li id="giftCards" role="presentation"><a class=" " to="<?php echo e(url('#')); ?>" href="<?php echo e(url('#')); ?>">Donate Cards</a></li>
			<li id="exploreCampaigns" role="presentation"><a class=" " to="/explore-campaigns"
					href="<?php echo e(url('/explore-campaigns')); ?>">Explore Campaigns</a></li>
			<li id="donateMonthly" role="presentation"><a class=" " to="/monthlygiving" href="<?php echo e(url('#')); ?>">Donate
					Monthly</a></li>
			<li id="pertnerships" role="presentation"><a class=" " to="/partnerships"
					href="<?php echo e(url('#')); ?>">Partnerships</a></li>
			<li id="requestACampaign" role="presentation"><a class="navbar_newLink__8NxSH" to="/start-campaign"
					href="<?php echo e(url('#')); ?>">Start A Campaign</a></li>
			<li id="blogs" role="presentation"><a href="<?php echo e(url('#')); ?>">Students Blogs</a></li>
		</ul>
		<ul class="navbar_navbarNav__2O6OL ">
			<li class="account-menu-item_userDropdown__HaPB_" role="presentation"><a class=""
					to="<?php echo e(url('#')); ?>" id="loginLink" href="<?php echo e(url('#')); ?>">Join Us/Login<span
						class="sr-only">Join Us/Login</span></a></li>
		</ul>
	</div>
</nav>
</section>

<?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/donate_nav.blade.php ENDPATH**/ ?>