<?php $__env->startSection('content'); ?>
<div class="content container">
	<div class="row cols-wrapper">

		<?php echo $__env->make('Components.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="col-md-3 noPrintShow">
			<?php echo $__env->make('Components.sideNav.admissionSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('Components.sideNav.downloadLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('Components.sideNav.visitorsCount', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/pages/notice.blade.php ENDPATH**/ ?>