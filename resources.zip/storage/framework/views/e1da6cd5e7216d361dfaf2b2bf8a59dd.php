<div class="slider-wrapper theme-default">
        <div id="slider" class="nivoSlider">
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/65182.jpg')); ?>"
                                data-thumb="public/images/slides/65182.jpeg"
                                title="জাতীয় শিশু কিশোর ও ইসলামী সাংস্কৃতিক প্রতিযোগীতা-২০২৩" alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/46022.jpg')); ?>"
                                data-thumb="public/images/slides/46022.jpg"
                                title="বর্তমান মেয়র মহোদয়ের মাদ্রাসা পরিদর্শন ও অভিভাবকদের সাথে মতবিনিময় অনুষ্ঠানে।"
                                alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/49591.jpg')); ?>"
                                data-thumb="public/images/slides/49591.jpg"
                                title="পুলিশ সুপার কর্তৃক মাদ্রাসা পরিদর্শন ও অভিভাবকদের সাথে মতবিনিময়।" alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/53144.jpg')); ?>"
                                data-thumb="public/images/slides/53144.JPG" 
                                title="Madrasah Campus" alt="Slider Image"></a>

        </div>
</div><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/home/slider.blade.php ENDPATH**/ ?>