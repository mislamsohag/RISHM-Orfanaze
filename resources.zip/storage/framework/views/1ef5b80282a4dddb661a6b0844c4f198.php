<div class="slider-wrapper theme-default">
        <div id="slider" class="nivoSlider">
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/slider_3.jpg')); ?>"
                                data-thumb="public/images/slides/65182.jpeg"
                                title="মাদ্রাসার প্রাক্তন ছাত্রদের মিলন মেলা" alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/slider_1.jpg')); ?>"
                                data-thumb="public/images/slides/46022.jpg"
                                title="মাদ্রাসা ভবনের একাংশ দক্ষিণ পূর্ব কর্ণার থেকে"
                                alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/slider_4.jpg')); ?>"
                                data-thumb="public/images/slides/49591.jpg"
                                title="মাদ্রাসার উন্নয়নে কমিটি ও এলকাবাসীদের পরামর্শ সভা" alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/slider_5.jpg')); ?>"
                                data-thumb="public/images/slides/53144.JPG" 
                                title="মাদ্রাসা কমিটি ও এলাকার গণ্য-মান্য ব্যাক্তিবর্গের বৈঠক" alt="Slider Image"></a>
                <a href="<?php echo e(url('Javascript:;')); ?>"> <img src="<?php echo e(asset('images/slides/slider_2.jpg')); ?>"
                                data-thumb="public/images/slides/53144.JPG" 
                                title="মাদ্রাসা ভবনের একাংশ, (দক্ষিণ পশ্চিম কর্ণার থেকে)" alt="Slider Image"></a>

        </div>
</div><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Components/Pages/Home/slider.blade.php ENDPATH**/ ?>