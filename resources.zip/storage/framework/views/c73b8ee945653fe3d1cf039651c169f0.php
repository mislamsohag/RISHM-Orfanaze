<nav id="header" class="navbar_navbar__3Bct2 navbar_flexItemCenter__7pSUn navbar_fixedTop__1zfxM "><a id="navbarBrand"
		class="navbar_navbarBrand__1B8WF" to="/" href="http://127.0.0.1:8000/index.html"></a>
	<div class="navbar_flexItemCenter__7pSUn navbar_linksWrapper__1WMCd">
		<ul class="navbar_navbarNav__2O6OL">
			<li id="life" role="presentation"><a class=" "
					to="/life?utm_source=Menu&amp;utm_medium=Website&amp;utm_campaign=Medical"
					href="/life?utm_source=Menu&amp;utm_medium=Website&amp;utm_campaign=Medical">sohag</a></li>
			<li id="giftCards" role="presentation"><a class=" " to="/gift-card" href="/gift-card">Donate Cards</a></li>
			<li id="exploreCampaigns" role="presentation"><a class=" " to="/explore-campaigns"
					href="/explore-campaigns">Explore Campaigns</a></li>
			<li id="donateMonthly" role="presentation"><a class=" " to="/monthlygiving" href="/monthlygiving">Donate
					Monthly</a></li>
			<li id="pertnerships" role="presentation"><a class=" " to="/partnerships"
					href="/partnerships">Partnerships</a></li>
			<li id="requestACampaign" role="presentation"><a class="navbar_newLink__8NxSH" to="/start-campaign"
					href="/start-campaign">Start A Campaign</a></li>
			<li id="blogs" role="presentation"><a href="https://www.donatekart.com/blog">Blogs</a></li>
		</ul>
		<ul class="navbar_navbarNav__2O6OL ">
			<li class="account-menu-item_userDropdown__HaPB_" role="presentation"><a class=""
					to="/login?prevUrl=/donateHome" id="loginLink" href="/login?prevUrl=/donateHome">Join Us/Login<span
						class="sr-only">Join Us/Login</span></a></li>
		</ul>
	</div>
</nav><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/Components/donate_nav.blade.php ENDPATH**/ ?>