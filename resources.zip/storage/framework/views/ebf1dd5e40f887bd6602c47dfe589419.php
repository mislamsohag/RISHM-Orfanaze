<?php echo $__env->make('Components.head_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Header -->
    <?php echo $__env->make('Components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    <?php echo $__env->make('Components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- All Components inject here -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- All Components inject here -->        
    <!-- Footer -->
    <?php echo $__env->make('Components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer -->

<?php echo $__env->make('Components.js_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/Layouts/app.blade.php ENDPATH**/ ?>