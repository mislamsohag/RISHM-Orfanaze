<?php $__env->startSection('content'); ?>

<?php echo $__env->make('Components.galleryees.programme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\RSHNMProject\resources\views/pages/galleryees/programme.blade.php ENDPATH**/ ?>