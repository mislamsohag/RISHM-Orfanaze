

<?php $__env->startSection('content'); ?>
<section class="home-showcase_showCaseSection__1ITuP">
    <div class="home-showcase_bannerWrapper__r7GVA">
        <div class="home-showcase_banner__1P2Sx">
            <div class="home-showcase_overlayHeading___NuIh"></div>
        </div><img class="home-showcase_bannerImg__1pnLk gm-loaded gm-observing gm-observing-cb"
            data-gumlet="https://images.donatekart.com/Banner/cyclonedesktop.jpg" loading="lazy"
            src="https://dkprodimages.gumlet.io/Banner/cyclonedesktop.jpg?format=webp&amp;w=1366&amp;dpr=1.0">
    </div>
</section>
<div class="home-showcase_impactWrapperMob__JQamT">
    <div class="dk-impacts_impactsContainer__1klEY">
        <div class="dk-impacts_impactWrapper__2NIsy undefined">
            <div class="dk-impacts_icon__13hQG"><img
                    src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODYiIGhlaWdodD0iODYiIHZpZXdCb3g9IjAgMCA4NiA4NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CjxyZWN0IHdpZHRoPSI4NiIgaGVpZ2h0PSI4NiIgZmlsbD0idXJsKCNwYXR0ZXJuMCkiLz4KPHBhdGggZD0iTTQyLjQ3MjcgMzkuMDI3M1YzMy43NzczSDM3LjIyMjdWMzAuMjVINDIuNDcyN1YyNUg0NlYzMC4yNUg1MS4yNVYzMy43NzczSDQ2VjM5LjAyNzNINDIuNDcyN1pNMzMuMDM5MSA1NS44NDM3QzMzLjY5NTMgNTUuMTMyOCAzNC41MTU2IDU0Ljc3NzMgMzUuNSA1NC43NzczQzM2LjQ4NDQgNTQuNzc3MyAzNy4zMDQ3IDU1LjEzMjggMzcuOTYwOSA1NS44NDM3QzM4LjY3MTkgNTYuNSAzOS4wMjczIDU3LjMyMDMgMzkuMDI3MyA1OC4zMDQ2QzM5LjAyNzMgNTkuMjM0MyAzOC42NzE5IDYwLjAyNzMgMzcuOTYwOSA2MC42ODM1QzM3LjMwNDcgNjEuMzk0NSAzNi40ODQ0IDYxLjc1IDM1LjUgNjEuNzVDMzQuNTE1NiA2MS43NSAzMy42OTUzIDYxLjM5NDUgMzMuMDM5MSA2MC42ODM1QzMyLjM4MjggNjAuMDI3MyAzMi4wNTQ3IDU5LjIzNDMgMzIuMDU0NyA1OC4zMDQ2QzMyLjA1NDcgNTcuMzIwMyAzMi4zODI4IDU2LjUgMzMuMDM5MSA1NS44NDM3Wk01MC41MTE3IDU1Ljg0MzdDNTEuMjIyNyA1NS4xMzI4IDUyLjA0MyA1NC43NzczIDUyLjk3MjcgNTQuNzc3M0M1My45NTcgNTQuNzc3MyA1NC43NzczIDU1LjEzMjggNTUuNDMzNiA1NS44NDM3QzU2LjE0NDUgNTYuNSA1Ni41IDU3LjMyMDMgNTYuNSA1OC4zMDQ2QzU2LjUgNTkuMjM0MyA1Ni4xNDQ1IDYwLjAyNzMgNTUuNDMzNiA2MC42ODM1QzU0Ljc3NzMgNjEuMzk0NSA1My45NTcgNjEuNzUgNTIuOTcyNyA2MS43NUM1Mi4wNDMgNjEuNzUgNTEuMjIyNyA2MS4zOTQ1IDUwLjUxMTcgNjAuNjgzNUM0OS44NTU1IDYwLjAyNzMgNDkuNTI3MyA1OS4yMzQzIDQ5LjUyNzMgNTguMzA0NkM0OS41MjczIDU3LjMyMDMgNDkuODU1NSA1Ni41IDUwLjUxMTcgNTUuODQzN1pNMzUuODI4MSA0OS4xMTcxQzM1LjgyODEgNDkuMzkwNiAzNS45NjQ4IDQ5LjUyNzMgMzYuMjM4MyA0OS41MjczSDU2LjVWNTMuMDU0NkgzNS41QzM0LjUxNTYgNTMuMDU0NiAzMy42NjggNTIuNzI2NSAzMi45NTcgNTIuMDcwM0MzMi4zMDA4IDUxLjM1OTMgMzEuOTcyNyA1MC41MTE3IDMxLjk3MjcgNDkuNTI3M0MzMS45NzI3IDQ4LjkyNTcgMzIuMTM2NyA0OC4zNzg5IDMyLjQ2NDggNDcuODg2N0wzNC43NjE3IDQzLjUzOUwyOC41MjczIDMwLjI1SDI1VjI2LjgwNDdIMzAuNzQyMkwzMi4zODI4IDMwLjI1TDM0LjAyMzQgMzMuNzc3M0wzNy45NjA5IDQyLjA2MjVMMzguMjA3IDQyLjU1NDZINTAuNDI5N0w1NS4yNjk1IDMzLjc3NzNMNTcuMjM4MyAzMC4yNUw2MC4yNzM0IDMxLjk3MjdMNTMuNTQ2OSA0NC4xOTUzQzUyLjg5MDYgNDUuMzk4NCA1MS44NTE2IDQ2IDUwLjQyOTcgNDZIMzcuMzg2N0wzNS44MjgxIDQ4Ljg3MTFWNDkuMTE3MVoiIGZpbGw9InVybCgjcGFpbnQwX2xpbmVhcikiLz4KPGRlZnM+CjxwYXR0ZXJuIGlkPSJwYXR0ZXJuMCIgcGF0dGVybkNvbnRlbnRVbml0cz0ib2JqZWN0Qm91bmRpbmdCb3giIHdpZHRoPSIxIiBoZWlnaHQ9IjEiPgo8dXNlIHhsaW5rOmhyZWY9IiNpbWFnZTAiIHRyYW5zZm9ybT0ic2NhbGUoMC4wMTE2Mjc5KSIvPgo8L3BhdHRlcm4+CjxsaW5lYXJHcmFkaWVudCBpZD0icGFpbnQwX2xpbmVhciIgeDE9IjI1IiB5MT0iNDMuMDI3MyIgeDI9IjY0IiB5Mj0iNDMuMDI3MyIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgo8c3RvcCBzdG9wLWNvbG9yPSIjRkY3NDAwIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI0Y5MTcxNyIvPgo8L2xpbmVhckdyYWRpZW50Pgo8aW1hZ2UgaWQ9ImltYWdlMCIgd2lkdGg9Ijg2IiBoZWlnaHQ9Ijg2IiB4bGluazpocmVmPSJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUZZQUFBQldDQVlBQUFCVlZtSDNBQUFGRUVsRVFWUjRBZTJkVzI4Y05SVEhIYXFxUVZ3S0NFSkJxR3BRSHlyU1ZoV3FFQTk5S0ZKQmVTZ0ZsWElyclZTSlNpQTFFZ2dFRkdndW42ZWZKYTlJU0NWc2Q4ZjJMb2wyeDU3Tit4L1owOTFObXBtZG1SM1BacnoyU2trMlk4LzQrRGRuZk03NCtFSklUVDdZYWIySmZ2c2R5T0E5aFBRRDlOakhrT3dyUk94YmhNRVBFUHdQU0xaaHk4K2hZUVZ3QkRJNGpZaGVSVWgvdGdWWVhqbW5DaFpCOEN4NndYa0krZ1VFdFVvRDh3SWQ1SnNLV093OGZnT1MzeHdVNnNMZlNzRkNCcTlvN1pSczNRV1llK3RZQ1Zqcy9QMENJbTE4MXZZVzV0SjNvMkNCeGp4RTgwTUkrcWRMRUpQcWFnd3N1dlF0UkxObjNaT2c1VGxtQkN3RWV4ZVNydVlwMEpVOHBjQnFYelJrMTF5QlZhU2VFNFBWQmtvRWQ0c1U1bExlaWNENjlqVDcxYm93V0FoKzBiZW5oc0dpdDNYU1E4MkdxcHE4M0JxTDN0WnhST3dYbDlySk1uWE5CUlo0ZEF5Q2ZsK21JTmZPelFRTFlBNlMzM0lOVE5uNlpvTVY3RXJaUWx3OGZ5eFlkSnRMTGtJeFVlZFVzTmorNjNrSWZ0OUVJUzVlSXgyczVNc3VBakZWNTBTd0VNMlhJZWtEVTRXNGVKMWtzQkgvMUVVWUp1dDhBQ3orKy9kMVNPWnN6NzhwdUFmQnFsaStSZkg3dXNxNkR5eDYvR1JkQmJWTnJ2MWdJM3JIdGdyVVZkNGhXTjBmNE1NcnhvWXdqY0QyVzJmcmV2ZHRsR3NFVnRBYk5sYWdyakpyc0Rvb0tPanZkUlhTUnJsaXNHSDdsSTNDMTFubUdLenZHalJtdEFZM093WXIyY3JnZ1ArYkw2YVZ4WWtnNHE5bVpmTHB4V0VUZURmTGVET2dGSkZBMHZlOVJoYlh5Q3htQk41d1ZhU3h2dSsxSXJBK3RGMFIySWo1RVlNVjlEOFRTUDVqVmtQczA0c2JOK1VWK0tCaEpScnJ4dzZZYjJNRnYwL2dYMmZOZzVWc2hjQ0hZOHlEamVnZEF0L0JiUjZzb0RlVVYrQ0hFaGszWG54WjlXNWQ4dTVVY1hkcUxMT0lYeUlJNllXeG1ZemZUY09WcUtOOEliMUE5R0lNZFJUT1pwbkM5aW1DYnZkRk9EanR2Y0tuZEIyTnhud2Ntdkg5QmVZOGc0amQxVkRWTDIvQURMYjd5bkFOUHRqZFBsSGhvMkZPRzJ4b2QzZTNUd3k0RWhBeWg1RCs1T0dXMUZ5MUdoTWhjME93Nm90ZXBza0dqYWl6akJHOXVnOXFESmFmOFJwYlVtTWpmdVlnMkVaajN2Zk5sZ0ZMVjRkdTF0TjAvZFRPTW1ENXJhZDVEdjkvTXJIRExTdHVxczN1ZHhhR0lKTysrRzdFQ2JSV2RSTm1mZUxKYzM0NlVnRkR2b2F3OFZJV1Y1M3VYYThDV3B2a1lxVlIxaE9VZmZRMmg2MmhEOURwUEpmR01mRzRIOU9WUTJzRnU1SUliOXhCNVpQNWFmVmo0S281RzNoMGJCekQxRFQwL0JTbFZDUFdiUzZsZ3N1VDRKdUVCSzBOZzh0NTJJM05veGZiOFNIeWtTRVQ5UE94d0lva1luUHpLQVQ5THZXeE1QWDJVdmZycUNXeU5qZVBGbUdYbWRmNUJjM1VZbTY5cmVPWm9DYkpFRSs3ZDNHZFdMcXFsaCtjaEZudWMrSkZJeE1hOUxvL3htWGtFL3hpYmtCbE1rSTAzMGJFZnAzNU5sZlZVWFFXeTdBcWZLN3FlSmp4SWFBcnVUdFhDdFBMT0NGZVBHSVcxNUFKYms3OFZwWEJMSGV5anZETzBsd3gwZnJvUUtRMU40MEtNajdaUThiZS9RL1UzZzI5MXRrSzBKUy9wTjRDSmVUWExSc0x0b2FJWGF2TVJ5MlBkWFFGOU51dldiREh6RHBFOEpsU2hwSGtsbnlMZDBVS3ZxbVpXN1lPd2I1VU45OFNqT2xpNnVYOVpSMEF0NzVXTnp0ZFVrdFR0SHUyRzV6VGtlQnB6QzhUd1c4SWcrdm90NWNPM1gyYTFqM0R3NGRISUI0dlFnYkxlay9FTXErY2U4OVYreXVxQ1N1aXM0aU5qV2VtVlovYWxxTkRRWjEvRnZUUWZiVXBVQmhjMXRZNnBMY2gyVDJvVUVpOGhOVTlxR05oNnhPZFIyOGdGSnhHdjdPUU9zVG5FR3I5UDZSZXRGRW02ZXN3QUFBQUFFbEZUa1N1UW1DQyIvPgo8L2RlZnM+Cjwvc3ZnPgo="
                    class="lazyload gm-observing gm-observing-cb" alt="" loading="lazy"></div>
            <p class="dk-impacts_title__3edI6"><svg aria-hidden="true" focusable="false" data-prefix="fas"
                    data-icon="rupee-sign" class="svg-inline--fa fa-rupee-sign fa-w-10 " role="img"
                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                    <path fill="currentColor"
                        d="M308 96c6.627 0 12-5.373 12-12V44c0-6.627-5.373-12-12-12H12C5.373 32 0 37.373 0 44v44.748c0 6.627 5.373 12 12 12h85.28c27.308 0 48.261 9.958 60.97 27.252H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h158.757c-6.217 36.086-32.961 58.632-74.757 58.632H12c-6.627 0-12 5.373-12 12v53.012c0 3.349 1.4 6.546 3.861 8.818l165.052 152.356a12.001 12.001 0 0 0 8.139 3.182h82.562c10.924 0 16.166-13.408 8.139-20.818L116.871 319.906c76.499-2.34 131.144-53.395 138.318-127.906H308c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-58.69c-3.486-11.541-8.28-22.246-14.252-32H308z">
                    </path>
                </svg> 200+ Cr</p>
            <p>Worth Donations</p>
        </div>
        <div class="dk-impacts_impactWrapper__2NIsy undefined">
            <div class="dk-impacts_icon__13hQG"><img
                    src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CjxyZWN0IHdpZHRoPSI4MCIgaGVpZ2h0PSI4MCIgZmlsbD0idXJsKCNwYXR0ZXJuMCkiLz4KPHBhdGggZD0iTTMxLjAyNzMgMzcuNDE4OFY0MC44MzM5SDI1Ljc3NzNWNDUuOTE3SDIyLjI1VjQwLjgzMzlIMTdWMzcuNDE4OEgyMi4yNVYzMi4zMzU3SDI1Ljc3NzNWMzcuNDE4OEgzMS4wMjczWk00OC41IDM5LjE2NjFDNDcuOTUzMiAzOS4xNjYxIDQ3LjQzMzYgMzkuMDg2NiA0Ni45NDE0IDM4LjkyNzhDNDcuOTgwNSAzNy40NDUyIDQ4LjUgMzUuODMwMyA0OC41IDM0LjA4M0M0OC41IDMyLjI4MjggNDcuOTgwNSAzMC42Njc5IDQ2Ljk0MTQgMjkuMjM4M0M0Ny40MzM2IDI5LjA3OTQgNDcuOTUzMiAyOSA0OC41IDI5QzQ5Ljk3NjUgMjkgNTEuMjA3IDI5LjUwMyA1Mi4xOTE0IDMwLjUwOUM1My4yMzA1IDMxLjQ2MjEgNTMuNzUgMzIuNjUzNCA1My43NSAzNC4wODNDNTMuNzUgMzUuNDU5NyA1My4yMzA1IDM2LjY1MSA1Mi4xOTE0IDM3LjY1N0M1MS4yMDcgMzguNjYzMSA0OS45NzY1IDM5LjE2NjEgNDguNSAzOS4xNjYxWk00My40MTQxIDM3LjY1N0M0Mi40Mjk3IDM4LjY2MzEgNDEuMTk5MiAzOS4xNjYxIDM5LjcyMjcgMzkuMTY2MUMzOC4zMDA4IDM5LjE2NjEgMzcuMDcwMyAzOC42NjMxIDM2LjAzMTIgMzcuNjU3QzM0Ljk5MjEgMzYuNjUxIDM0LjQ3MjcgMzUuNDU5NyAzNC40NzI3IDM0LjA4M0MzNC40NzI3IDMyLjY1MzQgMzQuOTkyMSAzMS40NjIxIDM2LjAzMTIgMzAuNTA5QzM3LjA3MDMgMjkuNTAzIDM4LjMwMDggMjkgMzkuNzIyNyAyOUM0MS4xOTkyIDI5IDQyLjQyOTcgMjkuNTAzIDQzLjQxNDEgMzAuNTA5QzQ0LjQ1MzIgMzEuNDYyMSA0NC45NzI3IDMyLjY1MzQgNDQuOTcyNyAzNC4wODNDNDQuOTcyNyAzNS40NTk3IDQ0LjQ1MzIgMzYuNjUxIDQzLjQxNDEgMzcuNjU3Wk01MS4zNzExIDQyLjgxOTVDNTMuMzk0NSA0My4xMzcyIDU1LjE3MTggNDMuNzE5NyA1Ni43MDMyIDQ0LjU2NjhDNTguMjM0NCA0NS40MTQgNTkgNDYuNDE5OSA1OSA0Ny41ODQ4VjUxSDUzLjc1VjQ3LjU4NDhDNTMuNzUgNDUuNzg0NiA1Mi45NTcgNDQuMTk2MSA1MS4zNzExIDQyLjgxOTVaTTMyLjgzMiA0My45MzE0QzM1LjIzODMgNDIuOTc4MyAzNy41MzUyIDQyLjUwMTggMzkuNzIyNyA0Mi41MDE4QzQxLjkxMDIgNDIuNTAxOCA0NC4yMDcgNDIuOTc4MyA0Ni42MTMzIDQzLjkzMTRDNDkuMDE5NSA0NC44ODQ1IDUwLjIyMjcgNDYuMTAyMyA1MC4yMjI3IDQ3LjU4NDhWNTFIMjkuMjIyN1Y0Ny41ODQ4QzI5LjIyMjcgNDYuMTAyMyAzMC40MjU4IDQ0Ljg4NDUgMzIuODMyIDQzLjkzMTRaIiBmaWxsPSJ1cmwoI3BhaW50MF9saW5lYXIpIi8+CjxkZWZzPgo8cGF0dGVybiBpZD0icGF0dGVybjAiIHBhdHRlcm5Db250ZW50VW5pdHM9Im9iamVjdEJvdW5kaW5nQm94IiB3aWR0aD0iMSIgaGVpZ2h0PSIxIj4KPHVzZSB4bGluazpocmVmPSIjaW1hZ2UwIiB0cmFuc2Zvcm09InNjYWxlKDAuMDEyNSkiLz4KPC9wYXR0ZXJuPgo8bGluZWFyR3JhZGllbnQgaWQ9InBhaW50MF9saW5lYXIiIHgxPSIxNyIgeTE9IjQxLjE3MjgiIHgyPSI2NC42IiB5Mj0iNDEuMTcyOCIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgo8c3RvcCBzdG9wLWNvbG9yPSIjRkY3NDAwIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI0Y5MTcxNyIvPgo8L2xpbmVhckdyYWRpZW50Pgo8aW1hZ2UgaWQ9ImltYWdlMCIgd2lkdGg9IjgwIiBoZWlnaHQ9IjgwIiB4bGluazpocmVmPSJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUZBQUFBQlFDQVlBQUFDT0VmS3RBQUFEOUVsRVFWUjRBZTJkMjFMYk1CQ0dUU25oMklaRFMzbXh2aytlZ0F1bXdIaEtteUhUOXNJditYZitEUWxCMkpaMXNCTkx5d3hESEZzcjcrZVZkbGVTUlZGczhRY0Y5bEJoZ2xzY1k0RlQvTUluekhHT0oxeWl4QmNzY0MyLy9MejhiaXJYOEZxV1lka0NlMXRVWWZpcVVXRWZKVTd3RnhmNGlXK1k0eWJvbHpJb2l6SXI3QSt2MFFBMVlvYUpXQTR0S1JTWXJUenJvQ1hQTUJsQXRYNnJrR2IyRzE5N2g5WUVkVm4zVWI5YTlpQWRkempFTTY2MkJzNEV5bnU1dzJFUHFzWVZpUklIMHRtYkN1eks4ZElSSGNUVk9vSTB6UEJSdk9ldWdMTGZ4em52T1lMcTRTSXd4MUVVYjJwWE9zeGJtL0xwdlc5eEhFNGdRQUx1Y2JZei9ad0pxT3Z4UGM0Q0VQZ1hIVm1UdFZudnVUOEp4NUlBOW5iYVVYUzFQUE02T3BnWlBqamljTHRjc29oL0F3VERwbkpESFRNSTd5dWJrYngxaUV4aUtGaE45VkRIUHZKclBPQmk5QTZqQ1pyNS9RTXUzTnFtNVdwVUNYaGJFNUx0dUlya25TV2Z0VldXN3Ztd1BGcFNzeGhEVG1NRlROMUwrS1YrZE9sNHhIVTIvVjdUUXlZRG4vQW1zVURaRmtqYnpyc0YydEowbTU1SXJ0KzdERDRrbVdtRVB2aXVvWTBNdjRkV2xtcjVMdE1FYW4wdGsxeFB1R3dObVdVb1BsWHJpYVZYMVRKWnRWUHpHTEVVamkzbkdWZTFWdmd5TEc5ejUzcWVENlJ1eEVaV0JzUitXcW5LVytEMG5SV3E4Mmh4SHFZaG1NNUUwcmFjYzE0VGtPMllyRGJUTzFRNHpqN250VUV6ejFjYk0zcFpEWmFhSUh5UFY1bUpETlZyODNXUExzaU1RLzg2Y09EZ1BFeHI1VmloWmg4QkFMbGdTUlltbW1UMXVGdVRMbkZTWkRsaEZNdEFPUEdFRWxNTllUeWJjWWxwb1JtSUp6eGFNVU1aV1EwZnk2UnprOE9SR1htTklEZkZZK203d0xVQ0RJU3BUVGdZSU5mRkJRckp1YnlHTVlIR1U3eThuOVl0OGc2c0xFVkxwUk01VFZHeG9YUXFNbCsrRnR6eW1BdFBobnBhS2RaVDZIeElRQ28zeDQzTXptays3QTl4Q1ZBZGlYZGZ1QVRJdDhnMVJQR0N1SjVnMTFFWnYyYjhDakRIVnhraXRMcFhnSHhaT29MQTNHU3NBZklEdHJtL3dVZ2YzbHVBR2xRN081STNBTVVLZFhqTENlSjdnTm9YaGdFVUsrVDJTeVB0azRhKzczY1dLQUM1QzRjdU9PcGtpYlVBQmFKT3VBY0M1TXVHR3RaWUlUWmFvRGJsYnFsZEswQ0J5STExMUtFMFdxSVZvRURVUERrTTRJc2xhbWhUMHhJN1dhQUE1SGFkT1d4N1VnT3ByUXZyREZBZ2N1Q1YrNW82VnBMeTlVNEExNWFvbWNxNlQzUUd1Q3FnUzRPWFljNktoOWZmMGU0ZEdMRUw4Z0szV1VqZU04azRZOWxrNGYxWnRzVGoxc01aRGtCNFE2c3JpTzh5UFpwVnZGakhJZmc3YWRZL2RtZ2I1SWg5bmhtU0JjTnFFeUJPSnVVTkcxZHJZOW9neERnbkZzaytNc0ZNSmdZZkp4bXlqU2pYNG5EeUtnR240NlI4SHhjTFVQNnpBZzZiRWV3ZmZKWVh3TGw5K3dqU3h2OHNlMjVaaEZpcExBQUFBQUJKUlU1RXJrSmdnZz09Ii8+CjwvZGVmcz4KPC9zdmc+Cg=="
                    class="lazyload gm-observing gm-observing-cb" alt="" loading="lazy"></div>
            <p class="dk-impacts_title__3edI6">7+ Lakhs</p>
            <p>Unique Donors</p>
        </div>
        <div class="dk-impacts_impactWrapper__2NIsy undefined">
            <div class="dk-impacts_icon__13hQG"><img
                    src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODYiIGhlaWdodD0iODYiIHZpZXdCb3g9IjAgMCA4NiA4NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CjxyZWN0IHdpZHRoPSI4NiIgaGVpZ2h0PSI4NS4wMTE1IiBmaWxsPSJ1cmwoI3BhdHRlcm4wKSIvPgo8cGF0aCBkPSJNNDUuNjY2MSAzOS4xNzE0QzQ0LjUxMTcgMzguMjEyMiA0Mi44MTE1IDM4LjM5NTkgNDEuNzQxIDM5LjQ1N0w0MS4zNDIyIDM5Ljg2NTJMNDAuOTIyNSAzOS40NTdDMzkuODcyOSAzOC4zOTU5IDM4LjE1MTcgMzguMjEyMiAzNi45OTczIDM5LjE3MTRDMzUuNjc1IDQwLjI3MzQgMzUuNjEyMSA0Mi4yMzI2IDM2Ljc4NzQgNDMuNDE2Mkw0MC44NTk1IDQ3LjQ5NzhDNDEuMTExNCA0Ny43NjMxIDQxLjU1MjEgNDcuNzYzMSA0MS44MDQgNDcuNDk3OEw0NS44NzYxIDQzLjQxNjJDNDcuMDUxNCA0Mi4yMzI2IDQ2Ljk4ODUgNDAuMjczNCA0NS42NjYxIDM5LjE3MTRaIiBmaWxsPSJ1cmwoI3BhaW50MF9saW5lYXIpIi8+CjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMjcuODE2OCA0My40OTg1VjU2LjM1NDhDMjcuODIxMiA1Ni43ODU3IDI3Ljk5NzUgNTcuMTk4MSAyOC4zMDg2IDU3LjUwNUMyOC42MTk3IDU3LjgxMiAyOS4wNDEyIDU3Ljk4OTQgMjkuNDg0MiA1OEg1Mi41MTgxQzUyLjk2MTggNTcuOTg5NCA1My4zODQgNTcuODExNCA1My42OTUxIDU3LjUwMzZDNTQuMDA2MyA1Ny4xOTU4IDU0LjE4MjEgNTYuNzgyNSA1NC4xODU1IDU2LjM1MDhWNDMuNDk4NUM1NC4xOTEgNDMuMjgyMiA1NC4xNTE5IDQzLjA2NzIgNTQuMDcwNyA0Mi44NjU4QzUzLjk4OTQgNDIuNjY0NSA1My44Njc1IDQyLjQ4MSA1My43MTIyIDQyLjMyNjFDNTMuNTU2OSA0Mi4xNzE0IDUzLjM3MTIgNDIuMDQ4MyA1My4xNjYyIDQxLjk2NDNDNTIuOTYxMiA0MS44ODAzIDUyLjc0MSA0MS44MzcgNTIuNTE4NiA0MS44MzdDNTIuMjk2MiA0MS44MzcgNTIuMDc2IDQxLjg4MDMgNTEuODcwOSA0MS45NjQzQzUxLjY2NiA0Mi4wNDgzIDUxLjQ4MDQgNDIuMTcxNCA1MS4zMjUgNDIuMzI2MUM1MS4xNjk3IDQyLjQ4MSA1MS4wNDc3IDQyLjY2NDUgNTAuOTY2NSA0Mi44NjU4QzUwLjg4NTIgNDMuMDY3MiA1MC44NDYxIDQzLjI4MjIgNTAuODUxNyA0My40OTg1VjU2LjM1NDhWNTQuNzA1N0g1Mi41MTgxSDI5LjQ4NDJIMzEuMTUwNlY1Ni4zNTQ4VjQzLjQ5ODVDMzEuMTU2MSA0My4yODIyIDMxLjExNzEgNDMuMDY3MiAzMS4wMzU4IDQyLjg2NThDMzAuOTU0NSA0Mi42NjQ1IDMwLjgzMjYgNDIuNDgxIDMwLjY3NzMgNDIuMzI2MUMzMC41MjIgNDIuMTcxNCAzMC4zMzYzIDQyLjA0ODMgMzAuMTMxNCA0MS45NjQzQzI5LjkyNjQgNDEuODgwMyAyOS43MDYyIDQxLjgzNyAyOS40ODM3IDQxLjgzN0MyOS4yNjEyIDQxLjgzNyAyOS4wNDExIDQxLjg4MDMgMjguODM2MSA0MS45NjQzQzI4LjYzMTEgNDIuMDQ4MyAyOC40NDU1IDQyLjE3MTQgMjguMjkwMiA0Mi4zMjYxQzI4LjEzNDggNDIuNDgxIDI4LjAxMjkgNDIuNjY0NSAyNy45MzE2IDQyLjg2NThDMjcuODUwNCA0My4wNjcyIDI3LjgxMTMgNDMuMjgyMiAyNy44MTY4IDQzLjQ5ODVaTTI1LjgzNDcgNDIuMjc4NEMyNy42NDk5IDQwLjQyMjEgMjkuNDY3MSAzOC41NjkyIDMxLjI4NjQgMzYuNzE5N0MzNC4xODU2IDMzLjc2NzQgMzcuMDgyNiAzMC44MTI0IDM5Ljk3NzIgMjcuODU0N0M0MC41ODc3IDI3LjIzMDkgNDEuMDczNCAyNi45OTY3IDQxLjA3MzQgMjYuOTk2N0M0Mi45MzkzIDI4Ljg1MjkgNDMuMzQ4NiAyOS41MjEzIDQ1LjIwOTggMzEuMzc2MkM0OC4xNzYzIDM0LjMzNjUgNTEuMTQ1NSAzNy4yOTQxIDU0LjExNzUgNDAuMjQ5MUM1NC44MDA2IDQwLjkyNTEgNTUuNDgzNiA0MS42MTAzIDU2LjE2NzYgNDIuMjg2M0M1Ni40ODA5IDQyLjU4OTIgNTYuOTA0NiA0Mi43NTkzIDU3LjM0NjQgNDIuNzU5M0M1Ny43ODgyIDQyLjc1OTMgNTguMjEyIDQyLjU4OTIgNTguNTI1MiA0Mi4yODYzQzU4LjgzMDIgNDEuOTcwMSA1OSA0MS41NTI3IDU5IDQxLjExOTJDNTkgNDAuNjg1NiA1OC44MzAyIDQwLjI2ODMgNTguNTI1MiAzOS45NTJDNTYuNjU4IDM4LjA5NjUgNTQuNzk0NCAzNi4yNDEzIDUyLjkzNDYgMzQuMzg2NEM0OS45NjgxIDMxLjQyNjEgNDYuOTk4OSAyOC40Njg1IDQ0LjAyNjkgMjUuNTEzNUM0My4zNDM4IDI0LjgzNjQgNDIuNjYwOCAyNC4xNTIzIDQxLjk3NjggMjMuNDc2MkM0MS44MjIzIDIzLjMyNTMgNDEuNjM4NSAyMy4yMDU1IDQxLjQzNjMgMjMuMTIzOEM0MS4yMzQgMjMuMDQyMSA0MS4wMTcgMjMgNDAuNzk4IDIzQzQwLjU3ODkgMjMgNDAuMzYyIDIzLjA0MjEgNDAuMTU5OCAyMy4xMjM4QzM5Ljk1NzQgMjMuMjA1NSAzOS43NzM3IDIzLjMyNTMgMzkuNjE5MiAyMy40NzYyQzM3LjgwMjcgMjUuMzMxOCAzNS45ODU0IDI3LjE4NDMgMzQuMTY3NSAyOS4wMzM5QzMxLjI2ODIgMzEuOTg2MiAyOC4zNzEzIDM0Ljk0MTEgMjUuNDc2NyAzNy44OTg4QzI0LjgxMDIgMzguNTg0IDI0LjEzOTUgMzkuMjYgMjMuNDc3MSAzOS45NDQxQzIzLjE3MDcgNDAuMjU5NiAyMyA0MC42NzcyIDIzIDQxLjExMTFDMjMgNDEuNTQ1MiAyMy4xNzA3IDQxLjk2MjggMjMuNDc3MSA0Mi4yNzg0QzIzLjc5MTcgNDIuNTc5MiAyNC4yMTUyIDQyLjc0NzcgMjQuNjU2NCA0Mi43NDc3QzI1LjA5NzYgNDIuNzQ3NyAyNS41MjEyIDQyLjU3OTIgMjUuODM1NyA0Mi4yNzg0SDI1LjgzNDdaIiBmaWxsPSJ1cmwoI3BhaW50MV9saW5lYXIpIi8+CjxkZWZzPgo8cGF0dGVybiBpZD0icGF0dGVybjAiIHBhdHRlcm5Db250ZW50VW5pdHM9Im9iamVjdEJvdW5kaW5nQm94IiB3aWR0aD0iMSIgaGVpZ2h0PSIxIj4KPHVzZSB4bGluazpocmVmPSIjaW1hZ2UwIiB0cmFuc2Zvcm09InNjYWxlKDAuMDExNDk0MyAwLjAxMTYyNzkpIi8+CjwvcGF0dGVybj4KPGxpbmVhckdyYWRpZW50IGlkPSJwYWludDBfbGluZWFyIiB4MT0iMzUuOTY4OCIgeTE9IjQyLjg0ODkiIHgyPSI0Ni43MTU2IiB5Mj0iNDIuODQ4OSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgo8c3RvcCBzdG9wLWNvbG9yPSIjRkY3NDAwIi8+CjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI0Y5MTcxNyIvPgo8L2xpbmVhckdyYWRpZW50Pgo8bGluZWFyR3JhZGllbnQgaWQ9InBhaW50MV9saW5lYXIiIHgxPSIyMyIgeTE9IjQwLjUwMDEiIHgyPSI1OSIgeTI9IjQwLjUwMDEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KPHN0b3Agc3RvcC1jb2xvcj0iI0ZGNzQwMCIvPgo8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNGOTE3MTciLz4KPC9saW5lYXJHcmFkaWVudD4KPGltYWdlIGlkPSJpbWFnZTAiIHdpZHRoPSI4NyIgaGVpZ2h0PSI4NiIgeGxpbms6aHJlZj0iZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFGY0FBQUJXQ0FZQUFBQzZsQXJKQUFBRlBrbEVRVlI0QWUyZFBXN2JUQkNHMTA3eS9kbU85Z2c2Z29CY2dJWHJRQTByUXdDaGdvVUFBVEpneEMzTGRLcFQrUWc2Z3EvMjRkbmxLdFFQUllvY0txSTVCZ1JMc2ltYkQ0Y3o3OHpzajFtdFZyWnZqMlNWMlBRMUhUMHRsMS9uUCtZUHM1ZlpYWklrLzhSeC9GY1VSWi9OdFh3QjFyeWJuajJzdGUvVzJzM1lqamRqTzNtYjJNazZzbzgvNDFIOG1vNDRwOFZpY1E5c1k4ek5IMlBkVDdoVnhtQWQ5RysvSGgxc3JEdE4weThYaC93eDRlN0N4OElmZnoyT2NDVnBtdjVuakxtOUNPZ2h3QzI2dmZGbVlxZXJ4TWFMK0Q3THNtNGhEdzF1QUkydm5xNm1GcGZSR2VTaHdpMUNMcmdMMmVBM2RMZ0I4bVE5Y2ZJdVZ4Z3lMbG5oRm9PZnRVaTVQT2kxQjZ4d2kzRDk4eWlMN0hLNS9OcGFWU2pjUTdpNGl2SGIxazE4YW16Q0N2YzRYQWQ0TTdhazJvMVRhb1ZiRGhmQUpDQ3VsdEVrdzFPNHArRjZ3TllCanVQNFBCZWhjS3ZoQmd0R0Q1OVZDRks0OWVBR0g1eW1EbkM5R0tkdzY4TjFnTjhtTmw0czdtdlJWYmpud1FWd2xFM1J3WDlYQWxhNDU4TTE3elVEbk1KdEF0ZEx0RHpBbFJ1d3dtMEcxN21IZFdUcDNaWFNWYmpONFFiM1VDclBGRzRidUw0R3NjaEsxSVBDYlFjWDkwQjZmTFNib1hEYnc2V0NSay91d1BjcTNQWndnKzg5c0Y2Rkt3SFh1SUVwQngwTWhTc0ROMWp2am10UXVGSndmVnE4TTdKSDRjckJaU3pFOXgvZkg3YldxM0RsNEFaWnBuQTdHdGxKeFd6YmMxUExsYlZjaHJQR3ovRy96bm9Wcml4Y3U3SDJhZm5FbUFkakZLNHMzQjIvcTNEbDRjWS80NUhMMWhTdVBOeG9IVm1uZHhXdVBGeUNtaXVpSzF4NXVDUVRya3FtY09YaE1nU0tFZXVxRmpwSUpwakc1ZVNZV3E2ODVWSWhjNTFoaGRzTlhNZlZ3N1U5bTBIWkJSREp6N1J1eXEraHVZWVprMW5vUTRxQkg1RmpuRzlRdU1LR2xmdGNKbFpRYkZDcmxiSmFQOVRKVFZoQk1xRExGSzRzWEtkeldhdUF2cnZDbFlOTCt1czZ3ZVRBRkJvVXJoeGNlTHJ4dTFSdktKRXBYRG00OFd2TUxNd3ZocnFqbDJOeUh6NzBDK1Y0aGpVZE5KR1FNeXpxQ2psYzN3Um1QUmdOYWpLQTRZaEk4R1NOTVRoZkpoTVAvWGFXT0g5YTZ6dkxDcWpmbGJGYUxrN3VFbllYeFdEeW1pWVQ3U0REYjl0VzMvb0ZkUTBpTGhHWGtHVVphNWtkZk4yb2FtaGp1WG1ac1d5UnVQbDgvcUNxb1JsZ1VsNVUxNEhKaGpmSUtqU2hhQUszNW94S1NtVnF2ZWNCaHBlcmdnVXJMZnV1MW5zZTJDQy90c05HeThDRzk5VjY2d1BHYW8vS3J3QnovenZMalhqZnF4MkswMW1iOTdVSFU2VDJnZTYvbnMxbWQ5RjZLcUwvVHYrRDlhM2syajVubWszdDgvT3pIK2k4RDdEaXRkTzlqSHU2dHBPNmh2OEhkMUM1Sk1BcHdENjRzVEswdW9mZEMrb1RodHBCckF3eXZhQnBwbU1iZnNPMU5zbVMwK3NzbE1FODlqN1JVUHRzUGpiQWdVejJHS2VtNzdsVzBOQ1RDOWZWUFhkdHNUckVrV2NVZG9aYWx1Uzg4MXB0TjB0eGgreU5QdEZ2SDlSZktWWDNIQUxZMWdHc3lvcHBDWEVGaDJMQkFTeUdWY1ZHNU9mMGlJYmdJZ0xZemkxMi82cHdKUUg4VVlNYzU4VWRldmJLby91Z21yN21EOU43KzJneVRXeFo3YVpnQzhmZHVIMXdYaGtTMWZkQUo3d2dmQUZTcTZjTTZPTTJRZ3ZXamNMWDlIdGhLNE9MQmE0R3RHOWZYbDd1K3FRbUtFeFJnTWtYLzlrZGI5QUFRT2VINEl0Sm1SbnRkNjJTRGFpZGJ4L1RKV2trREwwbE5ocGl3NkZyY0FQRmpZLyttQktRaEU2bDN1MjJ0MG9zZTVSZE9zUGo3a0hSOU9yMmIzSUJTRUM4eTBoSGdQYkZlR21WVWR4c0xoNXg5MXh6b0dyQ3NlcVlXMUpweW5ja0kvaG50amxrdTBNRVBOQ3hPRy9sUmZnODc4azJpVlVFTHZYekxNcytZOVZJT2x3STFrWVhtbHNaOWNFRkNBOWU4MzdZNEpOSXozRWNmL0ZVOVFTZy93SGRscmdVYkl4aW53QUFBQUJKUlU1RXJrSmdnZz09Ii8+CjwvZGVmcz4KPC9zdmc+Cg=="
                    class="lazyload gm-observing gm-observing-cb" alt="" loading="lazy"></div>
            <p class="dk-impacts_title__3edI6">1400+</p>
            <p>NGOs Impacted</p>
        </div>
    </div>
</div>
<div id="featuredCampaigns" class="home_campaignContainer__rABdp">
    <div class="react-multi-carousel-list  responsive-carousel_carousel__3TThN " dir="ltr">
        <ul class="react-multi-carousel-track "
            style="transition: transform 400ms ease-in-out 0s; overflow: unset; transform: translate3d(-3200px, 0px, 0px);">
            <li data-index="0" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea lazyload gm-added gm-loaded gm-observing gm-observing-cb"
                        data-gumlet="https://images.donatekart.com/campaign/cover/support-people-through-the-harsh-winters2116700946.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/support-people-through-the-harsh-winters2116700946.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">This Winter, Save Countless Lives With Donatekart,
                            One Blanket At A Time</div>
                        <div class="showcase-campaigns_desc__1PfaB">As the temperatures drop we hear heartbreaking news
                            reports of the homeless succumbing to the harsh winter conditions. It is time we step up and
                            decide to save these innocent lives. Donatekart Foundation is working with trusted NGOs to
                            ensure that these poor and underprivileged souls are not left all alone during the winter
                            months. You can join their mission and make a difference. </div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow7" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="1" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Save-Kids-From-The-Cold1303121969.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Save-Kids-From-The-Cold1303121969.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Warm Clothes Are A Luxury These Poor Kids Can’t
                            Afford, Save Them From The Cold </div>
                        <div class="showcase-campaigns_desc__1PfaB">At an age when these kids should be going to school,
                            learning, and playing, thousands of poor kids in India are struggling to make it through the
                            winter. Lack of warm clothing, adequate shelter, and nutritious food during winter can make
                            them more susceptible to illnesses and have a profound impact on their well-being. They need
                            our support to brave the cold. </div><a class="showcase-campaigns_donateNowLink__3Vi-N"
                            id="donateNow8" target="_self">Donate Now &nbsp;<svg aria-hidden="true" focusable="false"
                                data-prefix="fas" data-icon="arrow-right" class="svg-inline--fa fa-arrow-right fa-w-14 "
                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="2" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea lazyloaded gm-added gm-loaded gm-observing gm-observing-cb"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Help-stray-animals-stuck-in-cyclone614687594.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Help-stray-animals-stuck-in-cyclone614687594.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">As Cyclone Michaung Lashes Through Chennai, Support
                            Countless Strays In Need Of Help</div>
                        <div class="showcase-campaigns_desc__1PfaB">Cyclone Michaung has turned out to be even more
                            catastrophic than any disaster Chennai has seen before. Apartment buildings and
                            neighbourhoods are lying underwater. People are leaving their homes for a safer location.
                            There is panic and chaos. Amidst all of this, the voiceless souls have no one to turn to.
                            These animals are desperately in need of our help to endure this challenging time.</div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow0" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="3" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea lazyloaded gm-added gm-loaded gm-observing gm-observing-cb"
                        data-gumlet="https://images.donatekart.com/campaign/cover/support-people-affected-by-cyclone927754067.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/support-people-affected-by-cyclone927754067.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Devastating Floods And Heavy Rainfall Is Wreaking
                            Havoc In Chennai &amp; Andhra Pradesh, Stand With The Victims</div>
                        <div class="showcase-campaigns_desc__1PfaB">As Cyclone Michaung moves towards the South Andhra
                            Pradesh coast from Tamil Nadu, causing widespread devastation, numerous families find
                            themselves battling with the aftermath of intense rainfall, strong winds, and extensive
                            flooding. These unfortunate souls have either lost their homes or their source of
                            livelihood. They were able to build a life for themselves after years of hard work and toil.
                            But in the face of Nature’s fury, everyone is helpless.</div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow1" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="4" aria-hidden="false" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item react-multi-carousel-item--active ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Support-Dipala-Chauhan61958920.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Support-Dipala-Chauhan61958920.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Even At 66, Dipala Refuses To Stop Working For The
                            Voiceless And Injured Animals Of Himachal </div>
                        <div class="showcase-campaigns_desc__1PfaB">Dipala Chauhan has dedicated her life to caring for
                            the vulnerable animals in her community. However, each passing day brings increasing
                            challenges to this demanding task of animal rescue. But she is not one to give up. Dipala is
                            a woman on a mission who works tirelessly for the voiceless and abandoned animals. </div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow2" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="5" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Support-children-this-winter647825417.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Support-children-this-winter647825417.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">A Simple Blanket Can Be A Lifeline For The Homeless
                            During Cold Nights, Donate Now</div>
                        <div class="showcase-campaigns_desc__1PfaB"> As we cozy up in the warmth of our homes, there are
                            countless souls battling the biting cold on the streets and slums of India. Little children
                            shiver under tattered blankets, and families huddle together for a little bit of warmth. But
                            amidst this darkness, Voice of Slum is like a beacon of hope for these unfortunate souls.
                            Voice of Slum has embarked on a mission to bring warmth and hope to those who face the harsh
                            realities of winter every day. </div><a class="showcase-campaigns_donateNowLink__3Vi-N"
                            id="donateNow3" target="_self">Donate Now &nbsp;<svg aria-hidden="true" focusable="false"
                                data-prefix="fas" data-icon="arrow-right" class="svg-inline--fa fa-arrow-right fa-w-14 "
                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="6" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Help-Widows-of-Vrindavan254107874.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Help-Widows-of-Vrindavan254107874.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Hungry, Cold &amp; Alone, Vrindavan's Matajis Are
                            Struggling To Survive Winter</div>
                        <div class="showcase-campaigns_desc__1PfaB">Pain and suffering have become an inseparable part
                            of their lives - but these abandoned mothers deserve a life of happiness and comfort. All
                            their lives, they have toiled hard for their families and even now, in their final years,
                            they are all alone. You can change this by donating warm clothes, blankets, and nourishing
                            milk to these Matajis in Vrindavan.</div><a class="showcase-campaigns_donateNowLink__3Vi-N"
                            id="donateNow4" target="_self">Donate Now &nbsp;<svg aria-hidden="true" focusable="false"
                                data-prefix="fas" data-icon="arrow-right" class="svg-inline--fa fa-arrow-right fa-w-14 "
                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="7" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Donate-This-Winter397702291.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Donate-This-Winter397702291.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">As The Sadhus Shiver In Silence While Meditating,
                            Give Them Warmth &amp; Hope This Winter</div>
                        <div class="showcase-campaigns_desc__1PfaB">As winter approaches, the challenges of sadhus only
                            increase. Dedicated to their prayer and meditation, thousands of them are left to brave the
                            cold on the streets with nothing to call their own. This winter, let’s give these sadhus the
                            safety and warmth they need to survive.</div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow5" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="8" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/dog-coats-for-strays644750787.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/dog-coats-for-strays644750787.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">This Winter, Let's Come Together To Keep Countless
                            Strays Safe And Healthy</div>
                        <div class="showcase-campaigns_desc__1PfaB"> In winter, stray dogs are often left to fend for
                            themselves in the freezing cold, with no warm shelter or food to protect them from the
                            extreme weather conditions. As a result, they are more susceptible to illnesses,
                            hypothermia, and frostbite. However, together we can ensure that they stay safe and warm
                            during the winter.</div><a class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow6"
                            target="_self">Donate Now &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas"
                                data-icon="arrow-right" class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="9" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/support-people-through-the-harsh-winters2116700946.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/support-people-through-the-harsh-winters2116700946.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">This Winter, Save Countless Lives With Donatekart,
                            One Blanket At A Time</div>
                        <div class="showcase-campaigns_desc__1PfaB">As the temperatures drop we hear heartbreaking news
                            reports of the homeless succumbing to the harsh winter conditions. It is time we step up and
                            decide to save these innocent lives. Donatekart Foundation is working with trusted NGOs to
                            ensure that these poor and underprivileged souls are not left all alone during the winter
                            months. You can join their mission and make a difference. </div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow7" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="10" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Save-Kids-From-The-Cold1303121969.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Save-Kids-From-The-Cold1303121969.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Warm Clothes Are A Luxury These Poor Kids Can’t
                            Afford, Save Them From The Cold </div>
                        <div class="showcase-campaigns_desc__1PfaB">At an age when these kids should be going to school,
                            learning, and playing, thousands of poor kids in India are struggling to make it through the
                            winter. Lack of warm clothing, adequate shelter, and nutritious food during winter can make
                            them more susceptible to illnesses and have a profound impact on their well-being. They need
                            our support to brave the cold. </div><a class="showcase-campaigns_donateNowLink__3Vi-N"
                            id="donateNow8" target="_self">Donate Now &nbsp;<svg aria-hidden="true" focusable="false"
                                data-prefix="fas" data-icon="arrow-right" class="svg-inline--fa fa-arrow-right fa-w-14 "
                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="11" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/Help-stray-animals-stuck-in-cyclone614687594.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/Help-stray-animals-stuck-in-cyclone614687594.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">As Cyclone Michaung Lashes Through Chennai, Support
                            Countless Strays In Need Of Help</div>
                        <div class="showcase-campaigns_desc__1PfaB">Cyclone Michaung has turned out to be even more
                            catastrophic than any disaster Chennai has seen before. Apartment buildings and
                            neighbourhoods are lying underwater. People are leaving their homes for a safer location.
                            There is panic and chaos. Amidst all of this, the voiceless souls have no one to turn to.
                            These animals are desperately in need of our help to endure this challenging time.</div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow0" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
            <li data-index="12" aria-hidden="true" style="flex: 1 1 auto; position: relative; width: 800px;"
                class="react-multi-carousel-item  ">
                <div class="showcase-campaigns_slidesWrapper__3jIAc"><img
                        class="showcase-campaigns_campaignImg__un9ea gm-added gm-loaded gm-observing gm-observing-cb lazyloaded"
                        data-gumlet="https://images.donatekart.com/campaign/cover/support-people-affected-by-cyclone927754067.jpg"
                        loading="lazy"
                        src="https://dkprodimages.gumlet.io/campaign/cover/support-people-affected-by-cyclone927754067.jpg?format=webp&amp;w=800&amp;dpr=1.0">
                    <div class="showcase-campaigns_detailWrapper__2AtDj">
                        <div class="showcase-campaigns_featured__dGhvb"><span>Featured</span></div>
                        <div class="showcase-campaigns_title__1Rftr">Devastating Floods And Heavy Rainfall Is Wreaking
                            Havoc In Chennai &amp; Andhra Pradesh, Stand With The Victims</div>
                        <div class="showcase-campaigns_desc__1PfaB">As Cyclone Michaung moves towards the South Andhra
                            Pradesh coast from Tamil Nadu, causing widespread devastation, numerous families find
                            themselves battling with the aftermath of intense rainfall, strong winds, and extensive
                            flooding. These unfortunate souls have either lost their homes or their source of
                            livelihood. They were able to build a life for themselves after years of hard work and toil.
                            But in the face of Nature’s fury, everyone is helpless.</div><a
                            class="showcase-campaigns_donateNowLink__3Vi-N" id="donateNow1" target="_self">Donate Now
                            &nbsp;<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                                class="svg-inline--fa fa-arrow-right fa-w-14 " role="img"
                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                <path fill="currentColor"
                                    d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                                </path>
                            </svg></a>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<section class="campaign-search-bar_crowdfundingPlatformWrapper__1dyvO">
    <div class="campaign-search-bar_searchBarContainer__GS4DE">
        <div class="search-bar_searchBarContainer__gcFAB campaign-search-bar_searchBar__AbWIU ">
            <div class="search-bar_inputGroup__sQ-5G "><input type="text" id="searchBar"
                    class="search-bar_searchInput__srAHb campaign-search-bar_searchInput__pslSO"
                    placeholder="Search By Campaign Title Or NGO Name" value="" autocomplete="off">
                <div class="search-bar_inputGroupAddon__4lNWC"><button class="search-bar_btnSearch__Qvd6Q"><i><svg
                                aria-hidden="true" focusable="false" data-prefix="fas" data-icon="search"
                                class="svg-inline--fa fa-search fa-w-16 " role="img" xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 512 512">
                                <path fill="currentColor"
                                    d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z">
                                </path>
                            </svg></i></button></div>
            </div>
        </div>
    </div>
</section>
<div class="promo-card_card__2mkBA  home_promoCard__1K46q">
    <div class="promo-card_promoCardImgDiv__1Kg9w"></div>
    <div class="promo-card_promoCardDescription__2Dlk6">
        <h3 class="promo-card_title__rW5sa">Make A Difference Every Month</h3>
        <p class="promo-card_description__1i8OU">With our Social Investment Plan, you can now be a changemaker every
            month, and help uplift and empower those who are suffering.</p><button id="donateMonthlyBtn"
            class="promo-card_button__8wE9N">Donate Monthly Now</button>
    </div>
</div>
<section class="medical-campaigns_mainWrapper__3ZYn6">
    <div class="container">
        <div class="section-title_heading__2H9zs ">
            <div class="section-title_headingWrapper__31KBD">
                <h2>Medical Emergencies</h2>
            </div><a to="/life" class="section-title_link__2gz_R" href="/life">View All<!-- --> <svg aria-hidden="true"
                    focusable="false" data-prefix="fas" data-icon="arrow-right"
                    class="svg-inline--fa fa-arrow-right fa-w-14 " role="img" xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 448 512">
                    <path fill="currentColor"
                        d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                    </path>
                </svg></a>
        </div>
        <div class="dk-carousel_sliderContainer__3zuS0 medical-campaigns_sliderContainer__2S6fr">
            <div class="dk-carousel_slider__2p09r  medical-campaigns_slider__34eHv">
                <div class="dk-carousel_slide__3Uk9c medical-campaigns_slide__1C5xO" style="width: 380px;">
                    <div class="campaign-card_campaignCard__3h_CI medical-campaigns_campaignCard__1W15E ">
                        <div class="campaign-card_cardMainSection__3wvO5">
                            <div class="campaign-card_campaignImage__1Dfag"><img
                                    data-gumlet="https://images.donatekart.com/campaign/cover/Help-Lakhichand2106806133.jpg"
                                    class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                                    src="https://dkprodimages.gumlet.io/campaign/cover/Help-Lakhichand2106806133.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                                    class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                                    styles="[object Object]">Tax Benefit <span
                                        class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                            <div class="campaign-card_campaignDetailWrapper__1tPlX">
                                <div class="campaign-card_campaignSummary__1VBCd">
                                    <h4 class="campaign-card_campaignTitle__3Cjsz ">He Can’t Walk, Play Or Run Like
                                        Other Kids His Age, Help Lakhichand Get Life-Changing Surgery </h4>
                                    <div class="campaign-card_campaignAuthor__2CGti"><span
                                            class="campaign-card_authorImg__ukLIt">LD</span><span>By Lakhichand Dadabhau
                                            Shirsath </span></div>
                                </div>
                                <div class="campaign-card_campaignStats__2UM7R">
                                    <div class="campaign-card_statsWrapper__eFgvz">
                                        <div class="campaign-card_progressBarHeading__tZuXT"><span
                                                class="campaign-card_totalRaisedAmount__3Fl78">₹11,966</span> <span
                                                class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                        <div class="campaign-card_progressBarHeading__tZuXT"><img
                                                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                                class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                                width="16" loading="lazy">&nbsp;<span
                                                class="campaign-card_totalRaisedAmount__3Fl78">8</span> <span
                                                class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                                    </div>
                                    <div class="dk-progress-bar_backgroundBar__25DwK"
                                        style="height: 8px; border-radius: 4px;" title="2% Raised">
                                        <div class="dk-progress-bar_progressBar__3NzxJ"
                                            style="width: 2%; height: 8px; border-radius: 4px;">
                                            <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                                style="border-radius: 4px;"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn0"
                                        class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fab"
                                            data-icon="facebook-square"
                                            class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                            <path fill="currentColor"
                                                d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                            </path>
                                        </svg> Share</button><a id="donateNowBtn0"
                                        class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                        href="https://www.donatekart.com/life/Help-Lakhichand/#products">Donate Now</a>
                                </div>
                            </div><a id="campaignLink0" class="campaign-card_campaignLinkWrap__2ve4y"
                                href="https://www.donatekart.com/life/Help-Lakhichand/"></a>
                        </div>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c medical-campaigns_slide__1C5xO" style="width: 380px;">
                    <div class="campaign-card_campaignCard__3h_CI medical-campaigns_campaignCard__1W15E ">
                        <div class="campaign-card_cardMainSection__3wvO5">
                            <div class="campaign-card_campaignImage__1Dfag"><img
                                    data-gumlet="https://images.donatekart.com/campaign/cover/Help-Harshali689780148.jpg"
                                    class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                                    src="https://dkprodimages.gumlet.io/campaign/cover/Help-Harshali689780148.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                                    class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                                    styles="[object Object]">Tax Benefit <span
                                        class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                            <div class="campaign-card_campaignDetailWrapper__1tPlX">
                                <div class="campaign-card_campaignSummary__1VBCd">
                                    <h4 class="campaign-card_campaignTitle__3Cjsz ">Despite Selling His Land, This
                                        Farmer Can't Save His Only Child From Deadly Cancer</h4>
                                    <div class="campaign-card_campaignAuthor__2CGti"><span
                                            class="campaign-card_authorImg__ukLIt">HS</span><span>By Harshali Suresh
                                            Thorait</span></div>
                                </div>
                                <div class="campaign-card_campaignStats__2UM7R">
                                    <div class="campaign-card_statsWrapper__eFgvz">
                                        <div class="campaign-card_progressBarHeading__tZuXT"><span
                                                class="campaign-card_totalRaisedAmount__3Fl78">₹1,36,851</span> <span
                                                class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                        <div class="campaign-card_progressBarHeading__tZuXT"><img
                                                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                                class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                                width="16" loading="lazy">&nbsp;<span
                                                class="campaign-card_totalRaisedAmount__3Fl78">70</span> <span
                                                class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                                    </div>
                                    <div class="dk-progress-bar_backgroundBar__25DwK"
                                        style="height: 8px; border-radius: 4px;" title="68% Raised">
                                        <div class="dk-progress-bar_progressBar__3NzxJ"
                                            style="width: 68%; height: 8px; border-radius: 4px;">
                                            <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                                style="border-radius: 4px;"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn1"
                                        class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fab"
                                            data-icon="facebook-square"
                                            class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                            <path fill="currentColor"
                                                d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                            </path>
                                        </svg> Share</button><a id="donateNowBtn1"
                                        class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                        href="https://www.donatekart.com/life/Help-Harshali/#products">Donate Now</a>
                                </div>
                            </div><a id="campaignLink1" class="campaign-card_campaignLinkWrap__2ve4y"
                                href="https://www.donatekart.com/life/Help-Harshali/"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="campaigns_campaignsContainer__2etq0">
    <div class="container">
        <div class="campaigns_sectionContainer__UZtLo">
            <div class="section-title_heading__2H9zs ">
                <div class="section-title_headingWrapper__31KBD">
                    <h2>Categories</h2>
                </div><a to="/explorecampaigns" class="section-title_link__2gz_R" href="/explorecampaigns">View All
                    Campaigns <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right"
                        class="svg-inline--fa fa-arrow-right fa-w-14 " role="img" xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 448 512">
                        <path fill="currentColor"
                            d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z">
                        </path>
                    </svg></a>
            </div>
        </div>
    </div>
    <div class="container campaigns_mobContainer__1iA-d">
        <div class="">
            <div class="">
                <div id="categoriesCarousel">
                    <div class="dk-carousel_sliderContainer__3zuS0 ">
                        <div class="dk-carousel_slider__2p09r  category-list_campaignCarousel__1Zhz-">
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category0" title="Urgent"
                                    class="category-list_categoryDiv__3sBVH  category-list_active__1GJan"><span
                                        id="categoryIcon0" class="category-list_categoryIcon__1iBWP"><span
                                            class="category-list_urgentCategory__1aNbv"></span></span>
                                    <h3 id="categoryName0" class="category-list_categoryName__1ui-6">Urgent</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category1" title="Animals" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon1" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas" data-icon="paw"
                                            class="svg-inline--fa fa-paw fa-w-16 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                            <path fill="currentColor"
                                                d="M256 224c-79.41 0-192 122.76-192 200.25 0 34.9 26.81 55.75 71.74 55.75 48.84 0 81.09-25.08 120.26-25.08 39.51 0 71.85 25.08 120.26 25.08 44.93 0 71.74-20.85 71.74-55.75C448 346.76 335.41 224 256 224zm-147.28-12.61c-10.4-34.65-42.44-57.09-71.56-50.13-29.12 6.96-44.29 40.69-33.89 75.34 10.4 34.65 42.44 57.09 71.56 50.13 29.12-6.96 44.29-40.69 33.89-75.34zm84.72-20.78c30.94-8.14 46.42-49.94 34.58-93.36s-46.52-72.01-77.46-63.87-46.42 49.94-34.58 93.36c11.84 43.42 46.53 72.02 77.46 63.87zm281.39-29.34c-29.12-6.96-61.15 15.48-71.56 50.13-10.4 34.65 4.77 68.38 33.89 75.34 29.12 6.96 61.15-15.48 71.56-50.13 10.4-34.65-4.77-68.38-33.89-75.34zm-156.27 29.34c30.94 8.14 65.62-20.45 77.46-63.87 11.84-43.42-3.64-85.21-34.58-93.36s-65.62 20.45-77.46 63.87c-11.84 43.42 3.64 85.22 34.58 93.36z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName1" class="category-list_categoryName__1ui-6">Animals</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category2" title="Children" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon2" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas" data-icon="baby"
                                            class="svg-inline--fa fa-baby fa-w-12 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                            <path fill="currentColor"
                                                d="M192 160c44.2 0 80-35.8 80-80S236.2 0 192 0s-80 35.8-80 80 35.8 80 80 80zm-53.4 248.8l25.6-32-61.5-51.2L56.8 383c-11.4 14.2-11.7 34.4-.8 49l48 64c7.9 10.5 19.9 16 32 16 8.3 0 16.8-2.6 24-8 17.7-13.2 21.2-38.3 8-56l-29.4-39.2zm142.7-83.2l-61.5 51.2 25.6 32L216 448c-13.2 17.7-9.7 42.8 8 56 7.2 5.4 15.6 8 24 8 12.2 0 24.2-5.5 32-16l48-64c10.9-14.6 10.6-34.8-.8-49l-45.9-57.4zM376.7 145c-12.7-18.1-37.6-22.4-55.7-9.8l-40.6 28.5c-52.7 37-124.2 37-176.8 0L63 135.3C44.9 122.6 20 127 7.3 145-5.4 163.1-1 188 17 200.7l40.6 28.5c17 11.9 35.4 20.9 54.4 27.9V288h160v-30.8c19-7 37.4-16 54.4-27.9l40.6-28.5c18.1-12.8 22.4-37.7 9.7-55.8z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName2" class="category-list_categoryName__1ui-6">Children</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category3" title="Elderly" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon3" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas" data-icon="male"
                                            class="svg-inline--fa fa-male fa-w-6 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512">
                                            <path fill="currentColor"
                                                d="M96 0c35.346 0 64 28.654 64 64s-28.654 64-64 64-64-28.654-64-64S60.654 0 96 0m48 144h-11.36c-22.711 10.443-49.59 10.894-73.28 0H48c-26.51 0-48 21.49-48 48v136c0 13.255 10.745 24 24 24h16v136c0 13.255 10.745 24 24 24h64c13.255 0 24-10.745 24-24V352h16c13.255 0 24-10.745 24-24V192c0-26.51-21.49-48-48-48z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName3" class="category-list_categoryName__1ui-6">Elderly</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category4" title="Faith" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon4" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="praying-hands" class="svg-inline--fa fa-praying-hands fa-w-20 "
                                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                                            <path fill="currentColor"
                                                d="M272 191.91c-17.6 0-32 14.4-32 32v80c0 8.84-7.16 16-16 16s-16-7.16-16-16v-76.55c0-17.39 4.72-34.47 13.69-49.39l77.75-129.59c9.09-15.16 4.19-34.81-10.97-43.91-14.45-8.67-32.72-4.3-42.3 9.21-.2.23-.62.21-.79.48l-117.26 175.9C117.56 205.9 112 224.31 112 243.29v80.23l-90.12 30.04A31.974 31.974 0 0 0 0 383.91v96c0 10.82 8.52 32 32 32 2.69 0 5.41-.34 8.06-1.03l179.19-46.62C269.16 449.99 304 403.8 304 351.91v-128c0-17.6-14.4-32-32-32zm346.12 161.73L528 323.6v-80.23c0-18.98-5.56-37.39-16.12-53.23L394.62 14.25c-.18-.27-.59-.24-.79-.48-9.58-13.51-27.85-17.88-42.3-9.21-15.16 9.09-20.06 28.75-10.97 43.91l77.75 129.59c8.97 14.92 13.69 32 13.69 49.39V304c0 8.84-7.16 16-16 16s-16-7.16-16-16v-80c0-17.6-14.4-32-32-32s-32 14.4-32 32v128c0 51.89 34.84 98.08 84.75 112.34l179.19 46.62c2.66.69 5.38 1.03 8.06 1.03 23.48 0 32-21.18 32-32v-96c0-13.77-8.81-25.99-21.88-30.35z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName4" class="category-list_categoryName__1ui-6">Faith</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category5" title="Disability" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon5" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="wheelchair" class="svg-inline--fa fa-wheelchair fa-w-16 "
                                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                            <path fill="currentColor"
                                                d="M496.101 385.669l14.227 28.663c3.929 7.915.697 17.516-7.218 21.445l-65.465 32.886c-16.049 7.967-35.556 1.194-43.189-15.055L331.679 320H192c-15.925 0-29.426-11.71-31.679-27.475C126.433 55.308 128.38 70.044 128 64c0-36.358 30.318-65.635 67.052-63.929 33.271 1.545 60.048 28.905 60.925 62.201.868 32.933-23.152 60.423-54.608 65.039l4.67 32.69H336c8.837 0 16 7.163 16 16v32c0 8.837-7.163 16-16 16H215.182l4.572 32H352a32 32 0 0 1 28.962 18.392L438.477 396.8l36.178-18.349c7.915-3.929 17.517-.697 21.446 7.218zM311.358 352h-24.506c-7.788 54.204-54.528 96-110.852 96-61.757 0-112-50.243-112-112 0-41.505 22.694-77.809 56.324-97.156-3.712-25.965-6.844-47.86-9.488-66.333C45.956 198.464 0 261.963 0 336c0 97.047 78.953 176 176 176 71.87 0 133.806-43.308 161.11-105.192L311.358 352z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName5" class="category-list_categoryName__1ui-6">Disability</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category6" title="Hunger" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon6" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas" data-icon="utensils"
                                            class="svg-inline--fa fa-utensils fa-w-13 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 416 512">
                                            <path fill="currentColor"
                                                d="M207.9 15.2c.8 4.7 16.1 94.5 16.1 128.8 0 52.3-27.8 89.6-68.9 104.6L168 486.7c.7 13.7-10.2 25.3-24 25.3H80c-13.7 0-24.7-11.5-24-25.3l12.9-238.1C27.7 233.6 0 196.2 0 144 0 109.6 15.3 19.9 16.1 15.2 19.3-5.1 61.4-5.4 64 16.3v141.2c1.3 3.4 15.1 3.2 16 0 1.4-25.3 7.9-139.2 8-141.8 3.3-20.8 44.7-20.8 47.9 0 .2 2.7 6.6 116.5 8 141.8.9 3.2 14.8 3.4 16 0V16.3c2.6-21.6 44.8-21.4 48-1.1zm119.2 285.7l-15 185.1c-1.2 14 9.9 26 23.9 26h56c13.3 0 24-10.7 24-24V24c0-13.2-10.7-24-24-24-82.5 0-221.4 178.5-64.9 300.9z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName6" class="category-list_categoryName__1ui-6">Hunger</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category7" title="Education" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon7" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="graduation-cap" class="svg-inline--fa fa-graduation-cap fa-w-20 "
                                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                                            <path fill="currentColor"
                                                d="M622.34 153.2L343.4 67.5c-15.2-4.67-31.6-4.67-46.79 0L17.66 153.2c-23.54 7.23-23.54 38.36 0 45.59l48.63 14.94c-10.67 13.19-17.23 29.28-17.88 46.9C38.78 266.15 32 276.11 32 288c0 10.78 5.68 19.85 13.86 25.65L20.33 428.53C18.11 438.52 25.71 448 35.94 448h56.11c10.24 0 17.84-9.48 15.62-19.47L82.14 313.65C90.32 307.85 96 298.78 96 288c0-11.57-6.47-21.25-15.66-26.87.76-15.02 8.44-28.3 20.69-36.72L296.6 284.5c9.06 2.78 26.44 6.25 46.79 0l278.95-85.7c23.55-7.24 23.55-38.36 0-45.6zM352.79 315.09c-28.53 8.76-52.84 3.92-65.59 0l-145.02-44.55L128 384c0 35.35 85.96 64 192 64s192-28.65 192-64l-14.18-113.47-145.03 44.56z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName7" class="category-list_categoryName__1ui-6">Education</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category8" title="Women" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon8" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas" data-icon="female"
                                            class="svg-inline--fa fa-female fa-w-8 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512">
                                            <path fill="currentColor"
                                                d="M128 0c35.346 0 64 28.654 64 64s-28.654 64-64 64c-35.346 0-64-28.654-64-64S92.654 0 128 0m119.283 354.179l-48-192A24 24 0 0 0 176 144h-11.36c-22.711 10.443-49.59 10.894-73.28 0H80a24 24 0 0 0-23.283 18.179l-48 192C4.935 369.305 16.383 384 32 384h56v104c0 13.255 10.745 24 24 24h32c13.255 0 24-10.745 24-24V384h56c15.591 0 27.071-14.671 23.283-29.821z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName8" class="category-list_categoryName__1ui-6">Women</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category9" title="Medical" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon9" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="briefcase-medical"
                                            class="svg-inline--fa fa-briefcase-medical fa-w-16 " role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                            <path fill="currentColor"
                                                d="M464 128h-80V80c0-26.5-21.5-48-48-48H176c-26.5 0-48 21.5-48 48v48H48c-26.5 0-48 21.5-48 48v288c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V176c0-26.5-21.5-48-48-48zM192 96h128v32H192V96zm160 248c0 4.4-3.6 8-8 8h-56v56c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-56h-56c-4.4 0-8-3.6-8-8v-48c0-4.4 3.6-8 8-8h56v-56c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v56h56c4.4 0 8 3.6 8 8v48z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName9" class="category-list_categoryName__1ui-6">Medical</h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category10" title="Disaster Relief" class="category-list_categoryDiv__3sBVH  ">
                                    <span id="categoryIcon10" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="house-damage" class="svg-inline--fa fa-house-damage fa-w-18 "
                                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                                            <path fill="currentColor"
                                                d="M288 114.96L69.47 307.71c-1.62 1.46-3.69 2.14-5.47 3.35V496c0 8.84 7.16 16 16 16h149.23L192 439.19l104.11-64-60.16-119.22L384 392.75l-104.11 64L319.81 512H496c8.84 0 16-7.16 16-16V311.1c-1.7-1.16-3.72-1.82-5.26-3.2L288 114.96zm282.69 121.32L512 184.45V48c0-8.84-7.16-16-16-16h-64c-8.84 0-16 7.16-16 16v51.69L314.75 10.31C307.12 3.45 297.56.01 288 0s-19.1 3.41-26.7 10.27L5.31 236.28c-6.57 5.91-7.12 16.02-1.21 22.6l21.4 23.82c5.9 6.57 16.02 7.12 22.6 1.21L277.42 81.63c6.05-5.33 15.12-5.33 21.17 0L527.91 283.9c6.57 5.9 16.69 5.36 22.6-1.21l21.4-23.82c5.9-6.57 5.36-16.69-1.22-22.59z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName10" class="category-list_categoryName__1ui-6">Disaster Relief
                                    </h3>
                                </div>
                            </div>
                            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 130.75px;">
                                <div id="category11" title="Others" class="category-list_categoryDiv__3sBVH  "><span
                                        id="categoryIcon11" class="category-list_categoryIcon__1iBWP"><svg
                                            aria-hidden="true" focusable="false" data-prefix="fas"
                                            data-icon="ellipsis-h" class="svg-inline--fa fa-ellipsis-h fa-w-16 "
                                            role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                            <path fill="currentColor"
                                                d="M328 256c0 39.8-32.2 72-72 72s-72-32.2-72-72 32.2-72 72-72 72 32.2 72 72zm104-72c-39.8 0-72 32.2-72 72s32.2 72 72 72 72-32.2 72-72-32.2-72-72-72zm-352 0c-39.8 0-72 32.2-72 72s32.2 72 72 72 72-32.2 72-72-32.2-72-72-72z">
                                            </path>
                                        </svg></span>
                                    <h3 id="categoryName11" class="category-list_categoryName__1ui-6">Others</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="campaigns_cardWrapper__2oFYt">
        <div class="container campaigns_cardContainer__nGHUh">
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/Help-Sudheer398622271.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/Help-Sudheer398622271.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">From Begging To Inspiring Countless Tribal
                                Kids In Beed, Sudheer Is Transforming Their Lives</h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">PS</span><span>By Pardhi samaj janjagruti
                                    Sevabhavi sanstha</span></div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹1,79,469</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">171</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="7% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 7%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn0"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn0"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/PSJSS/Help-Sudheer/#products">Donate Now</a></div>
                    </div><a id="campaignLink0" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/PSJSS/Help-Sudheer/"></a>
                </div>
            </div>
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/Support-in-upliftment-of-children19440816.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/Support-in-upliftment-of-children19440816.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">ROSA Strives To Break The Cycle Of Poverty
                                Of The Musahar Community By Empowering Their Children</h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">RO</span><span>By Rural Organization for
                                    Social Advancement </span></div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹17,964</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">11</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="0% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 0%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn1"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn1"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/ROSA/Support-in-upliftment-of-children/#products">Donate
                                Now</a></div>
                    </div><a id="campaignLink1" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/ROSA/Support-in-upliftment-of-children/"></a>
                </div>
            </div>
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/look-after-special-children305480039.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/look-after-special-children305480039.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">Father To 33 Kids, This Man Is Working
                                Tirelessly For The Mentally Disabled Children In Haryana </h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">PA</span><span>By Prabhat An Awakening</span>
                            </div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹10,09,542</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">1,016</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="25% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 25%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn2"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn2"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/Support-PAA/look-after-special-children/#products">Donate
                                Now</a></div>
                    </div><a id="campaignLink2" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/Support-PAA/look-after-special-children/"></a>
                </div>
            </div>
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/support-disabled-animals1450390427.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/support-disabled-animals1450390427.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">With Love And Care, These Disabled Strays
                                Can Live A Healthy And Fulfilling Life </h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">JW</span><span>By Jeev Welfare Trust</span>
                            </div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹23,977</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">23</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="1% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 1%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn3"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn3"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/Jeev-welfare-trust/support-disabled-animals/#products">Donate
                                Now</a></div>
                    </div><a id="campaignLink3" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/Jeev-welfare-trust/support-disabled-animals/"></a>
                </div>
            </div>
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/Support-AWT1470508719.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/Support-AWT1470508719.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">This Couple In Jharkhand Has Created A Safe
                                Haven For Countless Sick, Abandoned &amp; Paralyzed Dogs</h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">AW</span><span>By ANIMAL WELFARE TRUST</span>
                            </div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹19,666</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">21</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="1% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 1%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn4"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn4"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/animalwelfaretrust/Support-AWT/#products">Donate
                                Now</a></div>
                    </div><a id="campaignLink4" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/animalwelfaretrust/Support-AWT/"></a>
                </div>
            </div>
            <div class="campaign-card_campaignCard__3h_CI campaigns_homeCards__37690 ">
                <div class="campaign-card_cardMainSection__3wvO5">
                    <div class="campaign-card_campaignImage__1Dfag"><img
                            data-gumlet="https://images.donatekart.com/campaign/cover/support-disabled-villagers318685469.jpg"
                            class="gm-added gm-loaded gm-observing gm-observing-cb" loading="lazy"
                            src="https://dkprodimages.gumlet.io/campaign/cover/support-disabled-villagers318685469.jpg?format=webp&amp;w=360&amp;dpr=1.0"><span
                            class="tax-benefit-tool-tip_taxBenefit__2R0fU tax-benefit-tool-tip_cardTooltip__3bARY"
                            styles="[object Object]">Tax Benefit <span
                                class="tax-benefit-tool-tip_icon__3bD7_">i</span></span></div>
                    <div class="campaign-card_campaignDetailWrapper__1tPlX">
                        <div class="campaign-card_campaignSummary__1VBCd">
                            <h4 class="campaign-card_campaignTitle__3Cjsz ">The Water They Drink Is Killing Them, Help
                                Hundreds Of Villagers In Sonbhadra Survive</h4>
                            <div class="campaign-card_campaignAuthor__2CGti"><span
                                    class="campaign-card_authorImg__ukLIt">HW</span><span>By Hope Welfare Trust</span>
                            </div>
                        </div>
                        <div class="campaign-card_campaignStats__2UM7R">
                            <div class="campaign-card_statsWrapper__eFgvz">
                                <div class="campaign-card_progressBarHeading__tZuXT"><span
                                        class="campaign-card_totalRaisedAmount__3Fl78">₹1,52,855</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Raised</span></div>
                                <div class="campaign-card_progressBarHeading__tZuXT"><img
                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGlkPSJHcm91cF8yMTMiIGRhdGEtbmFtZT0iR3JvdXAgMjEzIiB3aWR0aD0iMzAuMzUiIGhlaWdodD0iMzIuMjI5IiB2aWV3Qm94PSIwIDAgMzAuMzUgMzIuMjI5Ij4KICA8ZyBpZD0iR3JvdXBfMTk0IiBkYXRhLW5hbWU9Ikdyb3VwIDE5NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAuODE0IDApIj4KICAgIDxnIGlkPSJHcm91cF8xOTMiIGRhdGEtbmFtZT0iR3JvdXAgMTkzIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfNjgzIiBkYXRhLW5hbWU9IlBhdGggNjgzIiBkPSJNMTAsNC42MjJBMi42LDIuNiwwLDAsMSwxMi42MjIsMmEyLjg3NCwyLjg3NCwwLDAsMSwyLjE0Ni45OTNBMi44NzQsMi44NzQsMCwwLDEsMTYuOTEzLDJhMi42LDIuNiwwLDAsMSwyLjYyMiwyLjYyMmMwLDEuNjY5LTEuOTg3LDMuNTg0LTQuMjM1LDUuNjM0YS43OTQuNzk0LDAsMCwxLTEuMDczLDBDMTEuOTg3LDguMjA2LDEwLDYuMjkxLDEwLDQuNjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTAgLTIpIiBmaWxsPSIjMDAwMDAwIi8+CiAgICA8L2c+CiAgPC9nPgogIDxnIGlkPSJJY29ubHlfQnVsa19Qcm9maWxlIiBkYXRhLW5hbWU9Ikljb25seS9CdWxrL1Byb2ZpbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMy43MjYpIj4KICAgIDxnIGlkPSJQcm9maWxlIj4KICAgICAgPHBhdGggaWQ9IkZpbGxfMSIgZGF0YS1uYW1lPSJGaWxsIDEiIGQ9Ik0xMy4wNDIsMEM2LjAwOCwwLDAsMS4yMTgsMCw2LjA5czUuOTcsNi4xMzUsMTMuMDQyLDYuMTM1YzcuMDM0LDAsMTMuMDQyLTEuMjE2LDEzLjA0Mi02LjA5UzIwLjExNSwwLDEzLjA0MiwwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDE2LjI3NykiIGZpbGw9IiMwMDAwMDAiLz4KICAgICAgPHBhdGggaWQ9IkZpbGxfNCIgZGF0YS1uYW1lPSJGaWxsIDQiIGQ9Ik03LjA4MSwxMy44NWE2Ljk4LDYuOTgsMCwwLDAsNy4wODEtNi45MjVBNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDAsNi45OCw2Ljk4LDAsMCwwLDAsNi45MjUsNi45OCw2Ljk4LDAsMCwwLDcuMDgxLDEzLjg1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1Ljk2KSIgZmlsbD0iIzAwMDAwMCIvPgogICAgPC9nPgogIDwvZz4KPC9zdmc+"
                                        class="campaign-card_backerIcon__-gSlf gm-added gm-observing gm-observing-cb"
                                        width="16" loading="lazy">&nbsp;<span
                                        class="campaign-card_totalRaisedAmount__3Fl78">85</span> <span
                                        class="campaign-card_totalRequiredAmount__1Of2S">Backers</span></div>
                            </div>
                            <div class="dk-progress-bar_backgroundBar__25DwK" style="height: 8px; border-radius: 4px;"
                                title="6% Raised">
                                <div class="dk-progress-bar_progressBar__3NzxJ"
                                    style="width: 6%; height: 8px; border-radius: 4px;">
                                    <div class="dk-progress-bar_animatedProgressBar__3NDGy "
                                        style="border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="campaign-card_btnSection__2EXX_"><button id="shareBtn5"
                                class="campaign-card_btn__7FYJl campaign-card_readMoreBtn__lA6h0 campaign-card_dskView__3hyFT"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square"
                                    class="svg-inline--fa fa-facebook-square fa-w-14 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path fill="currentColor"
                                        d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z">
                                    </path>
                                </svg> Share</button><a id="donateNowBtn5"
                                class="campaign-card_btn__7FYJl campaign-card_donateBtn__2y8iz"
                                href="https://www.donatekart.com/HWT/support-disabled-villagers/#products">Donate
                                Now</a></div>
                    </div><a id="campaignLink5" class="campaign-card_campaignLinkWrap__2ve4y"
                        href="https://www.donatekart.com/HWT/support-disabled-villagers/"></a>
                </div>
            </div>
        </div>
        <div class="campaigns_viewMoreWrapper__1fDuz">
            <p class="view-more-button_seeMoreBtn__37voR"><button id="" class="view-more-button_btn__36pn4 ">View
                    More</button></p>
        </div>
    </div>
</section>
<div class="container live-data_liveDataWrapper__1CYQJ">
    <div class="live-data_gridWrapper__1JMSv">
        <h1 class="live-data_header__1fj2v"><span class="live-data_amountDonated__OqFwn">₹ 75692</span> raised in the
            past hour</h1>
        <div class="live-data_statsWrapper__2QxG5">
            <div class="live-data_recentDonors__3aXyV">
                <p class="live-data_recentDonorVal__LsXjN">60</p><label class="live-data_label__y3wog">Donors</label>
            </div>
            <div class="live-data_campaigns__2O0U8">
                <p class="live-data_recentDonorVal__LsXjN">17</p><label class="live-data_label__y3wog">Campaigns</label>
            </div>
        </div>
    </div>
    <div class="live-data_liveDonorsWrapper__1s4j8">
        <div class="live-data_pulsateWrapper__1Ed0F">
            <div class="live-data_pulse__OWZWo"></div><label class="live-data_label__y3wog">Live</label>
        </div>
        <p class="live-data_subHeader__jzqVh">People giving now</p>
        <div class="dk-carousel_sliderContainer__3zuS0 ">
            <div class="dk-carousel_slider__2p09r  ">
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">3 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Chandrashekhar Dehankar</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Donate-This-Winter">As The Sadhus Shiver In Silence
                            While Meditating, Give Them Warmth &amp; Hope This Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                200</span><span class="live-data_amount__1tU-G">3 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Padma</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-Rupmaya-Prabhu/Feed-Vrindavan">From Medical Student To
                            Sadhu, Rupmaya Prabhuji Left Everything Behind To Serve Hundreds In Need</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                520</span><span class="live-data_amount__1tU-G">4 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Anuja</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">6 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">JAI KRISHAN MAHCH</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1260</span><span class="live-data_amount__1tU-G">6 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Deepak kaushik</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                4500</span><span class="live-data_amount__1tU-G">8 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Deepakprasad Palanikumar</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/life/Help-Baby-of-Mary-Clancy-511782928"> Baby of Mary Clancy
                            and Anandaraj is in NICU, Please Show Your Support</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1085</span><span class="live-data_amount__1tU-G">8 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vardhaman Jadhav</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Support-Elderly-This-DaanUtsav">This 63 Year Old Is
                            Working Relentlessly To Feed Warm Meals To Senior Citizens</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                400</span><span class="live-data_amount__1tU-G">8 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Rashmi Work</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Rescue-Foundation/Support-Triveni-Acharya">Despite Losing Her
                            Husband, Triveni Continues To Fight For Countless Young Girls, Help Her </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                930</span><span class="live-data_amount__1tU-G">8 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Shanker S</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                301</span><span class="live-data_amount__1tU-G">9 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vikas Singh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                700</span><span class="live-data_amount__1tU-G">9 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Sangita</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                600</span><span class="live-data_amount__1tU-G">10 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Meenakshi</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                850</span><span class="live-data_amount__1tU-G">11 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Rashmi Work</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/shyam-gau-seva/help-for-disabled-cows">Shri Shyam Gau Seva
                            Dham: A Haven for Injured and Disabled Cows in Haryana</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">13 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">N D Gaur</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                3000</span><span class="live-data_amount__1tU-G">15 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">PRACHI MAHAGAONKAR</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                201</span><span class="live-data_amount__1tU-G">16 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Shivcharan sen</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-SSJT/take-care-of-animals">When The World Ignores Their
                            Pain, Bhesana Gaushala Gives Hundreds Of Animals A Safe Home </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">16 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Leena Pednekar</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">18 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Rudrak Gupta</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                500</span><span class="live-data_amount__1tU-G">19 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">M G Rajesh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1700</span><span class="live-data_amount__1tU-G">20 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Deepali Mathur</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Donate-This-Winter">As The Sadhus Shiver In Silence
                            While Meditating, Give Them Warmth &amp; Hope This Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                2000</span><span class="live-data_amount__1tU-G">20 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Deepali Mathur</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1800</span><span class="live-data_amount__1tU-G">21 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Rajib Mukherjee.</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Support-matajis-this-winter">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                100</span><span class="live-data_amount__1tU-G">21 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vignesh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/life/Help-Baby-of-Mary-Clancy-511782928"> Baby of Mary Clancy
                            and Anandaraj is in NICU, Please Show Your Support</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                5045</span><span class="live-data_amount__1tU-G">21 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Mannish G</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/NAFB/support-Rambhai">A Mentor To Blind Kids, This Visually
                            Challenged Man Is Breaking Barriers And Empowering Dreams</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                600</span><span class="live-data_amount__1tU-G">21 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vikas</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/dog-coats-for-strays">This Winter, Let's Come
                            Together To Keep Countless Strays Safe And Healthy</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                500</span><span class="live-data_amount__1tU-G">25 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Santhosh Kumar</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1020</span><span class="live-data_amount__1tU-G">28 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Dilip Mohan</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                300</span><span class="live-data_amount__1tU-G">29 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Arvind Singh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                5000</span><span class="live-data_amount__1tU-G">29 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Mannish G</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                400</span><span class="live-data_amount__1tU-G">30 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Kapil</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-PAA/look-after-special-children">Father To 33 Kids,
                            This Man Is Working Tirelessly For The Mentally Disabled Children In Haryana </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">34 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Shyama</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                200</span><span class="live-data_amount__1tU-G">34 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Subhi singh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1890</span><span class="live-data_amount__1tU-G">34 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vansh Kavish Khamesra</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">34 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Surya Erlapati</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/dog-coats-for-strays">This Winter, Let's Come
                            Together To Keep Countless Strays Safe And Healthy</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                200</span><span class="live-data_amount__1tU-G">36 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">MbKamath</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                4000</span><span class="live-data_amount__1tU-G">37 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Shubham</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹ 10</span><span
                                class="live-data_amount__1tU-G">37 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Harshavardhan Ashok Jagtap</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Earth-Charitable-Foundation-515415198/Help-Earth-Charitable-Foundation">Sachin
                            Is On A Mission To Give Stray Animals 24x7 Medical Care</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">37 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Kim Giani</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                980</span><span class="live-data_amount__1tU-G">39 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">MINAXI K VAISHNAV</p><a
                            class="live-data_campaignLink__1SAz9" href="https://donatekart.com/NAFB/support-Rambhai">A
                            Mentor To Blind Kids, This Visually Challenged Man Is Breaking Barriers And Empowering
                            Dreams</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1700</span><span class="live-data_amount__1tU-G">40 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Nalini</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1100</span><span class="live-data_amount__1tU-G">40 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Sailaja Mulugu</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                240</span><span class="live-data_amount__1tU-G">40 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Amar Vangani</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">41 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Manikandan K</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                300</span><span class="live-data_amount__1tU-G">41 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Omkar jadhav</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-SSJT/take-care-of-animals">When The World Ignores Their
                            Pain, Bhesana Gaushala Gives Hundreds Of Animals A Safe Home </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                250</span><span class="live-data_amount__1tU-G">42 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Ruchi</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                625</span><span class="live-data_amount__1tU-G">43 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Anonymous</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                2000</span><span class="live-data_amount__1tU-G">43 minutes ago</span></p>
                        <p class="live-data_donorName__2bmUT">Prakash Reddy</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                250</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Mohan Rao Macherla Advocate</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                300</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Aditi Kulkarni - Moghe</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                200</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">saket kumar sahu</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/dog-coats-for-strays">This Winter, Let's Come
                            Together To Keep Countless Strays Safe And Healthy</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">diksha</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-PAA/look-after-special-children">Father To 33 Kids,
                            This Man Is Working Tirelessly For The Mentally Disabled Children In Haryana </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                300</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Vilas karnewar</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                420</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Jyoti</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Support-Rupmaya-Prabhu/Feed-Vrindavan">From Medical Student To
                            Sadhu, Rupmaya Prabhuji Left Everything Behind To Serve Hundreds In Need</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Nakul Misra</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                465</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Anonymous</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Rajaram/support-rajaram-gaushala">Over 6000+ Cows Have Found A
                            Forever Home At Rajaram Gaushala, Support Them </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                3000</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Ramesh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                500</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Archana joshi</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1500</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">M Narang</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Dipala-Chauhan/Support-Dipala-Chauhan">Even At 66, Dipala
                            Refuses To Stop Working For The Voiceless And Injured Animals Of Himachal </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                400</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Anonymous</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1000</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">T n bhutia</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Save-Kids-From-Cold">Warm Clothes Are A Luxury These
                            Poor Kids Can’t Afford, Save Them From The Cold </a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                3170</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Gurpreet kaur Rajpal</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                600</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Ayush Agarwal</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/Help-stray-animals-stuck-in-cyclone">As Cyclone
                            Michaung Lashes Through Chennai, Support Countless Strays In Need Of Help</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                400</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Manoj Kumar</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                300</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Manoj Kumar</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Donatekart/support-people-affected-by-cyclone">Devastating
                            Floods And Heavy Rainfall Is Wreaking Havoc In Chennai &amp; Andhra Pradesh, Stand With The
                            Victims</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1200</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Dheeraj Singh</p><a class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Support-matajis-this-winter">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 232px;">
                    <div>
                        <p class="live-data_amountWrapper__1DnnY"><span class="live-data_amount__1tU-G">₹
                                1180</span><span class="live-data_amount__1tU-G">about 1 hour ago</span></p>
                        <p class="live-data_donorName__2bmUT">Ripa Mukesh Patel</p><a
                            class="live-data_campaignLink__1SAz9"
                            href="https://donatekart.com/Pure-Devotion/Help-Widows-of-Vrindavan">Hungry, Cold &amp;
                            Alone, Vrindavan's Matajis Are Struggling To Survive Winter</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="how-it-works_howDkWorks__vhL8d">
    <div class="container">
        <div class="section-title_heading__2H9zs ">
            <div class="section-title_headingWrapper__31KBD">
                <h2>How It Works?</h2>
            </div>
        </div>
    </div>
    <div class="how-it-works_tabsWrapper__2NXsD">
        <h3 id="tab0" class="how-it-works_tab__156Dk how-it-works_active__lqxO3">For Donors</h3>
        <h3 id="tab1" class="how-it-works_tab__156Dk ">For NGOs</h3>
    </div>
    <div class="container how-it-works_tabContent__3ot5B">
        <div class="dk-carousel_sliderContainer__3zuS0 ">
            <div class="dk-carousel_slider__2p09r  how-it-works_cardCarousel__2lxfc">
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 259.5px;">
                    <div class="how-it-works_cardWrapper__3MBw2">
                        <div class="how-it-works_card__2UYjS">
                            <p class="how-it-works_img__2KOvt"><img
                                    src="/_next/static/images/dk-process1-ff826ef23fbf38ff6e312d69ad1c17b6.webp"
                                    class="lazyload gm-observing gm-observing-cb"
                                    alt="Donatekart - How Fund Raising Works - Choose a cause" loading="lazy"></p>
                            <h4 class="how-it-works_title__P-8jN">Choose a cause</h4>
                            <p class="how-it-works_desc__1L29A">Browse different campaigns and select a cause.</p>
                        </div>
                        <div class="how-it-works_nextIcon__HtqcL"><span class="how-it-works_icon__3U_wa"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-up"
                                    class="svg-inline--fa fa-angle-up fa-w-10 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                    <path fill="currentColor"
                                        d="M177 159.7l136 136c9.4 9.4 9.4 24.6 0 33.9l-22.6 22.6c-9.4 9.4-24.6 9.4-33.9 0L160 255.9l-96.4 96.4c-9.4 9.4-24.6 9.4-33.9 0L7 329.7c-9.4-9.4-9.4-24.6 0-33.9l136-136c9.4-9.5 24.6-9.5 34-.1z">
                                    </path>
                                </svg></span></div>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 259.5px;">
                    <div class="how-it-works_cardWrapper__3MBw2">
                        <div class="how-it-works_card__2UYjS">
                            <p class="how-it-works_img__2KOvt"><img
                                    src="/_next/static/images/dk-process2-3493f77dcb0d787fb6ea538caa22c453.webp"
                                    class="lazyload gm-observing gm-observing-cb"
                                    alt="Donatekart - How Fund Raising Works - Select products" loading="lazy"></p>
                            <h4 class="how-it-works_title__P-8jN">Select products</h4>
                            <p class="how-it-works_desc__1L29A">Select products and quantity you wish to donate.</p>
                        </div>
                        <div class="how-it-works_nextIcon__HtqcL"><span class="how-it-works_icon__3U_wa"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-up"
                                    class="svg-inline--fa fa-angle-up fa-w-10 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                    <path fill="currentColor"
                                        d="M177 159.7l136 136c9.4 9.4 9.4 24.6 0 33.9l-22.6 22.6c-9.4 9.4-24.6 9.4-33.9 0L160 255.9l-96.4 96.4c-9.4 9.4-24.6 9.4-33.9 0L7 329.7c-9.4-9.4-9.4-24.6 0-33.9l136-136c9.4-9.5 24.6-9.5 34-.1z">
                                    </path>
                                </svg></span></div>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 259.5px;">
                    <div class="how-it-works_cardWrapper__3MBw2">
                        <div class="how-it-works_card__2UYjS">
                            <p class="how-it-works_img__2KOvt"><img
                                    src="/_next/static/images/dk-process3-9b5d3f79a11d7c06fe059c4052a691c9.webp"
                                    class="lazyload gm-observing gm-observing-cb"
                                    alt="Donatekart - How Fund Raising Works - Order processing" loading="lazy"></p>
                            <h4 class="how-it-works_title__P-8jN">Order processing</h4>
                            <p class="how-it-works_desc__1L29A">Checkout and pay for your contributions.</p>
                        </div>
                        <div class="how-it-works_nextIcon__HtqcL"><span class="how-it-works_icon__3U_wa"><svg
                                    aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-up"
                                    class="svg-inline--fa fa-angle-up fa-w-10 " role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                    <path fill="currentColor"
                                        d="M177 159.7l136 136c9.4 9.4 9.4 24.6 0 33.9l-22.6 22.6c-9.4 9.4-24.6 9.4-33.9 0L160 255.9l-96.4 96.4c-9.4 9.4-24.6 9.4-33.9 0L7 329.7c-9.4-9.4-9.4-24.6 0-33.9l136-136c9.4-9.5 24.6-9.5 34-.1z">
                                    </path>
                                </svg></span></div>
                    </div>
                </div>
                <div class="dk-carousel_slide__3Uk9c undefined" style="width: 259.5px;">
                    <div class="how-it-works_cardWrapper__3MBw2">
                        <div class="how-it-works_card__2UYjS">
                            <p class="how-it-works_img__2KOvt"><img
                                    src="/_next/static/images/dk-process4-8f6d0a288efb395b43ae5c98598d10c5.webp"
                                    class="lazyload gm-observing gm-observing-cb"
                                    alt="Donatekart - How Fund Raising Works - delivery report" loading="lazy"></p>
                            <h4 class="how-it-works_title__P-8jN">delivery report</h4>
                            <p class="how-it-works_desc__1L29A">Donatekart delivers the products and the organisation
                                updates
                                about product utilization.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container">
    <div class="section-title_heading__2H9zs ">
        <div class="section-title_headingWrapper__31KBD">
            <h2>Testimonials</h2>
        </div>
    </div>
</div>
<div class="home-testimonials_tabsWrapper__2PKcc">
    <h3 class="home-testimonials_tab__1Qmkj home-testimonials_active__CqgFO">Celebrities</h3>
    <h3 class="home-testimonials_tab__1Qmkj ">Donors</h3>
    <h3 class="home-testimonials_tab__1Qmkj ">NGOs</h3>
</div>
<div class="container home-testimonials_tabContent__10f9t">
    <div class="dk-carousel_sliderContainer__3zuS0 ">
        <div class="dk-carousel_slider__2p09r  home-testimonials_cardCarousel__X_9yd">
            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 380px;">
                <div class="home-testimonials_card__1FXGk">
                    <p class="home-testimonials_img__psXpx"><img
                            src="/_next/static/images/shanti-mohan-610f37ffd471924f8d273058f5d3f2f8.jpg"
                            class="lazyload gm-observing gm-observing-cb" alt="Donatekart - Shanti Mohan - image"
                            loading="lazy"></p>
                    <h4 class="home-testimonials_title__2b_5B">Shanti Mohan</h4>
                    <p class="home-testimonials_role__1QVXX">Founder of LetsVenture</p>
                    <div class="home-testimonials_bodyBg__3TeD7 home-testimonials_donorBg__2HhMr">
                        <p class="home-testimonials_desc__25D3H">What struck me most about this venture is the passion
                            and commitment of the founders to make the process of giving easy. They have a good
                            understanding of the problem statement and have an even better solution.</p>
                    </div>
                </div>
            </div>
            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 380px;">
                <div class="home-testimonials_card__1FXGk">
                    <p class="home-testimonials_img__psXpx"><img
                            src="/_next/static/images/vijay-sekhar-sharma-900048ee44bbbf993de82e60202c43ed.jpg"
                            class="lazyload gm-observing gm-observing-cb"
                            alt="Donatekart - Vijay Shekhar Sharma - image" loading="lazy"></p>
                    <h4 class="home-testimonials_title__2b_5B">Vijay Shekhar Sharma</h4>
                    <p class="home-testimonials_role__1QVXX">Founder of One97 &amp; Paytm</p>
                    <div class="home-testimonials_bodyBg__3TeD7 home-testimonials_donorBg__2HhMr">
                        <p class="home-testimonials_desc__25D3H">Anyone who donates often thinks about whether they’re
                            actually making a difference. This is why Donatekart is an incredible idea - you can clearly
                            see the impact your donations have made in the form of products delivered to the NGOs.</p>
                    </div>
                </div>
            </div>
            <div class="dk-carousel_slide__3Uk9c undefined" style="width: 380px;">
                <div class="home-testimonials_card__1FXGk">
                    <p class="home-testimonials_img__psXpx"><img
                            src="/_next/static/images/yuvraj-singh-96bd4e92e7cfe9c5c2be08dae20d7f3e.jpg"
                            class="lazyload gm-observing gm-observing-cb" alt="Donatekart - Yuvraj Singh - image"
                            loading="lazy"></p>
                    <h4 class="home-testimonials_title__2b_5B">Yuvraj Singh</h4>
                    <p class="home-testimonials_role__1QVXX">Former Indian International Cricketer</p>
                    <div class="home-testimonials_bodyBg__3TeD7 home-testimonials_donorBg__2HhMr">
                        <p class="home-testimonials_desc__25D3H">Donatekart is a unique platform where you can be
                            assured that the products you donate are delivered responsibly to NGOs. I’m so happy to have
                            partnered with them to help so many people during the pandemic.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="featured-in_featuredIn__1dnEJ">
    <div class="container">
        <div class="section-title_heading__2H9zs ">
            <div class="section-title_headingWrapper__31KBD">
                <h2>Featured In</h2>
            </div>
        </div>
        <div class="featured-in_imageWrapper__ZpwNF">
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://www.outlookbusiness.com/enterprise/big-idea/for-a-worthy-cause-4331"><img
                            data-src="data:image/webp;base64,UklGRrQcAABXRUJQVlA4WAoAAAAMAAAAlQAAlQAAVlA4TJkQAAAvlUAlANWGgrZtmJQ/7P0DICLUtm3DuKVtOQPdkrMrxqpxfkA4/dbvleTa2nbs0ZHY+NHFtm2rsm3btu1kbNu2Wca28aOanIBTjd9u9K538M8KK4iSbJt2zjs5j7Ft27Zt27r1bNv2i23j/xIIbtsGkiQnM3v//+5h4v4zcNtIkZfx+B7hD9u2ZWqz7QtWd7fb3d3d3d3d3f2uu7u7u7vEFSfuCe4OExhb7uG6hmTu5f77jp00pHQ4ctDSkk7PPSTE5sqBhWaGCJEQSZIjST51moB6/jDfIiG2bSNIYrz//Tf8P+o/BEly4zZDGxYhlb3gASjKDwYARCrM+e/d6FzU4HpuycA/FITAALjRIBxPPxAhBBFARCHAiU+EQsAo/eAQAn2AceeCsXNXESJkA3/fsK+IuATj1ADQBx2nG446BYQAIGSu5/WgdhF4343/Oki2k11ro7jWQbq1paWltbW1peG8k3hrnfhvqYNAN2pvUAEa+L8Vgvnkxw1OA554ncCF6l4ty/USTzW+J5tyrPU53pKRHMKvX7/CY62/0edwumGul0xTGD0oAwAECFTVu70N6s3gfbjWVDaE6ApIRkC+gvLhl62AYIU4I8QdPtny6h5e049XtWLy5ZEtn2z5pRGVjIDoERJGSBIJuqZT76OM6SRAOMsu5Zf8iN9gbIdwHdmeuMDiyoYmb6liHbwvRcs1ZzaCq6R1XI3xUJO235iD+mGk7ct/FYaHNXXrotdAHS413upzUFZJkMydGCsbR9d8yzv5dpBuAByckb8v/hvkM5F/E00/IqC6nagj2oVPcydOql6raXDnkGLXD/Zhq6bPhXlRnMH7o34SCXvL5mq3d6YY1ZNlfR6R3w2SBGeZ8rnGsGpvPhl9E6gULtdSrqIUVSy3Cmwn/88EEcyGCAjmWCijmL3R/dC/ZAhX8XaIItmT66h6t7OOgx0KX/9hHrZ6ooHUC+e/mMuVeV+mq2yb0yvBpn4MluvH0aqvUg69u/vvQnV1rQo48n/3gDWT5eSideDnNsrNQIn/1s8A5eyPJjoL5nw+iSb9PEZ/r6KpVVMrfv7D3E7ZnBZCI3gv5vKR/H3pXt+iJczYFRVaOyHGHxcjvsrl0LtzqCebqueIoCMNI/l2uCO2VNR2crvA8cxekJjzY+8afUE/IqjBfjeIHdCR7Mil/650fJy5o+8a7pMEi8PrmiQsPL6V/nxo31O8hBkfUWnqx0bKrb29XupwOpK9pbNSZ/PJGPHnUrRcP4xTDWOy5s8O0o3h0/HG7OvxlQH4vZCO4thfB7oiv6YPlgA2GsKICBJwYAAVac0jpXkiD3RYrsmGYft609VhxYSVn9pUxKm4YXjunc7ahSyczWTjR/Dt6cOstlHaC27CW+6bKJkdKDaJUsqgAb7oVGDqiPonOpJtOO3r2ii+icvTNJ6l5kWSb2O/+RdJfZ6SjxtvY/s6gSdpPMxy43lKV56l8jLJB1ld+fgiuWt307iS5JUobhN4DmgFjPcHEwHgNWaAGbU0EQHbyWYqK1Mpgg0aqshk5WRmUgzDd+4zYXaBEzwdxe7cdV8f9AQcD6gyVA1VFVUdVRnVArUKtRu1D3fd+G0mUEDACnd/1JFqqLqoPgTuE+iBvqToR4Abd4xwqKB0AMxfeaCXAFdwBIdyJIuOoqn5FoBCbiNgVh+4ktM4lTM5nVOIZRCH82+CwYM5hKampsNomoEDN2ynP9/mVbyQF/BS3shJzMKJC9zNV3kl61e9jDdzHm58AXvcBgP+ERHo15GN4855t+zXdxF3/R4b97ybcrdsmcgyyb97/V1v5N0/76rvVNLdi++ieSvncSN/50XQLWTS+hwiIXo9gwm7QQo9/6QCQGqsgyTu4pVEsDf14dV3sAu6H9uwBz27sSs703M3TmDjaHZk61MXcTIfZFs+RhGqgr8RxZ78mos5iXfT+jmUL93M0+i09uReAGAM+2BZn4ANE6xwBOGeu7EzkTeiP04hitW6znsIVfMPrLC+BgVIArtBv6cQhmlUN9G7qEDJZA4iHMHXGMXjA3mQ6/kwS1VwXrjtahhcwsF8jjIqaWrdm5tg5gK+x9cxuH1G/bfQW59UAGMSy7T1aVgZl+lxRLEH94HjiSaGU2EG+HfcicK8sEX3wgBi2RW9LT8FYCOnQR+gR2ESB2LRv2E7SuF+HsTO5ldQ91rKYAAV/JaG6byYuneQiQI4ngUCn5j98PACPsT7eDaafk4eSgBsPgAPcGIAHu5HfoAV/geKBejPGJyYYTzeRkQ/JhfAoPBc9IcxooMGzV3NPJB9iGFVDsxugNuxMYi28OuYiRJBMVfju0sMTdNefJBGxcDi2eAnaL0iDoYIA16MbNoBTbQtX6HeIJEvhT6JDcXeADyEwwuqMK7AoeyEtR2HA4YbKBHAR3yF6ziZ1VstrZvPpBo2mM/gHZxAWNP8EdgxHHjrPMT2bIdFpN+J4ZCvhVbPosboGsCAhCbwEiLR9A/KCAGC7hdiEa0KMER85N4Pg1sF7uE1aLJ2Za3yQLoWqknieWii53I+NgDxmGhqEGB++0/4MnWa9CfZDIiTW6DP02hyQzGXsBjc+HOIaDs6J8IQLueHeGjWSxnimy/ykid5Ks9BEzU/ABuNMnI8NVRxHKRJ78SCIljgzdzFdqyZyYchTXVvJQOGuot+fBkj+rP0525u52Z+ziE4AdJ5AREQWa9mMHAATmRPiCiGJfGwb+8KIMCptGuir9PSUXtHARu2h0hb3yYfFhMCvoWmhzmPDxADEb2JsSj1IPRVTKZpN3ZhZ7bWHQwDGEinRWQ9F1EA7mRPNBG9lJEwfIvYWf5iNFlLprDcw2fxyn0oRvPfaCKi8DcogXEylsncQPjzgNP4KmGLrLeTDA+EvkUVNYTpC9zBrdTfzK/w4Aahu3kZmsha1h8ATprWayL9csbB8C2o5isQWfuRyCSWWdbX8MaePIASAW5jZyzS5PfauRJrE8CVfBZNRDsRyzDoOxiw6GDAIqECjGHZ+CAWkbU0EyXCC16DJqL3U4aPjeBfkNb7ksATz8HyeomlhhMyCAy+Dk36nWTCXrgc/Q4EgI0fsj1E9ErWRfADAl7zpGmLg7P4Ba2k628CEMbT3yMGimQvHoLhW+PgeEhbL2I8qbySsPUmAEN+48OI4Nl0qGpYBGoML0RbW3pxImYugpYLBMjn5xBRBE9bPyYQMmP0MIuAS/kHYdJ/hRUE7JFotZ4DfIhhPOeTpo/Qvqle693IxgDjV9BbKAJPZWE4eSvbEsVBpIAeo5txHvQyFAx6f0IrkaafUo3RbYKxdgCAiMrlfWj9R2bSH9S88DqiiOYkfGkYUJvej7boAlQ1/8Ky6GyMA4xn6GgYB/OYgggWP5sYXsN0zB3GOuqchQGU0BaNJvolITa4DwGGsS2i4yFOByzCjT+DrDOJ4xwMGxk/ILz1enwMjqHd0l8kCAdj2RFNqzqUYsWXYr2YFoVvcz5ihxXfTjutafR2yanQ3vRBDB/VHAFp+hUGwvr3cFAppW6l4x7eBpg5lMt7iGZREvfzaWyEmGvMc5mKEsw5xexlEUb6S1zG+XcXcjKfIwa9I9+mBMANrmZfLOsjDGRpBr0nshMv4j7gwF1frb2ZO4V80ml8MdbzSIFxnEU+v1Y/7qDGnAztQju7x7CdXA6HsLPRH/Aw0Q4gbD2X4aQyk5W9D/JuhjB/d35GbwF5jKkfV53+C5Xcxnb8mccKySWRr6J35jx8cEZslHAK0fYfyGqNodWibevtXEI74EbAbUu1tQ+v5028hF35BMOoAnDXObVlB17JO3hiL8LvJRauYAYfswiLgL7KTGbhQP0GHb6PckwlgruOI5I/YSdQxhFsiyba+AY6XsVT+7I7qYzjA2zDi3k3z7yoompX/ko+6H0bdU+9i3ewRS86i8CcAg8X82M+TF/fx+nztE/yTY4kFi9CEbqXP/I5Gj7P3xkOC0Tc465ibuJvfIGGH3FzVZaDtuP5Fh/Do/EjfIP2bA7ms/T1fZnVJQhMkz33NrDhl9T3fZyGvk/R0tDyafp+xyyg+vNnPkPDVzmCsbhxImJj/ubVfZ3Hkwp8cl9QTdD0FwcAhukNMSkBGMZQ2Q/AVX6gihBcngChIAdYoALw/qBEmaIAo5bGIoC3OCC+aN3dIiL2qiiGv1vMHzYKCUIEqKQCUyY2qKjlKS2X4sWDACAAmwKFIRq/QWp3ZQWddzAPl8EfLCfkLWTKZGdlEEdaja9kMomHnhxVhG5XqSmEjNGsfogyDDG0jKARIuYUUgtYkIJpBsu3CZXNdOodoNogkFoDhbvG1gwA788DEYgjB2C2gZHAVIqo3gZv4+D6Nf6R1WwowX6DQDTHlqv8IkAuY2B4iaPWrPHoTGAkfpuyoWUsapZNMGV41apuXOUj4u/u9sraAM/5SVbl231bCUCorDZ2NbuRYhq7Z5WtQg0sE5hW5dUpIljb1CYipfSgJahsdKOrAdLTEugyFMFH2kwxxW+Dt1AolyrSLMECIoXW0KjaJBCUmoeRDX09kAT6mvzdrioqGyLzmnuUiJ0+wwCPsTL5H2WODTC/XzC5Umq6DTR0JW6p26KJJBOOK0eF1pfUNJrg9wfvJ40NmThJq9RaO2+0Jd3X0BuaQEalVxE9E+uxrBpe7KIplUk1spzlN0ovqwdYqLjKS7ZJVu4F0nl6WFVWPsMorLYuP9wgnFMjqlsKt7j9ZDGIckOaLdyAIsuw5G0Fc3rl1Uie8c2N3RRLMb8foeHVlWpNLtSIrWQLTCWBvtG1voRRLO9icY+/fSgOOh6ui6+plcG8QhtsFYQLiGN9Vk3CzuQaXgWVWJJHPIGJNb3cZcSGKuQBpuBCRliJIZX2MpJqfcMTUyq3FvmB9vHYa2ODJO9n3FbMIw7LtBRblkMFCVZtyVvq5mYiM8tVI2nzBYzYLWODcPO69WOt2PzZlWjOzR9f9TOZBmdWelFOsQimVuu8xTmWeN/yLoa9BlcuNmhGudx4e7SakVvRllqbQ8l0zdtoK8+ShzgNkwlght1rrfk2EsUJ2CwwpfzIZmHTPD/UaMrJr7hyUcX9lHkTt8mbo//+NbnKq3WSpdMyvKqr1B40ZzWOKkf5xFRy/5a3sfMOM5hWK+Ls8RUJlWFLKmtLYATTCY6r4kqsNgceJtTmkrLsFntfBfnYEPf/1s1VMyqtSo1WF5G4ObbF9WWMopwZDKuCWjGpeuByrX2P5KNSLcFktI0lnwqGU2hDbXo9Lg2DKMTvHv8sRtK8ZmyVkMGTgRFbzsb3VmllV52VxdzYKq4se9Bs1ZFSal4qDuaYnrmLplqXC6TTMG8MxdiZBAXDFlKwkEZgbhgi0tBrBSWHiTSL25MEuhB4dHM5KCAXlxtH2MmazW0TaAnG0wB3obmSrRm1JmTNZHzNw/i79gWZMBoTUSJ+XjOFgppWKpM8Gpfk4pHQgrretuWNgSVZVViTy14VdIR8ctrbD3gtEN5TrjC3kVGFNy0w6xBDohY/4LwDgBCVYc5gfm/BmJW6qtvf7Zui4vLMhX22gJHAeCuw7FIGHZ4M4vYshjAEImY/TCUHQP3DuXdFd96KZW2wAYhvqPWBNGZHgsVTbaYpbzrd/mZTJ4xjUMmGwjvnnbngzUFdxf/gvzfhm1DJBSLyf/+Zo5AAAEVYSUZ4AAAASUkqAAgAAAAFABIBAwABAAAAAQAAABoBBQABAAAASgAAABsBBQABAAAAUgAAACgBAwABAAAAAgAAAGmHBAABAAAAWgAAAAAAAABgAAAAAQAAAGAAAAABAAAAAgACoAQAAQAAAJYAAAADoAQAAQAAAJYAAAAAAAAAWE1QIHMLAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pgo8eDp4bXBtZXRhIHhtbG5zOng9J2Fkb2JlOm5zOm1ldGEvJyB4OnhtcHRrPSdJbWFnZTo6RXhpZlRvb2wgMTAuMTAnPgo8cmRmOlJERiB4bWxuczpyZGY9J2h0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMnPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6cGRmPSdodHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvJz4KICA8cGRmOkF1dGhvcj5TaHlhbSBQcmFzYWQ8L3BkZjpBdXRob3I+CiA8L3JkZjpEZXNjcmlwdGlvbj4KCiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0nJwogIHhtbG5zOnhtcD0naHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyc+CiAgPHhtcDpDcmVhdG9yVG9vbD5DYW52YTwveG1wOkNyZWF0b3JUb29sPgogPC9yZGY6RGVzY3JpcHRpb24+CjwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9J3cnPz4A"
                            class="lazyload gm-observing gm-observing-cb" alt="for a worthy cause" loading="lazy"></a>
                </div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://yourstory.com/2018/04/donatekart-driving-need-based-donations-making-ngos-effective/"><img
                            data-src="data:image/webp;base64,UklGRpwGAABXRUJQVlA4WAoAAAAEAAAAlQAAlQAAVlA4IHoEAAAQGwCdASqWAJYAPpFGnkulo6Kho5opQLASCU3cLfl9Wixi4vBXi9l3/N+p7bE+YD9gPVm/vn7Fe4zygOsc/ar2Cv2m9MT90vhF/vvnMvH9O04KaWX4ls4TasX3Ii2P7OKg6tfL+zik6cLNpRNJDD3+7mGtTnWzbYnPiZCjgslFVp9zWyi+yiTvGCXa/DXVbBfLtafLXJPeYsL26XDIwVF8gF0PgnaZeocK/7Jv4Hu489w0g8vuarrOurr2zDhaOmRHHFYYlSrZ+KjhEPzB+D8H0Qj9nFQdWvl/ZxUHVr5fxAAA/v7BoAHMDsR+sss3ckCrEH+PJbSPhDku53qnckYptKVHE+O+49g7e4HuxXX43o+ODE0NUXH4o/FV6l9+Foh7iNjX+r5eON2kdC299qxccdkkYxBwxJa3UCYlHjRX+wCzBx8sgdpZ2UjrK5WDpLdSngTibqXnD5iXBhiRQwjTRBiHbRwKSkYEea3WShXHRwtqIn+GkpAPde1jeAVzOFvh2NIT4km5AlXUVjjsGChbOJyF7qVKY5+5yn9UBWizfpVgjjUT0xCE8KK36nHOYTXWj+Xs23lo3H/w4xhaGtnAb86v8ayyhDtcM1Eu4jZtaUUhIXKyrNUzhr0F7NGruSWDqf83QzXpWhHwz0xMFNLxzMSUWI9qd2yc/T4QrzCyMGa2R/OCJ8WDUkskHwPw3fWHXZ3bmUeuqCEVB+bh4+H1IQQdEnpaRc0FW2Kbn/QZnaac5omV+5YSvTh9WPlF5r8uaxwU85TN1ONn40DtXcnO1WwgdQb6tTILcjz6+VqAQSVr1ClHFeJD2IkJ/6J2EkJ2oRlvhmXDXLW4ua97S6MSLm/HAfwCRqL+p7SOKxDWVrXG3Ko/5oUSW0Ag/quatt1v1ouB6UHce2ST131NnRvr8o+vOBSkZ2rBlDo5zEW/Q/w/SZjh306aQA4f7VSTNOFcw0BK8adT4HEDPoAJQ4SS0ZmvLkCbFdpJSpPvtIZN0cKWayYyJxhxZjfHn1g37saNUEgmdwf0Njs/vxUsEzea4reyCiWYnHt8snk0i3hzWBxCo2D30JqApU43PlURJD1re6tUncoD3znNtgZhG0Gp1bkQcpx0Kgr8p9Qw02CwQDSkyNMCXJf0Zf0LLL1QZe/PPqVu9XAvVNr//Ohd4KP414L/zpPjEVE6XmaxBqEzsnb0jgiHkKPImZM48ZOD7uT+4bZ8llx8zcBtTA6sqIOS/M2bP4J+cUbhz0Sc8gSf2DG1xksgl6DJz2SOt6ZI01CG1pLdyjI56pB2A4iKR0pVx8B52jt99mDr6AlUOn9qc1T16FHatF7ZpvRL/mJWbICbA9QvyuDALO0ZQsEuEYTtmP932EwxWSJSS/CJS9IJf2Pj0qfoMHcFAYEwvHfMp+bKsRTQFcAE8fybqrwiNVLVY1+JH0bfdgW/qjJvf6YuLghwXqVCSRmNprkMD5cEbLXIwqeqDxpGYVk25tYUfKaawGEp8k2IPbSYfk0auznCRoByvC6gAAAAAABYTVAg+wEAADw/eHBhY2tldCBiZWdpbj0n77u/JyBpZD0nVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkJz8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0nYWRvYmU6bnM6bWV0YS8nIHg6eG1wdGs9J0ltYWdlOjpFeGlmVG9vbCAxMC4xMCc+CjxyZGY6UkRGIHhtbG5zOnJkZj0naHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyc+CgogPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9JycKICB4bWxuczpwZGY9J2h0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8nPgogIDxwZGY6QXV0aG9yPlNoeWFtIFByYXNhZDwvcGRmOkF1dGhvcj4KIDwvcmRmOkRlc2NyaXB0aW9uPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6eG1wPSdodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvJz4KICA8eG1wOkNyZWF0b3JUb29sPkNhbnZhPC94bXA6Q3JlYXRvclRvb2w+CiA8L3JkZjpEZXNjcmlwdGlvbj4KPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPD94cGFja2V0IGVuZD0ncic/PgA="
                            class="lazyload gm-observing gm-observing-cb"
                            alt="donatekart driving need based donations making ngos effective" loading="lazy"></a>
                </div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://www.thehindu.com/news/cities/mumbai/give-in-kind-not-cash/article19166531.ece"><img
                            data-src="data:image/webp;base64,UklGRiwKAABXRUJQVlA4WAoAAAAEAAAAlQAAlQAAVlA4IAoIAACwJQCdASqWAJYAPpFGnkslo6KhpJpJeLASCWdu4XHZyPkBziRAvxiQbth+dN/xv6c6wX6Dv8A/0HXG/67Jj2I/4vwP8LvsHMBwz9Wuov2D/w/KXvJ+Jmg9thIAPzH+t/8jwPdQLu/5q/oX/oPC1oAfz//F+q5/deNP6j9gbpR+i4O74OSksQNWph2VHJSWIGpfunC9RtiIp2Ed0gDdspvp3KMNsE+u+17nZQSKOz4Ry6usIvwDJUPGSSd/Usbz0YNWCElry69BSMF7H9ZA4po127WhFy4u+M6aj+jCf3LDTY7oy7Zq/5d5Y2VsCsSnYH2uQg7/iJwn68qtm7M/Zb3L26qVGCSZmDhj5viQyW+Nmq1oDHplWcj06qTezwzLdD2FjVJba6dASWIGrUw7KjkpLEDVqXIAAP7/EWACLohtS7oH8B4jPvcn9p3GpQshMivVGaCkUJbl/wtQu3WtCKCHSg64iM47zQCFefvO5r4YItiBGj7xjEvR0STSVTsllpNd+E32BPJHHlyeF17O09WXGOa5pl33qc970Z5HouNqXE/Sv+KsJ9qWaB35zL/Luflkf9f+wV33ZkeXTg4tg9HQkqNLuOmOQyj5OQYKIyFzZ6jnDVK2OVMoWlMxyedSzde0kUjGdGxnQYsHjJmhOtOgk/SMo29qiBQ4K5hGXoYALxCT2So7S6QJScBeVhauvt6Z5BWOqoeM+0p0EKj3sTGqp21YJ58ZUg8lX+0HPbGZSJSMYpWlnMrB3CDto97km6aO2N6o3WVobVymIUcerBZGm3Wm7s7UGSzbXMR7MBhmf9ipv+/zf3A6l30oI7MgO4DsiW3N+V7IPgcU5q+tU+eFM6y1l62mLU5wxlTJ0UqV74KprheTWtfhmbSy+K9kYMrA8e2pG56w5o5rAKVIQJTYU5xt6yhwJEYtU3W1oQXWGD0y3I86P23NDoe0afHeoFRsUiZszGIQEnsmzlZ1oR3DbeseRlgVb1DiIEnHTy1evqt9vJNjLIbxIDAtedRGfgdGWNAwiDFPcvIsRi/SPqZayY/t6xwZv1mfvPiOxfaLnRMlCLTjqxCtKOvIu5KI/NypGZNwQhH8Za30kdvUL0IZ8/U9adlQnlj1H1j5Vc9qgjS5LxLUEw3PFZUwLtnbpazE5ucfrOXCmxoQs5LM9oOSAGssLTsdXj1XOhcbg/JT82cePfCRkcqVGsHjlgy2u2DxhIA7uA2JbumTtFzJPo2/bxTBfJHLeMv/ZIt0+bx+MBvOHg1dybq5VM9XCca3SFuHUa+9PGo+Oq0VtZwRsh7IwPkj+5VQ+hKXxG3HQi1/3zbUFkcHggETEw4h0Oe+Y6b4+bYWw6wEj4+xHfCgavwnzdH5jKOPJVMuWbDHBXzKcsj/rw2dnxWbbkIOjmvWN9kVfjUUvX4qFvu10hjiOE8/aLu/GouiWhL7/KMy4RM7i3PiRvW0mbUNuiR7zsuSifvJOV2k+qttcNX/CWp/LmVgbISBQUs4qUYy7fx+1bOVoVTBZe1VuAs3LZ2cTzLQ2pIlNtzH9NeJjQqz7XEhsdSU2EzXaKPSHI3Pjprbzj6+jL19ZfrxWafe0ShgmQD/kFHg8RnAr1r8gxOGCGRB3sZLrPx8YyzHL8a3+bGTHLyQZBEsqnswII+Dq51KwHjC97B816sxKWRuh7flgOQ46I1m7J5nL1AQB2K1A0znT/6vnJIbWHTERZfJGho/+HC+f6Izt8ZpFdP2GRO55728FRDkCWxdziapOlcq65QIYqMA15yzszFoPNqtU3JZlPu0niCJ3Hpekx+S1sTgNyZfd9eqb2jI7Uq0vEPuj5SmY6Cse14fcueTtcAM3jYMxMXavwFKXJUU5m2ILG2qMNNKN6xzYynO1GtiqqRuKuMVcBTY2oUpSwvtRiI8SpGqWGoFhTrRqwz9CZVqE6P8HhG6+nyDOzjYqLVExDeXak37pTObtQ84ryV+RxuEBwCEr+l+Eid8e+ugpj3AMgAL2+tuQDq7gZXzRVle+JHCNcM9BIhkKD8GcK17WeHPBfFu+1vt26zzeyt/pdmbGxMbOYgHKVucMd917WYVYRulXEVMN8BSXcVcbf+pN98FkphyiML1d/EklojeJPgPpul0D/uZkoUp3hcQgZ0965xK6yot575Au5dsCXvbjd5djq5lQeIKOl7RDqUbi6Yj/mgdbQj9lF/gyUn6XuwiUUF0JjBU25uqa3AD1W4bGjKfN/nYcgN3cA7RLhhcj0Kcyg9LsKKb7bxYh4mBtE9h1EY46+GG1NfkOVhdnLlmKrJHd2rsp6S9Fl09QMC5sSTbkF+11o6bzULDr6lTB/E+g6cQ7GDVQ1iiMsGJ0nZRDSavb9SG+Osf63411CBSCCc4m62U4gl6UbFEMtluNWgqiVqpNx/Wxs7RlcUgjrG11Y0QfXUudS+7EwrDf95u5cWsgLXdL7+ZmE/MrITHZfWP2BCPPvChQSA5HDTlHok55158vpeDcxVQV8tzDkY4cZO90T0B1VlUflvwPi/K+0T/WPCA+WWaCBt/bdojBBrItNU6een1sskaHk/NdLu5ZPX4VdMY3p7AFEORarnCPVPNBONSE1wHQ7lELVXoXYvNzSV9AwWAm3ah/it4Rmo+bAjO5XLmlRRDMO0SLQrIwrvSgdRkWm6piyqxkSGnMI2yhemMfOsoDJ5yLLhMqQmmvADS2CR3A8EjSG04Iw+ZcHPzfUXP9kMdmiWrpfPgncjouzwAAABYTVAg+wEAADw/eHBhY2tldCBiZWdpbj0n77u/JyBpZD0nVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkJz8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0nYWRvYmU6bnM6bWV0YS8nIHg6eG1wdGs9J0ltYWdlOjpFeGlmVG9vbCAxMC4xMCc+CjxyZGY6UkRGIHhtbG5zOnJkZj0naHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyc+CgogPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9JycKICB4bWxuczpwZGY9J2h0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8nPgogIDxwZGY6QXV0aG9yPlNoeWFtIFByYXNhZDwvcGRmOkF1dGhvcj4KIDwvcmRmOkRlc2NyaXB0aW9uPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6eG1wPSdodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvJz4KICA8eG1wOkNyZWF0b3JUb29sPkNhbnZhPC94bXA6Q3JlYXRvclRvb2w+CiA8L3JkZjpEZXNjcmlwdGlvbj4KPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPD94cGFja2V0IGVuZD0ncic/PgA="
                            class="lazyload gm-observing gm-observing-cb" alt="give in kind not cash"
                            loading="lazy"></a></div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://www.thebetterindia.com/79642/donatekart-engineering-graduates-donations-ngo/"><img
                            data-src="data:image/webp;base64,UklGRnYMAABXRUJQVlA4WAoAAAAMAAAAlQAAlQAAVlA4ICgJAACwLgCdASqWAJYAPkkkj0WioiESS2yQKASEsbdvS/OgE+q6ul3nzNqt/pNd7i/yE+Uf9D91Xzx/r3qA/Ln/A9wD+1f1f/Lekf+wHuJ/aX1C/yn+r/87/M+6D/jv9J/wPcB+pv4V/IB+t/pO+wr/Wf8B7Bv8z/vv/09cf9n/hL/cX9x/aB/+taa5hfPPsd6uGLPpq/gO3C9o/MD5J/u/f76Xfxu+AL8d/lX91/JT8w+NXAB+S/1v/U8Z/eL/nX+g9SfAl+of6b/Se4H/LP6P/yP8H+Tvxv/7vnd+if+r/iPgT/mn9d/3guh4WVVf327/nhZLtr3L8L8ITJQqawwG86FR+dULE+puwaWD3BgyboX2uI5l1UmvJV+1QkipomwGWY6tu8ZYt3xp/KDE3G06C8W2ECN9f6rKlm13vR8dZ22fPAOPzzOUETzxx4Etzrq+Sr5l0FqrmF3+AH+pn5ijuuqFoxS0IRy/V2L4WR0QeLQq/u0t0KQktCphmv327/IAAP79wIAAgv8f/Q6o2PDMfnj6QBDyooNH61PMmrdH+htHBdsRgYfLog0o5bmBhxO/WSJQTu8hxOMUt/WjEZOES/npJ//zGfgTZkf76KFvSXgULoVDjNek9aCKfH9l9dNBsAUkLXmX/fWltEV5iWPsYeiGiSwymsRQiJmVtqvj2sj8CuWWSJZF70YLXYWq93lfNTPzQsCdBDR7husxc4ugRx8llC8gItIjTixLOz5BIS31SF5PGl0PCPhzgIbdMIf4xd4BPwBGozxazrsnvqfTbGafzR//1Q7fSf/iJA+E+jXgz3Ah9poXKTf+EahuK7AWkqhqtAD3/LQ/pBHqY94nhZwZDqiDL27Fx+QvzZBVTTuJh74P9d/d6qELwb+N4dOe/NwRda9pbt+krJ/DM9rih4CMsNfo8q9Cv9f9y/Q81sra+u0VyEtxTwt4IwoCOHN9nPmtUM+2bBKrWAbG4WCRhhxlmwBmIpAB6rDZyPz9GhVRjR7/9tV95XtRSZsZrbbsyVta3oL/wjqwy7XVTOKPF3agn955t5A6JWNIT/7Nd2VPjjJJ8rZinQeh65eYH7q6juiLXn0nbyvhNK26bgan/s/7bUyiy/IYJuTzM3aTgHVObOYqXuBEqCUKliKWCmyr1WRS/i/c++xE0/ShXYCLbkHBz+BrfiJm7K00AQXGv3mGPC/RVew/bpmay5T8MSdozQI95fMELu6wY6JOh1sjdIRmNkYHERBuxpzZMpudwUd6YqQvRxbvOT5KhuuMoJjNT/wYz46Ta7eXReDF5QUPo4zi8m+/Liv9LLc24hcHUC3cJHL6IamUMGU5Lz/b19/vIU+/TMf7cY1yC5xxrg7T/MW7ZYz4ibJfjLOP/Z925y9SKXAayOveFMu7afO49T7uhisbE/A2Qo6g72PzfJ99D3Xfn6frpa+oAp75vrDfK4+PzsY7mbey7LzGgz4OmhCO8JKbJ85kGESnizvX19OyhXOj70QKWDX2Eftmmznqj/pr7AAL52lkn+fSxbkXrzqtqPawJkZJHNrMAshLdc/J0Pp9np3BYMjGw8d+PzMKGkLf8YMXeJnH4X1ZekVW4sJ3JFV/k+LkgGs2SsiGYksGL3uEtNF460b/lf1ioK7kIkmjBjRoAaDwGKxjr+WKX9Bg/VAxJuCapP0yKtL+jGn93JvjQWXzosu6v8/JulyHmKpJ9GTBcQTeHYRUxgOFwD+g05MwNf1DxpLW3jWMiEXdBfVFx3Iov5YSySVDCcvrfd97e/lIEH2nbzX0Oj897fnHuKq9ycDo5Yt4/1ss0cR3Pf/u9GGzAkNbBDw0n4f8k0GtR4exIKA4F7sdFW72hbawRI1qLPrt+zgjORSC+X/g+shbYq5PexHO/R9QfH8myjYhQHuGQMp6ffHehNteYo1jDRLY2q66rr9IGP6QjP/lPqw526y4Exz//aKaSYvfJpsWr1n0aobT3WFnZZn9RTosEGwrP6G8rd5I+FgVxAVpBqlkD3IP+PVDQIymen8mB54GR9tgDir+FXz/3eX/h152wgK/KH1yxbh8yPfxBxrx/HuG1KJFKS0hpbZTQ50PoNG/Q8woVz/UD1FFo/4tNzTbTri5DI6FRbPc/YxKRl821zy17v6XaSZV6lzpGzxeVgKTOD72BPMrOyXd29+5JpAQvLSPFrnnokbIOZiupKUm4TmTMWWasn0Yq8dnXWFzBSTKZpmq9IXF/w4s933cfKQqTEpYAS39uFgAaklxBywr6LpqRXLPdZfe/H3EiD51hViWKCelphjU5ED1xFczn2dD61LQUBYvi8HEgzKXVdQJLcHP3IJtaMxrDi7GMr+jhAj3vp812viOe0lLJfD2em2aMkA0/r2e2sSTFXgk7jvJkhVTx56NfWFfDIRLOaCMUPFoW8WEBaPMF2Ha6hicuKTx4+fy53os80aEOgiuuvcgvCEuIEw3dlfQckgJLGJuCgZ+frIDGDW7KX8LtCTIG/XgFsJze188sxUM/C2FGZ3bYpWgVT0Z3q1J+CUIrOIOjKY0SD6va/IKIwJfAEQuujobRGRj8i4QIT5VTtXn10q6D9o2fftoiz6k5+b1J+FIwDoVsvcq9e9kXmM9OMeeVluH2MdBLQM4kSgJPvO4ZUf3D2t36yPaZnViaBsPxUBZCnYoEn0u7rO23eP0O96Mk74KoV7l8r9uUPAq8MR/z29jEVZP25H9Y/EQT3VHys35WSMBcm/BtapKnLOhQvzgq2/EKpu2DaVFjy1LQxyK0VRUDmy8Gbf99yPB806WlkTocxH1/v5BtxdqS0dQzTDjMjYuOnxrYFotPraUMZ2F+TFyxw4l6fi1i5shgBusKGiOqIqAAmEvze19J7LThfuBt9++WJrLPAxPPLNzyDQU005kR2CJ0alqiIRNyn8kk6BQjEDKCqfWLrut8Pa1EQjI+sdR/jZJ53gaRJsgeGbJ1jpC47OSzwwzP+1icZhGaVRzM/1MwuTGhu2Y4Z71eD+g0AQbTnDZ4P5bNPn0bL+HiVlhLi3y6TG84j2tpRHCZl7bNWUeR96QCtDE0O9BWN9XPz+Pk2nbm3DXIgpgbCzFxq/JH/111sEgHGGHZeh2LCbe4AeqjgwzgAAAAAAARVhJRhAAAABJSSoACAAAAAAAAAAAAAAAWE1QIBADAAA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE3IChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxNUVEODE2OTM1ODQxMUU3OUI5MjkwRTg5REJFMEM3QiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoxNUVEODE2QTM1ODQxMUU3OUI5MjkwRTg5REJFMEM3QiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjE1RUQ4MTY3MzU4NDExRTc5QjkyOTBFODlEQkUwQzdCIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjE1RUQ4MTY4MzU4NDExRTc5QjkyOTBFODlEQkUwQzdCIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+"
                            class="lazyload gm-observing gm-observing-cb"
                            alt="donatekart engineering graduates donations ngo" loading="lazy"></a></div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="http://www.newindianexpress.com/cities/hyderabad/2018/feb/24/telugu-boys-win-big-at-nasscom-social-innovation-awards-1778001.html"><img
                            data-src="data:image/webp;base64,UklGRl4LAABXRUJQVlA4WAoAAAAMAAAAlQAAlQAAVlA4IBAIAABwKwCdASqWAJYAPkkkjkWioiESS2x4KASEs7dwt+XwGJP9Vtw7QTkb/QdKvwL+oB5gP1u/wHAAfs71iPoAeWN7IX7Xf7D1fLnT4M+AnxX7T/j50CuZP7p5Hvrp9//KD8uvh//LfiT5w+kn1AvUf9Y/J7+hfuVyCQAPyn+b/5L+y/uP5dn9h6Ed6n+mf631g/13gYeYewH/OP7D/t/ud+Nn/R/wPnZ+fv+V/jPgG/lH9K/0v9l/x3/w/yvzlex79sfZi/WwZaS84Ml5wZLzgyXnBkvNtSXBc/IctPW2a+iDt7dyHc/s8DI+tOjmoHKTBOzEAyhtuegAX5avaT2U3C2xg9Pwi7lSOBok5Z1pELD2HWI7EuzT2OVfH2EBH9X71yyZX2OkCEaX2s+0q7wOzjgObFbxb7eVAmvPyjfGmnR7WN0OnkaSVVqILBriOaY3/7A2xOBticDbE4G2JwNsTgbYnA2tQAD+/36AACw3nbWVs5yYZ45lWnUMyy+VF1tPZMMVs1KPwT41UYDFxHU9BhTTq2z5gejINTSgtfSDcoPqRorwWkFK06F4Rc5pS6hnJggGrRaa5rFrkuFsvRiGYNkeA/v5IR/5k/UX6R533wTw77GHub2on3yQa/TcGTVAFS9gyNT2nQyfvSp72wL7oPnwddNDNd4MpQH+McSm32ond/i0RpD/NLWfIUew/Ef8rnsNyYKBLoj+IATq2yP+wDsZCtEF+QWhJZ1HEXwHu1ov/nq2ijZRFLza+/Sjo/8i/xVxlpxfiI3kP1iT44QznxRzHBuQhOWdYiZualMJjE/ODMDJYu6ExUKX7NWpKPIMF8AlFQQG4NbQ2cYZQPKXPpEAlRCt1gLFLaQ9hiCR8wSL5BZElJld8uYbskpJJohGX4E0us6LeT58RFKhasAF0S6EIFha48inaZhWhRJej+TdmbCn4e8WWK62oP23/iWq1+8eM8d2CpfTHl71n+jZFb/2HT0KH8VuIr2ubf6vpt98s8f3dbDPRrt2Omf36M4WA9F7uCWKaAN2jCmaZrb3irCSXrrmaEQFpOHdHCvgNp9bbeNUMGrbcBtuX5FAMXh3B3IDj3wDN3yhM41Z7zj0NjafkPEx6/BMmpDEtMnf3E0Z6RNq8zLF8PXtLnkeQfwZsjFMvUFOYvDH/JRoxA5NL55/OlKT2U7m9y+cXpFZCXJZaKMnFDPQGoFsIZt103y6GxbZ5tej3FZV7mCB+7n/xm5sgF0kGXp9q4IcCbn7Fk0Ok9ZPOFBFfvJXkQ/BAm40t08nRJNQaIMrJYBnjwtyNNwnU9TNnQdf4jLqkyOCnnVTLs3jl50IUh1xDV4Zy400f21Mp1vzNWDvsgjIef/diGfT0NTtBWo7+F10UVhdf+3DFvxNDR8hdexe++4TBuJ1IIFllldNddktwkIGPvvY1MY53Zf0HdtG5y4/Bmnfio0KDZ7MuKOo6U7pgRB1gbHyN7xpExRTimgn83q9ycF5c9W5AejBbUsTPiSqIW6lcTjtE5EvhOKKhAPjMtyWwPit/8m0PjBzbYLKgR1e6J3H4W6dw1EF1ntP0ManvD7bKKSJ+tDgYHEge4TMTAMNq/+a/LfUwhcfVj7MB39Ogzz1x0yaoum/b+/P7Jb8IXgjmmvwRF16ikKiTryp1r/QOKECAe6xos/OS9xW6Og0alyGO98DfbH4iLIv/Rc1NHF2F0RkzKlwP+F4LnUlr/fU76xDN/1lMDT/y/gD29Tcv3l7AXx0rIcaNpAcaHByLVFwB2aABGsALmaH6swR8N+55JOePqsXC5A011AfSBTZ3fV+8KWlYaST//A7dJKQmIrd50QAFUc8gwc344eBYAc6hppaJpHj+WqXiDzdolJicZ/3AiNJDovc9vA2eOd0uYOktIRd2KCKFhw00LXxaxTe2k0IFwk2UOaHaY0eymZPG1WBCSuXnErv/wrkCMw/wz+hxSJxQscjiKXysSYEpDrAGtc8kdXxSjTq5FMJ3NVTp3DAFrycOGthvIJLnQLfyt10vM6MoC1N3I5Dtaz0PfEM5EDPgjJGbsC0NS11G407yhKgn0MkgiKz7r3Kc7blCWHroylCJpPXaeRGSYMcy9txAj/nt6jLNv4ACH5RuafS6HwV2oPTvoFWefN6uICGDRg05b3L8Lz2TbDrMGFOnp67vQ3PfM340WKyd4n0SCMXxuAC/Tfu3xNX8elVMA1rhlUMPUciqRtGlC/zaDFratr9tgb56D9rElMuh6gUYeY17B01P6cf8EHGvslp7XRLq3XtCmDsnxKGuG6Uh4mRxLxvn9Wzv3S+1gSARJOWv8bH8+M5k8fFnkZUuPgxiNay+1Dmp8p4HNHCfahMZ4rKgEZ8GnIwbfKOcj5GUyljJ5JTr/gfC76TOm16WWAJtcVnHAqWRhR87cO0G+YWnSoP/G4MK/8QxDQENQQK0NrTjiOCFSGusD4w9/pvVF+w3dpVQD09YN7aiz4VNh0nxaZFcNy3/+DcwgXN2xN+RwEzRLTRHrgue7jyBFiIfDD1o/7kWMPul/7yQsqbrVHtwAfKhVkToSDi8OBF5qDb+wY60B1Z7txMrGI8ib57GaXWmxA+5GZB9eIB4JySouveFJARnDA36J3l5cAzAFeo8HHh7PNQVCvwuHHS0q+DIwzMm2hM0GzPWbVTeJfqemMPN0kTZH5M1VqJkTss7nff6bEXM1D+4U+1vbljR0u2nquUYWQYiR4fUem7zz0v7rnxjnxcQaC0IAAAAABFWElGEAAAAElJKgAIAAAAAAAAAAAAAABYTVAgEAMAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQ1OEU5QjY0MzU4MzExRTc4NkYxRERENDk1QTBCNDI3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjQ1OEU5QjY1MzU4MzExRTc4NkYxRERENDk1QTBCNDI3Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NDU4RTlCNjIzNTgzMTFFNzg2RjFEREQ0OTVBMEI0MjciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NDU4RTlCNjMzNTgzMTFFNzg2RjFEREQ0OTVBMEI0MjciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4="
                            class="lazyload gm-observing gm-observing-cb"
                            alt="telugu boys win big at nasscom social innovation awards" loading="lazy"></a></div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://timesofindia.indiatimes.com/city/nagpur/want-to-donate-smart-go-for-donatekart/articleshow/57610064.cms"><img
                            data-src="data:image/webp;base64,UklGRoYFAABXRUJQVlA4WAoAAAAEAAAAlQAAlQAAVlA4IGQDAAAwGQCdASqWAJYAPpFEn0qlo6MhqBPZSLASCU3bps9Bld4/Cv3pxX/wPuZ+AHqN8wD/VdBHzAfsl+wHuq/4D9u/eH/mfOA6zP0DOl5/c/9gMyUDNbowyBWK3qrY65d6quOpgIkIsbgOaDVbIbr0eB629N3i/zoYpg3qVdoJTfJDMUjq6GYhWGeytH2NInnOaS0TyNALBIJt4OP4svG0L/Zzu7MSs0xUX7mjV5fGJOrs0yWjkvlvMhKEjQ4V6Jign19ZREhFp8wCJCLT5gESEWnzABgA/voCgAL/xzd9rRehVJLYymtAob07zu0Vqy8s9nqA5VWk0byaANMJicp4wpa14I+UYiDeRB+epzDazf6eyFTlDPgTfKv2kdmaxP99q8Qx1RdabwJ+kaAK1AFns+Z3e86VX/RRnRSAXyzK039YYuuuu66FnzVahjU0Rl4V1vcP0ckcNQVitUtsWYRBAHCn6ypyIPhNusz2j5pXD4KeRkMXaEjav4Z7/RQ7qe36Itq5vADwckGgUg7WsBZkfohph4F1sqaeEc0jcQlpH6AEb392X12oIRh4L8qCrDjceMEcXb0Y5Rgq9+5Tu43zkJ1XyajGFj08lFm+fIdA26x2NzIijGrUKfBFVH5RQvoESnmBxpvUdIx3Orcla2w72Jn6MpNECeEshZehRvbvz/WJqEcNKzOZw+aZTODH7+s65Fvnr8uCGZeadCzo4sw5XLiikQL0DA7X3KGm970oZQp8X8aSbFb5iZs24ZIDcR9NGBk0iWpAwWczofGYXsp1tvg3PS7/BtodII08YYLfbVuf7aI+tl50JdgFixMSohoIfavxG3D4Aj7xkyeAAAV/Rf/2dNj+ex16bmEq+quhWIEPUDU5fLB34HD/7nyBPpefM1Wn6+/Y+kRzkC8JjwxvumynE38BEmTWXE+TH6pA1n5qMLhh9KqpQj1ok2eaDdH84o/NHgqxNbFrU6AGKLALJwQq65b4VXnXQ0NT/WX7Bw6jWDzGQ+YLBelepw/Ms3Pjr0QoI5at63Vn1Eq4S/GHNuQ09CPDbfzinhjWLqvLdMxF3OajzAoRjG0v6PjjfwZqAbew8ruGQIAAfW/7/wV821kp//Lkpbt4P/pZBlSju8Ax/k22WMQqgco1AhH2cMptVAAAAAAAWE1QIPsBAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pgo8eDp4bXBtZXRhIHhtbG5zOng9J2Fkb2JlOm5zOm1ldGEvJyB4OnhtcHRrPSdJbWFnZTo6RXhpZlRvb2wgMTAuMTAnPgo8cmRmOlJERiB4bWxuczpyZGY9J2h0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMnPgoKIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PScnCiAgeG1sbnM6cGRmPSdodHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvJz4KICA8cGRmOkF1dGhvcj5TaHlhbSBQcmFzYWQ8L3BkZjpBdXRob3I+CiA8L3JkZjpEZXNjcmlwdGlvbj4KCiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0nJwogIHhtbG5zOnhtcD0naHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyc+CiAgPHhtcDpDcmVhdG9yVG9vbD5DYW52YTwveG1wOkNyZWF0b3JUb29sPgogPC9yZGY6RGVzY3JpcHRpb24+CjwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9J3InPz4A"
                            class="lazyload gm-observing gm-observing-cb" alt="want to donate smart go for donatekart"
                            loading="lazy"></a></div>
            </div>
            <div class="featured-in_imageDiv__2wi5y">
                <div class="featured-in_greyImage__1fvMY"><a target="_blank" rel="noreferrer"
                        href="https://www.forbesindia.com/lists/30-under-30-2022/1?profile=sandeep-sharma-anil-kumar-reddy-sarang-bobade"><img
                            data-src="/_next/static/images/forbesIn-0a6e261a22a11b49afef29ef8d00ca4d.webp"
                            class="lazyload gm-observing gm-observing-cb"
                            alt="Co-founders were listed in forbes 30 under 30" loading="lazy"></a></div>
            </div>
        </div>
    </div>
</section>
<section class="awards_awards__ztSaI">
    <div class="container">
        <div class="section-title_heading__2H9zs ">
            <div class="section-title_headingWrapper__31KBD">
                <h2>Awards</h2>
            </div>
        </div>
        <div class="awards_imageWrapper__2fFcx">
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/forbes30U30-1ad4375770a8fd22c031fa788cb6ae1c.webp"
                        class="lazyload gm-observing gm-observing-cb" alt="Donatekart - Featured Awards - Forbes 30U30"
                        loading="lazy"></div>
                <div class="awards_details__15j-U">
                    <p>Forbes 30 Under 30</p>
                    <p>2022</p>
                </div>
            </div>
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/maharastra-f64d5d28636e62573269c9ce07708a81.webp"
                        class="lazyload gm-observing gm-observing-cb"
                        alt="Donatekart - Featured Awards - Maharshtra State Logo" loading="lazy"></div>
                <div class="awards_details__15j-U">
                    <p>National Business Excellence <!-- --> And Achievers Award</p>
                    <p>2021</p>
                </div>
            </div>
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/plfhyd-765a42e8ab2b53fb1d3181a0849f854e.webp"
                        class="lazyload gm-observing gm-observing-cb"
                        alt="Donatekart - Featured Awards - Hyderabad Software Enterprises Association Logo"
                        loading="lazy"></div>
                <div class="awards_details__15j-U">
                    <p>Top Ten Startups In Hyderabad</p>
                    <p>2020</p>
                </div>
            </div>
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/azimPremJi-75234739471ec913b31c913a54eb08db.webp"
                        class="lazyload gm-observing gm-observing-cb"
                        alt="Donatekart - Featured Awards - Azim Premji Logo" loading="lazy"></div>
                <div class="awards_details__15j-U">
                    <p>Social Enterprise Challenge Award</p>
                    <p>2018</p>
                </div>
            </div>
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/nasscom-b788627d29932163c33ddd6df1c729e2.webp"
                        class="lazyload gm-observing gm-observing-cb"
                        alt="Donatekart - Featured Awards - A NASSCOM Social Innovation Forum Logo" loading="lazy">
                </div>
                <div class="awards_details__15j-U">
                    <p>NASSCOM Social Innovation Award</p>
                    <p>2018</p>
                </div>
            </div>
            <div class="awards_imageDiv__201b1">
                <div class="awards_awardImage__14g9h"><img
                        src="/_next/static/images/indianExp-2f3b4b9ff6fd7dab15d4e747577a1cd7.webp"
                        class="lazyload gm-observing gm-observing-cb"
                        alt="Donatekart - Featured Awards - The New Indian Express" loading="lazy"></div>
                <div class="awards_details__15j-U">
                    <p>Indian Express 40 <br> Under 40</p>
                    <p>2017</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.donate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects&Practices\Professional Projects\rsihmProject\resources\views/donateHome.blade.php ENDPATH**/ ?>